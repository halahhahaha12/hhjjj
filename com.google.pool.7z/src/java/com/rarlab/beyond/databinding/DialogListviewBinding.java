/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  android.widget.ListView
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class DialogListviewBinding
implements ViewBinding {
    public final ListView listViewDialogList;
    public final TextView listViewDialogMsg;
    private final LinearLayout rootView;

    private DialogListviewBinding(LinearLayout linearLayout, ListView listView, TextView textView) {
        this.rootView = linearLayout;
        this.listViewDialogList = listView;
        this.listViewDialogMsg = textView;
    }

    public static DialogListviewBinding bind(View view) {
        TextView textView;
        int n = 2131362102;
        ListView listView = (ListView)ViewBindings.findChildViewById((View)view, (int)n);
        if (listView != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362103))) != null) {
            return new DialogListviewBinding((LinearLayout)view, listView, textView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static DialogListviewBinding inflate(LayoutInflater layoutInflater) {
        return DialogListviewBinding.inflate(layoutInflater, null, false);
    }

    public static DialogListviewBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558453, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return DialogListviewBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

