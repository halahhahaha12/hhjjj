/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.TextView
 *  androidx.core.widget.NestedScrollView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class FragmentHelpBinding
implements ViewBinding {
    public final TextView helpTextView;
    private final NestedScrollView rootView;

    private FragmentHelpBinding(NestedScrollView nestedScrollView, TextView textView) {
        this.rootView = nestedScrollView;
        this.helpTextView = textView;
    }

    public static FragmentHelpBinding bind(View view) {
        TextView textView = (TextView)ViewBindings.findChildViewById((View)view, (int)2131362065);
        if (textView != null) {
            return new FragmentHelpBinding((NestedScrollView)view, textView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(2131362065)));
    }

    public static FragmentHelpBinding inflate(LayoutInflater layoutInflater) {
        return FragmentHelpBinding.inflate(layoutInflater, null, false);
    }

    public static FragmentHelpBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558456, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return FragmentHelpBinding.bind(view);
    }

    public NestedScrollView getRoot() {
        return this.rootView;
    }
}

