/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class ApplicationInfoItemBinding
implements ViewBinding {
    public final ImageView chooseClientDialogClientsItemIcon;
    public final TextView chooseClientDialogClientsItemName;
    public final TextView chooseClientDialogClientsItemPackageName;
    private final LinearLayout rootView;

    private ApplicationInfoItemBinding(LinearLayout linearLayout, ImageView imageView, TextView textView, TextView textView2) {
        this.rootView = linearLayout;
        this.chooseClientDialogClientsItemIcon = imageView;
        this.chooseClientDialogClientsItemName = textView;
        this.chooseClientDialogClientsItemPackageName = textView2;
    }

    public static ApplicationInfoItemBinding bind(View view) {
        TextView textView;
        TextView textView2;
        int n = 2131361964;
        ImageView imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)n);
        if (imageView != null && (textView2 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361965))) != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361966))) != null) {
            return new ApplicationInfoItemBinding((LinearLayout)view, imageView, textView2, textView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ApplicationInfoItemBinding inflate(LayoutInflater layoutInflater) {
        return ApplicationInfoItemBinding.inflate(layoutInflater, null, false);
    }

    public static ApplicationInfoItemBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558436, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ApplicationInfoItemBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

