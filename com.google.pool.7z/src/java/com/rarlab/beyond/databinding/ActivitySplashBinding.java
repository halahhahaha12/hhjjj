/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  androidx.constraintlayout.widget.Guideline
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Guideline;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class ActivitySplashBinding
implements ViewBinding {
    public final Guideline guideline2;
    public final Guideline guideline3;
    private final ConstraintLayout rootView;

    private ActivitySplashBinding(ConstraintLayout constraintLayout, Guideline guideline, Guideline guideline2) {
        this.rootView = constraintLayout;
        this.guideline2 = guideline;
        this.guideline3 = guideline2;
    }

    public static ActivitySplashBinding bind(View view) {
        Guideline guideline;
        int n = 2131362058;
        Guideline guideline2 = (Guideline)ViewBindings.findChildViewById((View)view, (int)n);
        if (guideline2 != null && (guideline = (Guideline)ViewBindings.findChildViewById((View)view, (int)(n = 2131362059))) != null) {
            return new ActivitySplashBinding((ConstraintLayout)view, guideline2, guideline);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivitySplashBinding inflate(LayoutInflater layoutInflater) {
        return ActivitySplashBinding.inflate(layoutInflater, null, false);
    }

    public static ActivitySplashBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558435, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivitySplashBinding.bind(view);
    }

    public ConstraintLayout getRoot() {
        return this.rootView;
    }
}

