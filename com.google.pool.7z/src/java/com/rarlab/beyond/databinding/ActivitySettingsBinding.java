/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class ActivitySettingsBinding
implements ViewBinding {
    public final Button BackButton;
    public final RelativeLayout ChildLayout;
    public final RelativeLayout ChildLayout2;
    public final RelativeLayout ParentLayout;
    public final EditText PasswordConfirmationInput;
    public final EditText PasswordInput;
    public final Button RedeemKeyButton;
    public final TextView RemainingDaysText;
    public final Button ResetHwidButton;
    public final ScrollView ScrollBar;
    public final EditText SecurityAnswerInput;
    public final EditText SecurityQuestionInput;
    public final EditText SubKeyInput;
    public final Button UpdatePasswordButton;
    public final Button UpdateSecurityQASButton;
    public final RelativeLayout loadingPanel;
    private final RelativeLayout rootView;
    public final TextView titleBar;

    private ActivitySettingsBinding(RelativeLayout relativeLayout, Button button, RelativeLayout relativeLayout2, RelativeLayout relativeLayout3, RelativeLayout relativeLayout4, EditText editText, EditText editText2, Button button2, TextView textView, Button button3, ScrollView scrollView, EditText editText3, EditText editText4, EditText editText5, Button button4, Button button5, RelativeLayout relativeLayout5, TextView textView2) {
        this.rootView = relativeLayout;
        this.BackButton = button;
        this.ChildLayout = relativeLayout2;
        this.ChildLayout2 = relativeLayout3;
        this.ParentLayout = relativeLayout4;
        this.PasswordConfirmationInput = editText;
        this.PasswordInput = editText2;
        this.RedeemKeyButton = button2;
        this.RemainingDaysText = textView;
        this.ResetHwidButton = button3;
        this.ScrollBar = scrollView;
        this.SecurityAnswerInput = editText3;
        this.SecurityQuestionInput = editText4;
        this.SubKeyInput = editText5;
        this.UpdatePasswordButton = button4;
        this.UpdateSecurityQASButton = button5;
        this.loadingPanel = relativeLayout5;
        this.titleBar = textView2;
    }

    public static ActivitySettingsBinding bind(View view) {
        RelativeLayout relativeLayout;
        RelativeLayout relativeLayout2;
        int n = 2131361799;
        Button button = (Button)ViewBindings.findChildViewById((View)view, (int)n);
        if (button != null && (relativeLayout = (RelativeLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131361806))) != null && (relativeLayout2 = (RelativeLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131361807))) != null) {
            ScrollView scrollView;
            EditText editText;
            Button button2;
            Button button3;
            TextView textView;
            TextView textView2;
            RelativeLayout relativeLayout3;
            Button button4;
            EditText editText2;
            EditText editText3;
            Button button5;
            EditText editText4;
            RelativeLayout relativeLayout4 = (RelativeLayout)view;
            n = 2131361827;
            EditText editText5 = (EditText)ViewBindings.findChildViewById((View)view, (int)n);
            if (editText5 != null && (editText3 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131361828))) != null && (button4 = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361831))) != null && (textView2 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361833))) != null && (button5 = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361834))) != null && (scrollView = (ScrollView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361840))) != null && (editText = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131361841))) != null && (editText4 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131361842))) != null && (editText2 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131361844))) != null && (button3 = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361849))) != null && (button2 = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361850))) != null && (relativeLayout3 = (RelativeLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362105))) != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362326))) != null) {
                ActivitySettingsBinding activitySettingsBinding = new ActivitySettingsBinding(relativeLayout4, button, relativeLayout, relativeLayout2, relativeLayout4, editText5, editText3, button4, textView2, button5, scrollView, editText, editText4, editText2, button3, button2, relativeLayout3, textView);
                return activitySettingsBinding;
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivitySettingsBinding inflate(LayoutInflater layoutInflater) {
        return ActivitySettingsBinding.inflate(layoutInflater, null, false);
    }

    public static ActivitySettingsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558434, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivitySettingsBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

