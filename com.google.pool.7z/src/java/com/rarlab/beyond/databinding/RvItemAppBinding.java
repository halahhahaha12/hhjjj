/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class RvItemAppBinding
implements ViewBinding {
    public final ImageView appImage;
    public final LinearLayout appLayout;
    public final TextView appName;
    private final LinearLayout rootView;

    private RvItemAppBinding(LinearLayout linearLayout, ImageView imageView, LinearLayout linearLayout2, TextView textView) {
        this.rootView = linearLayout;
        this.appImage = imageView;
        this.appLayout = linearLayout2;
        this.appName = textView;
    }

    public static RvItemAppBinding bind(View view) {
        int n = 2131361922;
        ImageView imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)n);
        if (imageView != null) {
            LinearLayout linearLayout = (LinearLayout)view;
            TextView textView = (TextView)ViewBindings.findChildViewById((View)view, (int)2131361924);
            if (textView != null) {
                return new RvItemAppBinding(linearLayout, imageView, linearLayout, textView);
            }
            n = 2131361924;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static RvItemAppBinding inflate(LayoutInflater layoutInflater) {
        return RvItemAppBinding.inflate(layoutInflater, null, false);
    }

    public static RvItemAppBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558512, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return RvItemAppBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

