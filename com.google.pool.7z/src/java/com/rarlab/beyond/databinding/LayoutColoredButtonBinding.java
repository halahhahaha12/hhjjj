/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class LayoutColoredButtonBinding
implements ViewBinding {
    public final LinearLayout cheatButton;
    public final ImageView icon;
    private final LinearLayout rootView;
    public final TextView text1;

    private LayoutColoredButtonBinding(LinearLayout linearLayout, LinearLayout linearLayout2, ImageView imageView, TextView textView) {
        this.rootView = linearLayout;
        this.cheatButton = linearLayout2;
        this.icon = imageView;
        this.text1 = textView;
    }

    public static LayoutColoredButtonBinding bind(View view) {
        TextView textView;
        LinearLayout linearLayout = (LinearLayout)view;
        int n = 16908294;
        ImageView imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)n);
        if (imageView != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 16908308))) != null) {
            return new LayoutColoredButtonBinding(linearLayout, linearLayout, imageView, textView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static LayoutColoredButtonBinding inflate(LayoutInflater layoutInflater) {
        return LayoutColoredButtonBinding.inflate(layoutInflater, null, false);
    }

    public static LayoutColoredButtonBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558458, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return LayoutColoredButtonBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

