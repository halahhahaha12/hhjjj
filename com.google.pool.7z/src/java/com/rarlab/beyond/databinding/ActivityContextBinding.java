/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  androidx.viewbinding.ViewBinding
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 */
package com.rarlab.beyond.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.viewbinding.ViewBinding;
import java.util.Objects;

public final class ActivityContextBinding
implements ViewBinding {
    private final LinearLayout rootView;

    private ActivityContextBinding(LinearLayout linearLayout) {
        this.rootView = linearLayout;
    }

    public static ActivityContextBinding bind(View view) {
        Objects.requireNonNull((Object)view, (String)"rootView");
        return new ActivityContextBinding((LinearLayout)view);
    }

    public static ActivityContextBinding inflate(LayoutInflater layoutInflater) {
        return ActivityContextBinding.inflate(layoutInflater, null, false);
    }

    public static ActivityContextBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558428, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivityContextBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

