/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.FrameLayout
 *  android.widget.LinearLayout
 *  androidx.appcompat.widget.Toolbar
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class ActivityFragmentCommonBinding
implements ViewBinding {
    public final FrameLayout fragmentContainer;
    private final LinearLayout rootView;
    public final Toolbar toolbar;

    private ActivityFragmentCommonBinding(LinearLayout linearLayout, FrameLayout frameLayout, Toolbar toolbar) {
        this.rootView = linearLayout;
        this.fragmentContainer = frameLayout;
        this.toolbar = toolbar;
    }

    public static ActivityFragmentCommonBinding bind(View view) {
        Toolbar toolbar;
        int n = 2131362046;
        FrameLayout frameLayout = (FrameLayout)ViewBindings.findChildViewById((View)view, (int)n);
        if (frameLayout != null && (toolbar = (Toolbar)ViewBindings.findChildViewById((View)view, (int)(n = 2131362330))) != null) {
            return new ActivityFragmentCommonBinding((LinearLayout)view, frameLayout, toolbar);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivityFragmentCommonBinding inflate(LayoutInflater layoutInflater) {
        return ActivityFragmentCommonBinding.inflate(layoutInflater, null, false);
    }

    public static ActivityFragmentCommonBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558430, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivityFragmentCommonBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

