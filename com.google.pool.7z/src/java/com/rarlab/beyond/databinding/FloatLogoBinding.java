/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.Spinner
 *  android.widget.Switch
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class FloatLogoBinding
implements ViewBinding {
    public final Switch AdBlock;
    public final Spinner AutoAction;
    public final LinearLayout AutoAimTab;
    public final Button AutoAimTabButton;
    public final View CoreStart;
    public final Switch DrawPrediction;
    public final Switch DrawShotState;
    public final Spinner EightBallPoolTarget;
    public final Switch FindBestShot;
    public final Switch FreezeLines;
    public final Switch HumanizedAngle;
    public final Switch HumanizedPower;
    public final RelativeLayout MainView;
    public final LinearLayout MenuTabs;
    public final LinearLayout MiscTab;
    public final Button MiscTabButton;
    public final Spinner PocketNominationMode;
    public final Switch UseFullPowerAtBreak;
    public final LinearLayout VisualsTab;
    public final Button VisualsTabButton;
    public final Switch WideGuideLine;
    public final TextView closeBtn;
    public final ImageView floatLogo;
    public final RelativeLayout layoutCollapsed;
    public final RelativeLayout relativeLayoutParent;
    private final RelativeLayout rootView;
    public final TextView titleBar;

    private FloatLogoBinding(RelativeLayout relativeLayout, Switch switch_, Spinner spinner, LinearLayout linearLayout, Button button, View view, Switch switch_2, Switch switch_3, Spinner spinner2, Switch switch_4, Switch switch_5, Switch switch_6, Switch switch_7, RelativeLayout relativeLayout2, LinearLayout linearLayout2, LinearLayout linearLayout3, Button button2, Spinner spinner3, Switch switch_8, LinearLayout linearLayout4, Button button3, Switch switch_9, TextView textView, ImageView imageView, RelativeLayout relativeLayout3, RelativeLayout relativeLayout4, TextView textView2) {
        this.rootView = relativeLayout;
        this.AdBlock = switch_;
        this.AutoAction = spinner;
        this.AutoAimTab = linearLayout;
        this.AutoAimTabButton = button;
        this.CoreStart = view;
        this.DrawPrediction = switch_2;
        this.DrawShotState = switch_3;
        this.EightBallPoolTarget = spinner2;
        this.FindBestShot = switch_4;
        this.FreezeLines = switch_5;
        this.HumanizedAngle = switch_6;
        this.HumanizedPower = switch_7;
        this.MainView = relativeLayout2;
        this.MenuTabs = linearLayout2;
        this.MiscTab = linearLayout3;
        this.MiscTabButton = button2;
        this.PocketNominationMode = spinner3;
        this.UseFullPowerAtBreak = switch_8;
        this.VisualsTab = linearLayout4;
        this.VisualsTabButton = button3;
        this.WideGuideLine = switch_9;
        this.closeBtn = textView;
        this.floatLogo = imageView;
        this.layoutCollapsed = relativeLayout3;
        this.relativeLayoutParent = relativeLayout4;
        this.titleBar = textView2;
    }

    public static FloatLogoBinding bind(View view) {
        Spinner spinner;
        ImageView imageView;
        View view2;
        Switch switch_;
        Switch switch_2;
        Spinner spinner2;
        LinearLayout linearLayout;
        TextView textView;
        Switch switch_3;
        Spinner spinner3;
        LinearLayout linearLayout2;
        RelativeLayout relativeLayout;
        Button button;
        Switch switch_4;
        Switch switch_5;
        LinearLayout linearLayout3;
        Button button2;
        RelativeLayout relativeLayout2;
        Switch switch_6;
        LinearLayout linearLayout4;
        TextView textView2;
        Button button3;
        Switch switch_7;
        RelativeLayout relativeLayout3;
        Switch switch_8;
        int n = 2131361793;
        Switch switch_9 = (Switch)ViewBindings.findChildViewById((View)view, (int)n);
        if (switch_9 != null && (spinner3 = (Spinner)ViewBindings.findChildViewById((View)view, (int)(n = 2131361794))) != null && (linearLayout4 = (LinearLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131361795))) != null && (button2 = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361796))) != null && (view2 = ViewBindings.findChildViewById((View)view, (int)(n = 2131361808))) != null && (switch_6 = (Switch)ViewBindings.findChildViewById((View)view, (int)(n = 2131361810))) != null && (switch_ = (Switch)ViewBindings.findChildViewById((View)view, (int)(n = 2131361811))) != null && (spinner2 = (Spinner)ViewBindings.findChildViewById((View)view, (int)(n = 2131361812))) != null && (switch_3 = (Switch)ViewBindings.findChildViewById((View)view, (int)(n = 2131361814))) != null && (switch_2 = (Switch)ViewBindings.findChildViewById((View)view, (int)(n = 2131361815))) != null && (switch_5 = (Switch)ViewBindings.findChildViewById((View)view, (int)(n = 2131361816))) != null && (switch_4 = (Switch)ViewBindings.findChildViewById((View)view, (int)(n = 2131361817))) != null && (relativeLayout3 = (RelativeLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131361820))) != null && (linearLayout2 = (LinearLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131361821))) != null && (linearLayout = (LinearLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131361822))) != null && (button = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361823))) != null && (spinner = (Spinner)ViewBindings.findChildViewById((View)view, (int)(n = 2131361829))) != null && (switch_7 = (Switch)ViewBindings.findChildViewById((View)view, (int)(n = 2131361851))) != null && (linearLayout3 = (LinearLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131361852))) != null && (button3 = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361853))) != null && (switch_8 = (Switch)ViewBindings.findChildViewById((View)view, (int)(n = 2131361854))) != null && (textView2 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361973))) != null && (imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362042))) != null && (relativeLayout = (RelativeLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362094))) != null && (relativeLayout2 = (RelativeLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362213))) != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362326))) != null) {
            FloatLogoBinding floatLogoBinding = new FloatLogoBinding((RelativeLayout)view, switch_9, spinner3, linearLayout4, button2, view2, switch_6, switch_, spinner2, switch_3, switch_2, switch_5, switch_4, relativeLayout3, linearLayout2, linearLayout, button, spinner, switch_7, linearLayout3, button3, switch_8, textView2, imageView, relativeLayout, relativeLayout2, textView);
            return floatLogoBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static FloatLogoBinding inflate(LayoutInflater layoutInflater) {
        return FloatLogoBinding.inflate(layoutInflater, null, false);
    }

    public static FloatLogoBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558454, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return FloatLogoBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

