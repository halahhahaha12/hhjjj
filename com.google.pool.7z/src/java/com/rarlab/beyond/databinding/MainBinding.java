/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class MainBinding
implements ViewBinding {
    private MainBinding(RelativeLayout relativeLayout, Button button, ScrollView scrollView, TextView textView, RelativeLayout relativeLayout2, Button button2, ImageView imageView, EditText editText, TextView textView2, EditText editText2) {
    }

    public static MainBinding bind(View view) {
        RelativeLayout relativeLayout;
        TextView textView;
        EditText editText;
        ImageView imageView;
        Button button;
        EditText editText2;
        ScrollView scrollView;
        TextView textView2;
        int n = 2131361809;
        Button button2 = (Button)ViewBindings.findChildViewById((View)view, (int)n);
        if (button2 != null && (scrollView = (ScrollView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361840))) != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362045))) != null && (relativeLayout = (RelativeLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362105))) != null && (button = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131362106))) != null && (imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362107))) != null && (editText2 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362198))) != null && (textView2 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362326))) != null && (editText = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362347))) != null) {
            MainBinding mainBinding = new MainBinding((RelativeLayout)view, button2, scrollView, textView, relativeLayout, button, imageView, editText2, textView2, editText);
            return mainBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static MainBinding inflate(LayoutInflater layoutInflater) {
        return MainBinding.inflate(layoutInflater, null, false);
    }

    public static MainBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558462, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return MainBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

