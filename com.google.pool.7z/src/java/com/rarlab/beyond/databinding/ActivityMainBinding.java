/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  androidx.constraintlayout.widget.Guideline
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Guideline;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.airbnb.lottie.LottieAnimationView;

public final class ActivityMainBinding
implements ViewBinding {
    public final Button addAppButton;
    public final Button containerButton;
    public final Guideline guideline5;
    public final Guideline guideline6;
    public final Guideline guideline7;
    public final LottieAnimationView lottieAnimationView;
    public final ConstraintLayout mainVertical;
    private final ConstraintLayout rootView;

    private ActivityMainBinding(ConstraintLayout constraintLayout, Button button, Button button2, Guideline guideline, Guideline guideline2, Guideline guideline3, LottieAnimationView lottieAnimationView, ConstraintLayout constraintLayout2) {
        this.rootView = constraintLayout;
        this.addAppButton = button;
        this.containerButton = button2;
        this.guideline5 = guideline;
        this.guideline6 = guideline2;
        this.guideline7 = guideline3;
        this.lottieAnimationView = lottieAnimationView;
        this.mainVertical = constraintLayout2;
    }

    public static ActivityMainBinding bind(View view) {
        Button button;
        LottieAnimationView lottieAnimationView;
        Guideline guideline;
        Guideline guideline2;
        Guideline guideline3;
        int n = 2131361912;
        Button button2 = (Button)ViewBindings.findChildViewById((View)view, (int)n);
        if (button2 != null && (button = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361980))) != null && (guideline3 = (Guideline)ViewBindings.findChildViewById((View)view, (int)(n = 2131362060))) != null && (guideline = (Guideline)ViewBindings.findChildViewById((View)view, (int)(n = 2131362061))) != null && (guideline2 = (Guideline)ViewBindings.findChildViewById((View)view, (int)(n = 2131362062))) != null && (lottieAnimationView = (LottieAnimationView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362108))) != null) {
            ConstraintLayout constraintLayout = (ConstraintLayout)view;
            ActivityMainBinding activityMainBinding = new ActivityMainBinding(constraintLayout, button2, button, guideline3, guideline, guideline2, lottieAnimationView, constraintLayout);
            return activityMainBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivityMainBinding inflate(LayoutInflater layoutInflater) {
        return ActivityMainBinding.inflate(layoutInflater, null, false);
    }

    public static ActivityMainBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558431, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivityMainBinding.bind(view);
    }

    public ConstraintLayout getRoot() {
        return this.rootView;
    }
}

