/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class FragmentMainBinding
implements ViewBinding {
    private final LinearLayout rootView;
    public final RecyclerView rvApps;

    private FragmentMainBinding(LinearLayout linearLayout, RecyclerView recyclerView) {
        this.rootView = linearLayout;
        this.rvApps = recyclerView;
    }

    public static FragmentMainBinding bind(View view) {
        RecyclerView recyclerView = (RecyclerView)ViewBindings.findChildViewById((View)view, (int)2131362223);
        if (recyclerView != null) {
            return new FragmentMainBinding((LinearLayout)view, recyclerView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(2131362223)));
    }

    public static FragmentMainBinding inflate(LayoutInflater layoutInflater) {
        return FragmentMainBinding.inflate(layoutInflater, null, false);
    }

    public static FragmentMainBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558457, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return FragmentMainBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

