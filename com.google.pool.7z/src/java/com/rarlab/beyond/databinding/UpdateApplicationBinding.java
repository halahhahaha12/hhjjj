/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  androidx.viewbinding.ViewBinding
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 */
package com.rarlab.beyond.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.viewbinding.ViewBinding;
import java.util.Objects;

public final class UpdateApplicationBinding
implements ViewBinding {
    private final LinearLayout rootView;

    private UpdateApplicationBinding(LinearLayout linearLayout) {
        this.rootView = linearLayout;
    }

    public static UpdateApplicationBinding bind(View view) {
        Objects.requireNonNull((Object)view, (String)"rootView");
        return new UpdateApplicationBinding((LinearLayout)view);
    }

    public static UpdateApplicationBinding inflate(LayoutInflater layoutInflater) {
        return UpdateApplicationBinding.inflate(layoutInflater, null, false);
    }

    public static UpdateApplicationBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558533, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return UpdateApplicationBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

