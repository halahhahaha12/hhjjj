/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class ActivityRegisterBinding
implements ViewBinding {
    public final Button BackButton;
    public final RelativeLayout ChildLayout2;
    public final Button RegisterButton;
    public final ScrollView ScrollBar;
    public final RelativeLayout loadingPanel;
    public final EditText password;
    public final EditText passwordConfirmation;
    private final RelativeLayout rootView;
    public final EditText securityAnswer;
    public final EditText securityQuestion;
    public final EditText subKey;
    public final TextView titleBar;
    public final EditText usernameInput;

    private ActivityRegisterBinding(RelativeLayout relativeLayout, Button button, RelativeLayout relativeLayout2, Button button2, ScrollView scrollView, RelativeLayout relativeLayout3, EditText editText, EditText editText2, EditText editText3, EditText editText4, EditText editText5, TextView textView, EditText editText6) {
        this.rootView = relativeLayout;
        this.BackButton = button;
        this.ChildLayout2 = relativeLayout2;
        this.RegisterButton = button2;
        this.ScrollBar = scrollView;
        this.loadingPanel = relativeLayout3;
        this.password = editText;
        this.passwordConfirmation = editText2;
        this.securityAnswer = editText3;
        this.securityQuestion = editText4;
        this.subKey = editText5;
        this.titleBar = textView;
        this.usernameInput = editText6;
    }

    public static ActivityRegisterBinding bind(View view) {
        EditText editText;
        RelativeLayout relativeLayout;
        RelativeLayout relativeLayout2;
        ScrollView scrollView;
        EditText editText2;
        EditText editText3;
        TextView textView;
        EditText editText4;
        Button button;
        EditText editText5;
        EditText editText6;
        int n = 2131361799;
        Button button2 = (Button)ViewBindings.findChildViewById((View)view, (int)n);
        if (button2 != null && (relativeLayout = (RelativeLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131361807))) != null && (button = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361832))) != null && (scrollView = (ScrollView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361840))) != null && (relativeLayout2 = (RelativeLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362105))) != null && (editText3 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362198))) != null && (editText = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362199))) != null && (editText5 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362244))) != null && (editText4 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362245))) != null && (editText2 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362286))) != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362326))) != null && (editText6 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362347))) != null) {
            ActivityRegisterBinding activityRegisterBinding = new ActivityRegisterBinding((RelativeLayout)view, button2, relativeLayout, button, scrollView, relativeLayout2, editText3, editText, editText5, editText4, editText2, textView, editText6);
            return activityRegisterBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivityRegisterBinding inflate(LayoutInflater layoutInflater) {
        return ActivityRegisterBinding.inflate(layoutInflater, null, false);
    }

    public static ActivityRegisterBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558433, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivityRegisterBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

