/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class FloatViewBinding
implements ViewBinding {
    public final ImageView imageView;
    public final LinearLayout layOut;
    private final LinearLayout rootView;

    private FloatViewBinding(LinearLayout linearLayout, ImageView imageView, LinearLayout linearLayout2) {
        this.rootView = linearLayout;
        this.imageView = imageView;
        this.layOut = linearLayout2;
    }

    public static FloatViewBinding bind(View view) {
        ImageView imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)2131362077);
        if (imageView != null) {
            LinearLayout linearLayout = (LinearLayout)view;
            return new FloatViewBinding(linearLayout, imageView, linearLayout);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(2131362077)));
    }

    public static FloatViewBinding inflate(LayoutInflater layoutInflater) {
        return FloatViewBinding.inflate(layoutInflater, null, false);
    }

    public static FloatViewBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558455, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return FloatViewBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

