/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class ActivityModulesBinding
implements ViewBinding {
    public final TextView ChetoStatusText;
    public final Button LoadButton;
    public final Button SettingsButton;
    public final Button UnloadButton;
    public final TextView UpdateDateText;
    public final RelativeLayout loadingPanel;
    public final TextView moduleText;
    private final RelativeLayout rootView;
    public final ScrollView scroll;
    public final TextView titleBar;

    private ActivityModulesBinding(RelativeLayout relativeLayout, TextView textView, Button button, Button button2, Button button3, TextView textView2, RelativeLayout relativeLayout2, TextView textView3, ScrollView scrollView, TextView textView4) {
        this.rootView = relativeLayout;
        this.ChetoStatusText = textView;
        this.LoadButton = button;
        this.SettingsButton = button2;
        this.UnloadButton = button3;
        this.UpdateDateText = textView2;
        this.loadingPanel = relativeLayout2;
        this.moduleText = textView3;
        this.scroll = scrollView;
        this.titleBar = textView4;
    }

    public static ActivityModulesBinding bind(View view) {
        TextView textView;
        Button button;
        ScrollView scrollView;
        Button button2;
        TextView textView2;
        Button button3;
        RelativeLayout relativeLayout;
        TextView textView3;
        int n = 2131361805;
        TextView textView4 = (TextView)ViewBindings.findChildViewById((View)view, (int)n);
        if (textView4 != null && (button = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361818))) != null && (button2 = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361843))) != null && (button3 = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361847))) != null && (textView2 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361848))) != null && (relativeLayout = (RelativeLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362105))) != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362136))) != null && (scrollView = (ScrollView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362229))) != null && (textView3 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362326))) != null) {
            ActivityModulesBinding activityModulesBinding = new ActivityModulesBinding((RelativeLayout)view, textView4, button, button2, button3, textView2, relativeLayout, textView, scrollView, textView3);
            return activityModulesBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivityModulesBinding inflate(LayoutInflater layoutInflater) {
        return ActivityModulesBinding.inflate(layoutInflater, null, false);
    }

    public static ActivityModulesBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558432, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivityModulesBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

