/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class ToastLayoutBinding
implements ViewBinding {
    public final ImageView icon;
    private final LinearLayout rootView;
    public final TextView text;

    private ToastLayoutBinding(LinearLayout linearLayout, ImageView imageView, TextView textView) {
        this.rootView = linearLayout;
        this.icon = imageView;
        this.text = textView;
    }

    public static ToastLayoutBinding bind(View view) {
        TextView textView;
        int n = 2131362071;
        ImageView imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)n);
        if (imageView != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362308))) != null) {
            return new ToastLayoutBinding((LinearLayout)view, imageView, textView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ToastLayoutBinding inflate(LayoutInflater layoutInflater) {
        return ToastLayoutBinding.inflate(layoutInflater, null, false);
    }

    public static ToastLayoutBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558532, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ToastLayoutBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

