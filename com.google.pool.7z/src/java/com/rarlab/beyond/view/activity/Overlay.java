/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.Canvas
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.IBinder
 *  android.view.Display
 *  android.view.View
 *  android.view.ViewConfiguration
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  java.lang.Class
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Process
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 */
package com.rarlab.beyond.view.activity;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.os.Build;
import android.os.IBinder;
import android.view.Display;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import com.rarlab.beyond.view.activity.ESPView;
import com.rarlab.beyond.view.activity.FloatLogo;

public class Overlay
extends Service {
    private static Overlay Instance;
    static Context ctx;
    View mFloatingView;
    ESPView overlayView;
    Process process;
    WindowManager windowManager;

    private native void Close();

    private void DrawCanvas() {
        WindowManager windowManager;
        int n = Build.VERSION.SDK_INT >= 26 ? 2038 : 2006;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, 0, this.getNavigationBarHeight(), n, 1304, 1);
        if (Build.VERSION.SDK_INT >= 28) {
            layoutParams.layoutInDisplayCutoutMode = 1;
        }
        layoutParams.gravity = 8388659;
        layoutParams.x = 0;
        layoutParams.y = 0;
        this.windowManager = windowManager = (WindowManager)this.getSystemService("window");
        windowManager.addView((View)this.overlayView, (ViewGroup.LayoutParams)layoutParams);
    }

    public static native void DrawOn(ESPView var0, Canvas var1, boolean var2);

    public static void Stop(Context context) {
        context.stopService(new Intent(context, Overlay.class));
        context.stopService(new Intent(context, FloatLogo.class));
    }

    public static void draw(ESPView eSPView, Canvas canvas) {
        Overlay.DrawOn(eSPView, canvas, Overlay.isLandscapeLeftOrRight());
    }

    private int getNavigationBarHeight() {
        boolean bl = ViewConfiguration.get((Context)this).hasPermanentMenuKey();
        int n = this.getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        if (n > 0 && !bl) {
            return this.getResources().getDimensionPixelSize(n);
        }
        return 0;
    }

    private static boolean isLandscapeLeftOrRight() {
        return ((WindowManager)ctx.getSystemService("window")).getDefaultDisplay().getRotation() == 1;
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        ctx = this;
        this.windowManager = (WindowManager)this.getSystemService("window");
        this.overlayView = new ESPView(ctx);
        this.DrawCanvas();
    }

    public void onDestroy() {
        super.onDestroy();
        this.Close();
        if (this.overlayView != null) {
            ((WindowManager)ctx.getSystemService("window")).removeView((View)this.overlayView);
            this.overlayView = null;
        }
        this.stopSelf();
        System.exit((int)-1);
    }

    public void onTaskRemoved(Intent intent) {
        this.stopSelf();
        try {
            Thread.sleep((long)100L);
        }
        catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }
}

