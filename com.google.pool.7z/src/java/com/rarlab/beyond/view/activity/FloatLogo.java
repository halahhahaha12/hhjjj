/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.IBinder
 *  android.view.GestureDetector
 *  android.view.GestureDetector$OnGestureListener
 *  android.view.LayoutInflater
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.Switch
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 */
package com.rarlab.beyond.view.activity;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Switch;
import android.widget.TextView;
import com.rarlab.beyond.view.activity.SingleTapConfirm;

public class FloatLogo
extends Service
implements View.OnClickListener {
    private static FloatLogo Instance;
    private Switch adBlock;
    private Spinner autoAction;
    private TextView closeButton;
    private Switch drawPrediction;
    private Switch drawShotState;
    private Spinner eightBallPoolTarget;
    private Switch findBestShot;
    private Switch freezeLines;
    private View gMainTab;
    private Button gMainTabButton;
    private View gMiscTab;
    private Button gMiscTabButton;
    private View gVisualsTab;
    private Button gVisualsTabButton;
    private Switch humanizedAngle;
    private Switch humanizedPower;
    private View logoView;
    private View mFloatingView;
    private WindowManager mWindowManager;
    private View mainView;
    private Spinner pocketNominationMode;
    private Switch useFullPowerAtBreak;
    private Switch wideGuideLine;

    private int getIntValue(String string2) {
        return this.getSharedPreferences("features", 0).getInt(string2, 0);
    }

    private boolean getValue(String string2) {
        return this.getSharedPreferences("features", 0).getBoolean(string2, false);
    }

    private void load() {
        this.closeButton = (TextView)this.mFloatingView.findViewById(2131361973);
        this.gMainTabButton = (Button)this.mFloatingView.findViewById(2131361796);
        this.gVisualsTabButton = (Button)this.mFloatingView.findViewById(2131361853);
        this.gMiscTabButton = (Button)this.mFloatingView.findViewById(2131361823);
        this.gMainTab = this.mFloatingView.findViewById(2131361795);
        this.gVisualsTab = this.mFloatingView.findViewById(2131361852);
        this.gMiscTab = this.mFloatingView.findViewById(2131361822);
        Object[] arrobject = new String[]{"none", "auto aim", "auto play"};
        this.autoAction = (Spinner)this.mFloatingView.findViewById(2131361794);
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, arrobject);
        arrayAdapter.setDropDownViewResource(17367049);
        this.autoAction.setAdapter((SpinnerAdapter)arrayAdapter);
        this.autoAction.setSelection(0);
        Object[] arrobject2 = new String[]{"stripe yellow ball", "anything"};
        this.eightBallPoolTarget = (Spinner)this.mFloatingView.findViewById(2131361812);
        ArrayAdapter arrayAdapter2 = new ArrayAdapter((Context)this, 17367043, arrobject2);
        arrayAdapter.setDropDownViewResource(17367049);
        this.eightBallPoolTarget.setAdapter((SpinnerAdapter)arrayAdapter2);
        this.eightBallPoolTarget.setSelection(0);
        Object[] arrobject3 = new String[]{"auto", "off"};
        this.pocketNominationMode = (Spinner)this.mFloatingView.findViewById(2131361829);
        ArrayAdapter arrayAdapter3 = new ArrayAdapter((Context)this, 17367043, arrobject3);
        arrayAdapter.setDropDownViewResource(17367049);
        this.pocketNominationMode.setAdapter((SpinnerAdapter)arrayAdapter3);
        this.pocketNominationMode.setSelection(0);
        this.findBestShot = (Switch)this.mFloatingView.findViewById(2131361814);
        this.useFullPowerAtBreak = (Switch)this.mFloatingView.findViewById(2131361851);
        this.humanizedPower = (Switch)this.mFloatingView.findViewById(2131361817);
        this.humanizedAngle = (Switch)this.mFloatingView.findViewById(2131361816);
        this.drawPrediction = (Switch)this.mFloatingView.findViewById(2131361810);
        this.drawShotState = (Switch)this.mFloatingView.findViewById(2131361811);
        this.freezeLines = (Switch)this.mFloatingView.findViewById(2131361815);
        this.wideGuideLine = (Switch)this.mFloatingView.findViewById(2131361854);
        this.adBlock = (Switch)this.mFloatingView.findViewById(2131361793);
        this.closeButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                FloatLogo.this.mainView.setVisibility(8);
                FloatLogo.this.logoView.setVisibility(0);
            }
        });
        this.gMainTabButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                FloatLogo.this.gMainTab.setVisibility(0);
                FloatLogo.this.gVisualsTab.setVisibility(8);
                FloatLogo.this.gMiscTab.setVisibility(8);
            }
        });
        this.gVisualsTabButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                FloatLogo.this.gMainTab.setVisibility(8);
                FloatLogo.this.gVisualsTab.setVisibility(0);
                FloatLogo.this.gMiscTab.setVisibility(8);
            }
        });
        this.gMiscTabButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                FloatLogo.this.gMainTab.setVisibility(8);
                FloatLogo.this.gVisualsTab.setVisibility(8);
                FloatLogo.this.gMiscTab.setVisibility(0);
            }
        });
        this.drawPrediction.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((Object)floatLogo.drawPrediction.getText()), FloatLogo.this.drawPrediction.isChecked());
                FloatLogo floatLogo2 = FloatLogo.this;
                floatLogo2.SettingValue(0, floatLogo2.drawPrediction.isChecked());
            }
        });
        this.drawShotState.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((Object)floatLogo.drawShotState.getText()), FloatLogo.this.drawShotState.isChecked());
                FloatLogo floatLogo2 = FloatLogo.this;
                floatLogo2.SettingValue(1, floatLogo2.drawShotState.isChecked());
            }
        });
        this.wideGuideLine.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((Object)floatLogo.wideGuideLine.getText()), FloatLogo.this.wideGuideLine.isChecked());
                FloatLogo floatLogo2 = FloatLogo.this;
                floatLogo2.SettingValue(2, floatLogo2.wideGuideLine.isChecked());
            }
        });
        this.adBlock.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((Object)floatLogo.adBlock.getText()), FloatLogo.this.adBlock.isChecked());
                FloatLogo floatLogo2 = FloatLogo.this;
                floatLogo2.SettingValue(3, floatLogo2.adBlock.isChecked());
            }
        });
        this.freezeLines.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((Object)floatLogo.freezeLines.getText()), FloatLogo.this.freezeLines.isChecked());
                FloatLogo floatLogo2 = FloatLogo.this;
                floatLogo2.SettingValue(4, floatLogo2.freezeLines.isChecked());
            }
        });
        this.findBestShot.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((Object)floatLogo.findBestShot.getText()), FloatLogo.this.findBestShot.isChecked());
                FloatLogo floatLogo2 = FloatLogo.this;
                floatLogo2.SettingValue(5, floatLogo2.findBestShot.isChecked());
            }
        });
        this.useFullPowerAtBreak.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((Object)floatLogo.useFullPowerAtBreak.getText()), FloatLogo.this.useFullPowerAtBreak.isChecked());
                FloatLogo floatLogo2 = FloatLogo.this;
                floatLogo2.SettingValue(6, floatLogo2.useFullPowerAtBreak.isChecked());
            }
        });
        this.humanizedPower.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((Object)floatLogo.humanizedPower.getText()), FloatLogo.this.humanizedPower.isChecked());
                FloatLogo floatLogo2 = FloatLogo.this;
                floatLogo2.SettingValue(7, floatLogo2.humanizedPower.isChecked());
            }
        });
        this.humanizedAngle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((Object)floatLogo.humanizedAngle.getText()), FloatLogo.this.humanizedAngle.isChecked());
                FloatLogo floatLogo2 = FloatLogo.this;
                floatLogo2.SettingValue(8, floatLogo2.humanizedAngle.isChecked());
            }
        });
        this.autoAction.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((int)floatLogo.autoAction.getId()), FloatLogo.this.autoAction.getSelectedItemPosition());
                FloatLogo.this.SettingIntValue(100, n);
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.eightBallPoolTarget.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((int)floatLogo.eightBallPoolTarget.getId()), FloatLogo.this.eightBallPoolTarget.getSelectedItemPosition());
                FloatLogo.this.SettingIntValue(101, n);
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.pocketNominationMode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                FloatLogo floatLogo = FloatLogo.this;
                floatLogo.setValue(String.valueOf((int)floatLogo.pocketNominationMode.getId()), FloatLogo.this.pocketNominationMode.getSelectedItemPosition());
                FloatLogo.this.SettingIntValue(102, n);
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        Switch switch_ = this.drawPrediction;
        switch_.setChecked(this.getValue(switch_.getText().toString()));
        Switch switch_2 = this.drawShotState;
        switch_2.setChecked(this.getValue(switch_2.getText().toString()));
        Switch switch_3 = this.wideGuideLine;
        switch_3.setChecked(this.getValue(switch_3.getText().toString()));
        Switch switch_4 = this.adBlock;
        switch_4.setChecked(this.getValue(switch_4.getText().toString()));
        Switch switch_5 = this.freezeLines;
        switch_5.setChecked(this.getValue(switch_5.getText().toString()));
        Spinner spinner = this.autoAction;
        spinner.setSelection(this.getIntValue(String.valueOf((int)spinner.getId())));
        Spinner spinner2 = this.eightBallPoolTarget;
        spinner2.setSelection(this.getIntValue(String.valueOf((int)spinner2.getId())));
        Spinner spinner3 = this.pocketNominationMode;
        spinner3.setSelection(this.getIntValue(String.valueOf((int)spinner3.getId())));
        Switch switch_6 = this.findBestShot;
        switch_6.setChecked(this.getValue(switch_6.getText().toString()));
        Switch switch_7 = this.useFullPowerAtBreak;
        switch_7.setChecked(this.getValue(switch_7.getText().toString()));
        Switch switch_8 = this.humanizedPower;
        switch_8.setChecked(this.getValue(switch_8.getText().toString()));
        Switch switch_9 = this.humanizedAngle;
        switch_9.setChecked(this.getValue(switch_9.getText().toString()));
        this.SettingValue(0, this.drawPrediction.isChecked());
        this.SettingValue(1, this.drawShotState.isChecked());
        this.SettingValue(2, this.wideGuideLine.isChecked());
        this.SettingValue(3, this.adBlock.isChecked());
        this.SettingValue(4, this.freezeLines.isChecked());
        this.SettingValue(5, this.humanizedPower.isChecked());
        this.SettingValue(6, this.humanizedAngle.isChecked());
        this.SettingIntValue(100, this.autoAction.getSelectedItemPosition());
        this.SettingIntValue(101, this.eightBallPoolTarget.getSelectedItemPosition());
        this.SettingIntValue(102, this.pocketNominationMode.getSelectedItemPosition());
    }

    private void setValue(String string2, int n) {
        SharedPreferences.Editor editor = this.getSharedPreferences("features", 0).edit();
        editor.putInt(string2, n);
        editor.apply();
    }

    private void setValue(String string2, boolean bl) {
        SharedPreferences.Editor editor = this.getSharedPreferences("features", 0).edit();
        editor.putBoolean(string2, bl);
        editor.apply();
    }

    public native void SettingIntValue(int var1, int var2);

    public native void SettingValue(int var1, boolean var2);

    void createOver() {
        WindowManager windowManager;
        this.mFloatingView = LayoutInflater.from((Context)this).inflate(2131558454, null);
        int n = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
        final WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, n, 8, 1);
        this.mWindowManager = windowManager = (WindowManager)this.getSystemService("window");
        windowManager.addView(this.mFloatingView, (ViewGroup.LayoutParams)layoutParams);
        final GestureDetector gestureDetector = new GestureDetector((Context)this, (GestureDetector.OnGestureListener)new SingleTapConfirm());
        this.mFloatingView.findViewById(2131362213).setOnTouchListener(new View.OnTouchListener(){
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (gestureDetector.onTouchEvent(motionEvent)) {
                    FloatLogo.this.mainView.setVisibility(0);
                    FloatLogo.this.logoView.setVisibility(8);
                    return true;
                }
                int n = motionEvent.getAction();
                if (n != 0) {
                    if (n != 2) {
                        return false;
                    }
                    layoutParams.x = this.initialX + (int)(motionEvent.getRawX() - this.initialTouchX);
                    layoutParams.y = this.initialY + (int)(motionEvent.getRawY() - this.initialTouchY);
                    FloatLogo.this.mWindowManager.updateViewLayout(FloatLogo.this.mFloatingView, (ViewGroup.LayoutParams)layoutParams);
                    return true;
                }
                this.initialX = layoutParams.x;
                this.initialY = layoutParams.y;
                this.initialTouchX = motionEvent.getRawX();
                this.initialTouchY = motionEvent.getRawY();
                return true;
            }
        });
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onClick(View view) {
    }

    public void onCreate() {
        super.onCreate();
        Instance = this;
        this.createOver();
        this.logoView = this.mFloatingView.findViewById(2131362213);
        this.mainView = this.mFloatingView.findViewById(2131361820);
        this.load();
    }

    public void onDestroy() {
        super.onDestroy();
        View view = this.mFloatingView;
        if (view != null) {
            this.mWindowManager.removeView(view);
        }
        this.stopSelf();
        System.exit((int)-1);
    }

    public void onTaskRemoved(Intent intent) {
        this.stopSelf();
        try {
            Thread.sleep((long)100L);
        }
        catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }

}

