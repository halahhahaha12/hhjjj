/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.os.Bundle
 *  android.os.Process
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.text.Editable
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.EditText
 *  android.widget.TextView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 */
package com.rarlab.beyond.view.activity;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Process;
import android.provider.Settings;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.rarlab.beyond.view.activity.FPActivity;
import com.rarlab.beyond.view.activity.ModulesActivity;
import com.rarlab.beyond.view.activity.RegisterActivity;

public class MainActivity
extends Activity
implements View.OnClickListener {
    private static boolean isAnyRequestProcessing;

    static {
        System.loadLibrary((String)"main");
        isAnyRequestProcessing = false;
    }

    private String HGASDYHASDASDASD() {
        return Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"android_id");
    }

    private native void XXX(String var1);

    private native String XXXX(String var1, String var2);

    private void getCredentials() {
        SharedPreferences sharedPreferences = this.getSharedPreferences("credentials", 0);
        String string2 = sharedPreferences.getString("username", null);
        String string3 = sharedPreferences.getString("password", null);
        TextView textView = (TextView)this.findViewById(2131362347);
        TextView textView2 = (TextView)this.findViewById(2131362198);
        textView.setText((CharSequence)string2);
        textView2.setText((CharSequence)string3);
    }

    private boolean isNetworkAvailable() {
        NetworkInfo networkInfo = ((ConnectivityManager)this.getSystemService("connectivity")).getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }

    private boolean isPackageInstalled(Context context, String string2) {
        try {
            context.getPackageManager().getApplicationInfo(string2, 0);
            return true;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            return false;
        }
    }

    private void saveCredentials(String string2, String string3) {
        SharedPreferences.Editor editor = this.getSharedPreferences("credentials", 0).edit();
        editor.putString("username", string2);
        editor.putString("password", string3);
        editor.apply();
    }

    void createOver() {
        TextView textView = (TextView)this.findViewById(2131362045);
        textView.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Intent intent = new Intent((Context)MainActivity.this, FPActivity.class);
                MainActivity.this.startActivity(intent);
            }
        });
        textView.getLeft();
    }

    public void onClick(View view) {
        int n = view.getId();
        if (n != 2131361809) {
            if (n != 2131362106) {
                return;
            }
            if (isAnyRequestProcessing) {
                Toast.makeText((Context)this, (CharSequence)"You're doing it too fast!", (int)0).show();
                return;
            }
            EditText editText = (EditText)this.findViewById(2131362347);
            EditText editText2 = (EditText)this.findViewById(2131362198);
            final String string2 = editText.getText().toString();
            final String string3 = editText2.getText().toString();
            isAnyRequestProcessing = true;
            this.findViewById(2131362105).setVisibility(0);
            new Thread(new Runnable(){

                public void run() {
                    final MainActivity mainActivity = MainActivity.this;
                    final String string22 = mainActivity.XXXX(string2, string3);
                    try {
                        Thread.sleep((long)1000L);
                    }
                    catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                    isAnyRequestProcessing = false;
                    if (string22.length() > 0) {
                        mainActivity.runOnUiThread(new Runnable(){

                            public void run() {
                                MainActivity.this.findViewById(2131362105).setVisibility(8);
                                Toast.makeText((Context)mainActivity, (CharSequence)string22, (int)0).show();
                            }
                        });
                        if (string22.equals((Object)"Success")) {
                            MainActivity.this.saveCredentials(string2, string3);
                            Intent intent = new Intent((Context)mainActivity, ModulesActivity.class);
                            MainActivity.this.startActivity(intent);
                        }
                    }
                }

            }).start();
            return;
        }
        this.startActivity(new Intent((Context)this, RegisterActivity.class));
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131558462);
        this.findViewById(2131362105).setVisibility(8);
        this.getCredentials();
        this.createOver();
        if (!this.isNetworkAvailable()) {
            Toast.makeText((Context)this, (CharSequence)"You must have an internet connection", (int)0).show();
            this.finishAffinity();
        }
        new Thread(new Runnable(){

            public void run() {
                MainActivity.this.isPackageInstalled((Context)this, "com.facebook.katana");
            }
        }).start();
        this.XXX(this.HGASDYHASDASDASD());
    }

    public void onDestroy() {
        super.onDestroy();
        Process.killProcess((int)Process.myPid());
    }

}

