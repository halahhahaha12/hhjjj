/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.GestureDetector
 *  android.view.GestureDetector$SimpleOnGestureListener
 *  android.view.MotionEvent
 */
package com.rarlab.beyond.view.activity;

import android.view.GestureDetector;
import android.view.MotionEvent;

class SingleTapConfirm
extends GestureDetector.SimpleOnGestureListener {
    SingleTapConfirm() {
    }

    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return true;
    }
}

