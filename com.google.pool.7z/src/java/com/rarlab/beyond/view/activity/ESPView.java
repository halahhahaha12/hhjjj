/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.Paint$Style
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.util.AttributeSet
 *  android.view.View
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.text.SimpleDateFormat
 *  java.util.Date
 *  java.util.Locale
 */
package com.rarlab.beyond.view.activity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.view.View;
import com.rarlab.beyond.view.activity.Overlay;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ESPView
extends View
implements Runnable {
    static long sleepTime;
    int FPS = 60;
    SimpleDateFormat formatter;
    Paint mFilledPaint;
    Paint mStrokePaint;
    Paint mTextPaint;
    Thread mThread;
    Date time;

    public ESPView(Context context) {
        Thread thread;
        super(context, null, 0);
        this.InitializePaints();
        this.setFocusableInTouchMode(false);
        this.setBackgroundColor(0);
        this.time = new Date();
        this.formatter = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        sleepTime = 1000 / this.FPS;
        this.mThread = thread = new Thread((Runnable)this);
        thread.start();
    }

    public static void ChangeFps(int n) {
        sleepTime = 1000 / (n + 20);
    }

    public void ClearCanvas(Canvas canvas) {
        canvas.drawColor(0, PorterDuff.Mode.CLEAR);
    }

    public void DrawCircle(Canvas canvas, int n, int n2, int n3, int n4, float f, float f2, float f3) {
        this.mStrokePaint.setColor(Color.rgb((int)n2, (int)n3, (int)n4));
        this.mStrokePaint.setAlpha(n);
        this.mStrokePaint.setStyle(Paint.Style.STROKE);
        this.mStrokePaint.setStrokeWidth(8.0f);
        canvas.drawCircle(f, f2, f3, this.mStrokePaint);
    }

    public void DrawFilledCircle(Canvas canvas, int n, int n2, int n3, int n4, float f, float f2, float f3) {
        this.mFilledPaint.setColor(Color.rgb((int)n2, (int)n3, (int)n4));
        this.mFilledPaint.setAlpha(n);
        this.mFilledPaint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(f, f2, f3, this.mFilledPaint);
    }

    public void DrawFilledRect(Canvas canvas, int n, int n2, int n3, int n4, float f, float f2, float f3, float f4) {
        this.mFilledPaint.setColor(Color.rgb((int)n2, (int)n3, (int)n4));
        this.mFilledPaint.setAlpha(n);
        canvas.drawRect(f, f2, f3, f4, this.mFilledPaint);
    }

    public void DrawLine(Canvas canvas, int n, int n2, int n3, int n4, float f, float f2, float f3, float f4, float f5) {
        this.mStrokePaint.setColor(Color.rgb((int)n2, (int)n3, (int)n4));
        this.mStrokePaint.setAlpha(n);
        this.mStrokePaint.setStrokeWidth(f);
        canvas.drawLine(f2, f3, f4, f5, this.mStrokePaint);
    }

    public void DrawRect(Canvas canvas, int n, int n2, int n3, int n4, float f, float f2, float f3, float f4, float f5) {
        this.mStrokePaint.setStrokeWidth(f);
        this.mStrokePaint.setColor(Color.rgb((int)n2, (int)n3, (int)n4));
        this.mStrokePaint.setAlpha(n);
        canvas.drawRect(f2, f3, f4, f5, this.mStrokePaint);
    }

    public void DrawText(Canvas canvas, int n, int n2, int n3, int n4, String string2, float f, float f2, float f3) {
        this.mTextPaint.setARGB(n, n2, n3, n4);
        this.mTextPaint.setTextSize(f3);
        canvas.drawText(string2, f, f2, this.mTextPaint);
    }

    public void InitializePaints() {
        Paint paint;
        Paint paint2;
        Paint paint3;
        this.mStrokePaint = paint = new Paint();
        paint.setStyle(Paint.Style.STROKE);
        this.mStrokePaint.setAntiAlias(true);
        this.mStrokePaint.setColor(Color.rgb((int)0, (int)0, (int)0));
        this.mFilledPaint = paint2 = new Paint();
        paint2.setStyle(Paint.Style.FILL);
        this.mFilledPaint.setAntiAlias(true);
        this.mFilledPaint.setColor(Color.rgb((int)0, (int)0, (int)0));
        this.mTextPaint = paint3 = new Paint();
        paint3.setStyle(Paint.Style.FILL_AND_STROKE);
        this.mTextPaint.setAntiAlias(true);
        this.mTextPaint.setColor(Color.rgb((int)0, (int)0, (int)0));
        this.mTextPaint.setTextAlign(Paint.Align.CENTER);
        this.mTextPaint.setStrokeWidth(1.1f);
    }

    protected void onDraw(Canvas canvas) {
        if (canvas != null && this.getVisibility() == 0) {
            this.ClearCanvas(canvas);
            Overlay.draw(this, canvas);
        }
    }

    /*
     * Exception decompiling
     */
    public void run() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl30 : RETURN : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }
}

