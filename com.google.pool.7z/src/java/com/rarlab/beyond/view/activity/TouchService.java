/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accessibilityservice.AccessibilityService
 *  android.accessibilityservice.AccessibilityService$GestureResultCallback
 *  android.accessibilityservice.GestureDescription
 *  android.accessibilityservice.GestureDescription$Builder
 *  android.accessibilityservice.GestureDescription$StrokeDescription
 *  android.content.Intent
 *  android.graphics.Path
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.view.accessibility.AccessibilityEvent
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 */
package com.rarlab.beyond.view.activity;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

public class TouchService
extends AccessibilityService {
    private boolean canPress = true;
    private Handler mHandler = null;
    private IntervalRunnable mRunnable;

    private native int getX();

    private native int getY();

    private void handleTouches() {
        if (Build.VERSION.SDK_INT >= 24) {
            do {
                try {
                    Thread.sleep((long)100L);
                }
                catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
                if (!this.shouldSimulateClick()) continue;
                Path path = new Path();
                path.moveTo((float)this.getX(), (float)this.getY());
                GestureDescription.StrokeDescription strokeDescription = new GestureDescription.StrokeDescription(path, 0L, 10L);
                GestureDescription.Builder builder = new GestureDescription.Builder();
                builder.addStroke(strokeDescription);
                this.dispatchGesture(builder.build(), null, null);
            } while (true);
        }
    }

    private native boolean shouldSimulateClick();

    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        accessibilityEvent.getEventType();
    }

    public void onCreate() {
        super.onCreate();
        HandlerThread handlerThread = new HandlerThread("auto-handler");
        handlerThread.start();
        this.mHandler = new Handler(handlerThread.getLooper());
    }

    public void onDestroy() {
        super.onDestroy();
        this.stopSelf();
        System.exit((int)-1);
    }

    public void onInterrupt() {
    }

    protected void onServiceConnected() {
    }

    public int onStartCommand(Intent intent, int n, int n2) {
        if (intent != null && intent.getBooleanExtra("action", false)) {
            if (this.mRunnable == null) {
                this.mRunnable = new IntervalRunnable();
            }
            this.mHandler.postDelayed((Runnable)this.mRunnable, 1000L);
            this.mHandler.post((Runnable)this.mRunnable);
        }
        return 1;
    }

    public void onTaskRemoved(Intent intent) {
        this.stopSelf();
        try {
            Thread.sleep((long)100L);
        }
        catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }

    private class IntervalRunnable
    implements Runnable {
        private IntervalRunnable() {
        }

        public void run() {
            TouchService.this.handleTouches();
        }
    }

}

