/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.Editable
 *  android.view.View
 *  android.widget.EditText
 *  android.widget.Toast
 *  androidx.appcompat.app.AppCompatActivity
 *  java.lang.CharSequence
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 */
package com.rarlab.beyond.view.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity
extends AppCompatActivity {
    private static boolean isAnyRequestProcessing;

    private native String XXX(String var1, String var2, String var3, String var4, String var5);

    public void onClick(View view) {
        int n = view.getId();
        if (n != 2131361799) {
            if (n != 2131361832) {
                return;
            }
            if (isAnyRequestProcessing) {
                Toast.makeText((Context)this, (CharSequence)"You're doing it too fast!", (int)0).show();
                return;
            }
            EditText editText = (EditText)this.findViewById(2131362347);
            EditText editText2 = (EditText)this.findViewById(2131362198);
            EditText editText3 = (EditText)this.findViewById(2131362199);
            EditText editText4 = (EditText)this.findViewById(2131362245);
            EditText editText5 = (EditText)this.findViewById(2131362244);
            EditText editText6 = (EditText)this.findViewById(2131362286);
            final String string2 = editText.getText().toString();
            final String string3 = editText2.getText().toString();
            String string4 = editText3.getText().toString();
            final String string5 = editText4.getText().toString();
            final String string6 = editText5.getText().toString();
            final String string7 = editText6.getText().toString();
            if (!string3.equals((Object)string4)) {
                Toast.makeText((Context)this, (CharSequence)"Passwords do not match", (int)0).show();
                return;
            }
            isAnyRequestProcessing = true;
            this.findViewById(2131362105).setVisibility(0);
            Runnable runnable = new Runnable(){

                public void run() {
                    RegisterActivity registerActivity = RegisterActivity.this;
                    String string22 = registerActivity.XXX(string2, string3, string5, string6, string7);
                    try {
                        Thread.sleep((long)1000L);
                    }
                    catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                    isAnyRequestProcessing = false;
                    if (string22.length() > 0) {
                        registerActivity.runOnUiThread(new Runnable((Activity)registerActivity, string22){
                            final /* synthetic */ Activity val$activity;
                            final /* synthetic */ String val$result;
                            {
                                this.val$activity = activity;
                                this.val$result = string2;
                            }

                            public void run() {
                                RegisterActivity.this.findViewById(2131362105).setVisibility(8);
                                Toast.makeText((Context)this.val$activity, (CharSequence)this.val$result, (int)0).show();
                            }
                        });
                    }
                }

            };
            new Thread(runnable).start();
            return;
        }
        super.finish();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131558433);
        this.findViewById(2131362105).setVisibility(8);
    }

}

