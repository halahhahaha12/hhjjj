/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.Editable
 *  android.view.View
 *  android.widget.EditText
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.AppCompatActivity
 *  java.lang.CharSequence
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 */
package com.rarlab.beyond.view.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity
extends AppCompatActivity {
    private static boolean isAnyRequestProcessing;

    private native String XXX();

    private native String XXXX(String var1);

    private native String XXXXX(String var1);

    private native String XXXXXX(String var1, String var2);

    private native String XXXXXXX();

    public void onClick(View view) {
        switch (view.getId()) {
            default: {
                return;
            }
            case 2131361850: {
                if (isAnyRequestProcessing) {
                    Toast.makeText((Context)this, (CharSequence)"You're doing it too fast!", (int)0).show();
                    return;
                }
                EditText editText = (EditText)this.findViewById(2131361842);
                EditText editText2 = (EditText)this.findViewById(2131361841);
                final String string2 = editText.getText().toString();
                final String string3 = editText2.getText().toString();
                isAnyRequestProcessing = true;
                this.findViewById(2131362105).setVisibility(0);
                new Thread(new Runnable(){

                    public void run() {
                        SettingsActivity settingsActivity = SettingsActivity.this;
                        String string22 = settingsActivity.XXXXXX(string2, string3);
                        try {
                            Thread.sleep((long)1000L);
                        }
                        catch (InterruptedException interruptedException) {
                            interruptedException.printStackTrace();
                        }
                        isAnyRequestProcessing = false;
                        if (string22.length() > 0) {
                            settingsActivity.runOnUiThread(new Runnable((Activity)settingsActivity, string22){
                                final /* synthetic */ Activity val$activity;
                                final /* synthetic */ String val$result;
                                {
                                    this.val$activity = activity;
                                    this.val$result = string2;
                                }

                                public void run() {
                                    SettingsActivity.this.findViewById(2131362105).setVisibility(8);
                                    Toast.makeText((Context)this.val$activity, (CharSequence)this.val$result, (int)0).show();
                                }
                            });
                        }
                    }

                }).start();
                return;
            }
            case 2131361849: {
                if (isAnyRequestProcessing) {
                    Toast.makeText((Context)this, (CharSequence)"You're doing it too fast!", (int)0).show();
                    return;
                }
                EditText editText = (EditText)this.findViewById(2131361828);
                EditText editText3 = (EditText)this.findViewById(2131361827);
                final String string4 = editText.getText().toString();
                if (!string4.equals((Object)editText3.getText().toString())) {
                    Toast.makeText((Context)this, (CharSequence)"Passwords do not match!", (int)0).show();
                    return;
                }
                isAnyRequestProcessing = true;
                this.findViewById(2131362105).setVisibility(0);
                new Thread(new Runnable(){

                    public void run() {
                        SettingsActivity settingsActivity = SettingsActivity.this;
                        String string2 = settingsActivity.XXXXX(string4);
                        try {
                            Thread.sleep((long)1000L);
                        }
                        catch (InterruptedException interruptedException) {
                            interruptedException.printStackTrace();
                        }
                        isAnyRequestProcessing = false;
                        if (string2.length() > 0) {
                            settingsActivity.runOnUiThread(new Runnable((Activity)settingsActivity, string2){
                                final /* synthetic */ Activity val$activity;
                                final /* synthetic */ String val$result;
                                {
                                    this.val$activity = activity;
                                    this.val$result = string2;
                                }

                                public void run() {
                                    SettingsActivity.this.findViewById(2131362105).setVisibility(8);
                                    Toast.makeText((Context)this.val$activity, (CharSequence)this.val$result, (int)0).show();
                                }
                            });
                        }
                    }

                }).start();
                return;
            }
            case 2131361834: {
                if (isAnyRequestProcessing) {
                    Toast.makeText((Context)this, (CharSequence)"You're doing it too fast!", (int)0).show();
                    return;
                }
                isAnyRequestProcessing = true;
                this.findViewById(2131362105).setVisibility(0);
                new Thread(new Runnable(){

                    public void run() {
                        SettingsActivity settingsActivity = SettingsActivity.this;
                        String string2 = settingsActivity.XXXXXXX();
                        try {
                            Thread.sleep((long)1000L);
                        }
                        catch (InterruptedException interruptedException) {
                            interruptedException.printStackTrace();
                        }
                        isAnyRequestProcessing = false;
                        if (string2.length() > 0) {
                            settingsActivity.runOnUiThread(new Runnable((Activity)settingsActivity, string2){
                                final /* synthetic */ Activity val$activity;
                                final /* synthetic */ String val$result;
                                {
                                    this.val$activity = activity;
                                    this.val$result = string2;
                                }

                                public void run() {
                                    SettingsActivity.this.findViewById(2131362105).setVisibility(8);
                                    Toast.makeText((Context)this.val$activity, (CharSequence)this.val$result, (int)0).show();
                                }
                            });
                        }
                    }

                }).start();
                return;
            }
            case 2131361831: {
                if (isAnyRequestProcessing) {
                    Toast.makeText((Context)this, (CharSequence)"You're doing it too fast!", (int)0).show();
                    return;
                }
                final String string5 = ((EditText)this.findViewById(2131361844)).getText().toString();
                isAnyRequestProcessing = true;
                this.findViewById(2131362105).setVisibility(0);
                new Thread(new Runnable(){

                    public void run() {
                        SettingsActivity settingsActivity = SettingsActivity.this;
                        String string2 = settingsActivity.XXXX(string5);
                        try {
                            Thread.sleep((long)1000L);
                        }
                        catch (InterruptedException interruptedException) {
                            interruptedException.printStackTrace();
                        }
                        isAnyRequestProcessing = false;
                        if (string2.length() > 0) {
                            settingsActivity.runOnUiThread(new Runnable((Activity)settingsActivity, string2){
                                final /* synthetic */ Activity val$activity;
                                final /* synthetic */ String val$result;
                                {
                                    this.val$activity = activity;
                                    this.val$result = string2;
                                }

                                public void run() {
                                    SettingsActivity.this.findViewById(2131362105).setVisibility(8);
                                    Toast.makeText((Context)this.val$activity, (CharSequence)this.val$result, (int)0).show();
                                }
                            });
                            if (string2.equals((Object)"Success")) {
                                TextView textView = (TextView)SettingsActivity.this.findViewById(2131361833);
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("Remaining Time:\n ");
                                stringBuilder.append(SettingsActivity.this.XXX());
                                textView.setText((CharSequence)stringBuilder.toString());
                            }
                        }
                    }

                }).start();
                return;
            }
            case 2131361799: 
        }
        super.finish();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131558434);
        this.findViewById(2131362105).setVisibility(8);
        TextView textView = (TextView)this.findViewById(2131361833);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Remaining Time:\n ");
        stringBuilder.append(this.XXX());
        textView.setText((CharSequence)stringBuilder.toString());
    }

}

