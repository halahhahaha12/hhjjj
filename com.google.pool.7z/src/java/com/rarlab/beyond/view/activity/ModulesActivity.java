/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningServiceInfo
 *  android.content.ActivityNotFoundException
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.Resources
 *  android.graphics.Point
 *  android.graphics.Rect
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Process
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.util.DisplayMetrics
 *  android.view.Display
 *  android.view.DisplayCutout
 *  android.view.View
 *  android.view.Window
 *  android.view.WindowInsets
 *  android.view.WindowManager
 *  android.widget.Toast
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.core.app.ActivityCompat
 *  java.io.File
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Process
 *  java.lang.Runnable
 *  java.lang.Runtime
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.util.List
 */
package com.rarlab.beyond.view.activity;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Point;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.DisplayCutout;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.rarlab.beyond.view.activity.FloatLogo;
import com.rarlab.beyond.view.activity.Overlay;
import com.rarlab.beyond.view.activity.SettingsActivity;
import com.rarlab.beyond.view.activity.TouchService;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class ModulesActivity
extends AppCompatActivity {
    private static boolean doubleBackToExitPressedOnce;
    private static boolean isAnyRequestProcessing;
    private static boolean isHackLoaded;
    private static Process process;

    private native String XXX();

    private native void XXXX(int var1, int var2, float var3, int var4, int var5, String var6);

    private native void XXXXX(String var1, String var2);

    static /* synthetic */ Point access$300(ModulesActivity modulesActivity) {
        return modulesActivity.getResolution();
    }

    private boolean checkAccessibilityPermission() {
        if (!this.isAccessibilitySettingsOn(this.getApplicationContext(), TouchService.class)) {
            Toast.makeText((Context)this, (CharSequence)"Enable Accessibility Permission ", (int)1).show();
            this.startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS"));
            return false;
        }
        return true;
    }

    private boolean checkPermission() {
        boolean bl = this.CheckFloatViewPermission();
        boolean bl2 = this.checkAccessibilityPermission();
        return bl && bl2;
    }

    private void getCredentials() {
        SharedPreferences sharedPreferences = this.getSharedPreferences("credentials", 0);
        this.XXXXX(sharedPreferences.getString("username", null), sharedPreferences.getString("password", null));
    }

    private int getDPI() {
        return (int)(160.0f * this.getResources().getDisplayMetrics().density);
    }

    private Point getResolution() {
        Display display = this.getWindowManager().getDefaultDisplay();
        Point point = new Point();
        display.getRealSize(point);
        return point;
    }

    private boolean isGameInstalled(Context context) {
        try {
            context.getPackageManager().getApplicationInfo("com.miniclip.eightballpool", 0);
            return true;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            return false;
        }
    }

    private boolean isPackageInstalled(Context context, String string2) {
        try {
            context.getPackageManager().getApplicationInfo(string2, 0);
            return true;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            return false;
        }
    }

    public static boolean isRooted(Context context) {
        Process process = Runtime.getRuntime().exec("su -c exit");
        try {
            int n = process.waitFor();
            boolean bl = false;
            if (n == 0) {
                bl = true;
            }
            return bl;
        }
        catch (InterruptedException interruptedException) {
            try {
                interruptedException.printStackTrace();
                return false;
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
                return false;
            }
        }
    }

    private boolean isServiceRunning() {
        ActivityManager activityManager = (ActivityManager)this.getSystemService("activity");
        if (activityManager != null) {
            for (ActivityManager.RunningServiceInfo runningServiceInfo : activityManager.getRunningServices(Integer.MAX_VALUE)) {
                if (!FloatLogo.class.getName().equals((Object)runningServiceInfo.service.getClassName())) continue;
                return true;
            }
        }
        return false;
    }

    private void onUnload() {
        Process process = ModulesActivity.process;
        if (process != null) {
            process.destroy();
        }
        this.getApplicationContext().stopService(new Intent(this.getApplicationContext(), TouchService.class));
        this.getApplicationContext().stopService(new Intent(this.getApplicationContext(), Overlay.class));
        this.getApplicationContext().stopService(new Intent(this.getApplicationContext(), FloatLogo.class));
    }

    private void startDaemon(Activity activity) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getApplicationInfo().nativeLibraryDir);
        stringBuilder.append(File.separator);
        stringBuilder.append("libtgpa.so");
        String string2 = stringBuilder.toString();
        new File(string2).setExecutable(true);
        try {
            Runtime runtime = Runtime.getRuntime();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("su -c ");
            stringBuilder2.append(string2);
            process = runtime.exec(stringBuilder2.toString());
            return;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            process = null;
            return;
        }
    }

    private void startFloater(Context context) {
        if (!this.isServiceRunning()) {
            this.getApplicationContext().startService(new Intent(context, FloatLogo.class));
        }
    }

    public boolean CheckFloatViewPermission() {
        int n = Build.VERSION.SDK_INT;
        int n2 = 1;
        if (n >= 23 && !Settings.canDrawOverlays((Context)this)) {
            Toast.makeText((Context)this, (CharSequence)"Enable Overlay Permission ", (int)n2).show();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("package:");
            stringBuilder.append(this.getPackageName());
            Intent intent = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse((String)stringBuilder.toString()));
            n2 = 0;
            this.startActivityForResult(intent, 0);
        }
        return (boolean)n2;
    }

    public boolean CheckReadStoragePermission() {
        if (!this.checkPermissionForReadExternalStorage()) {
            try {
                this.requestPermissionForReadExternalStorage();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            return false;
        }
        return true;
    }

    public boolean checkPermissionForReadExternalStorage() {
        int n = Build.VERSION.SDK_INT;
        boolean bl = false;
        if (n >= 23) {
            int n2 = this.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE");
            bl = false;
            if (n2 == 0) {
                bl = true;
            }
        }
        return bl;
    }

    public boolean isAccessibilitySettingsOn(Context context, Class class_) {
        String string2 = Settings.Secure.getString((ContentResolver)context.getContentResolver(), (String)"enabled_accessibility_services");
        if (string2 != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(context.getPackageName());
            stringBuilder.append("/");
            stringBuilder.append(class_.getName());
            if (string2.contains((CharSequence)stringBuilder.toString())) {
                return true;
            }
        }
        return false;
    }

    boolean isGameRunning() {
        Process process = Runtime.getRuntime().exec("su -c (toolbox ps; toolbox ps -A; toybox ps; toybox ps -A) | grep com.miniclip.eightballpool");
        try {
            int n = process.waitFor();
            boolean bl = false;
            if (n == 0) {
                bl = true;
            }
            return bl;
        }
        catch (InterruptedException interruptedException) {
            try {
                interruptedException.printStackTrace();
                return false;
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
                return false;
            }
        }
    }

    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            this.onUnload();
            this.finishAffinity();
            return;
        }
        doubleBackToExitPressedOnce = true;
        Toast.makeText((Context)this, (CharSequence)"Please click BACK again to exit", (int)0).show();
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable(){

            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000L);
    }

    public void onClick(View view) {
        int n = view.getId();
        if (n != 2131361818) {
            if (n != 2131361843) {
                if (n != 2131361847) {
                    return;
                }
                this.onUnload();
                this.finishAffinity();
                android.os.Process.killProcess((int)android.os.Process.myPid());
                return;
            }
            this.startActivity(new Intent((Context)this, SettingsActivity.class));
            return;
        }
        if (isAnyRequestProcessing) {
            Toast.makeText((Context)this, (CharSequence)"You're doing it too fast!", (int)0).show();
            return;
        }
        if (!ModulesActivity.isRooted(this.getApplicationContext())) {
            Toast.makeText((Context)this, (CharSequence)"root access is not properly installed in this device", (int)0).show();
            return;
        }
        if (!this.checkPermission()) {
            return;
        }
        if (!this.isGameInstalled(this.getApplicationContext())) {
            Toast.makeText((Context)this, (CharSequence)"Please install 8BP", (int)0).show();
            try {
                this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)"market://details?id=com.miniclip.eightballpool")));
                return;
            }
            catch (ActivityNotFoundException activityNotFoundException) {
                this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)"https://play.google.com/store/apps/details?id=com.miniclip.eightballpool")));
                return;
            }
        }
        isAnyRequestProcessing = true;
        this.findViewById(2131362105).setVisibility(0);
        if (!isHackLoaded) {
            Toast.makeText((Context)this, (CharSequence)"Hack is loading!", (int)0).show();
            new Thread(new Runnable((Activity)this){
                final /* synthetic */ Activity val$activity;
                {
                    this.val$activity = activity;
                }

                public void run() {
                    final String string2 = ModulesActivity.this.XXX();
                    try {
                        Thread.sleep((long)1000L);
                    }
                    catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                    isAnyRequestProcessing = false;
                    if (string2.length() > 0) {
                        this.val$activity.runOnUiThread(new Runnable(){

                            public void run() {
                                ModulesActivity.this.findViewById(2131362105).setVisibility(8);
                                Toast.makeText((Context)1.this.val$activity, (CharSequence)string2, (int)0).show();
                            }
                        });
                        if (string2.equals((Object)"Success")) {
                            Intent intent = ModulesActivity.this.getPackageManager().getLaunchIntentForPackage("com.miniclip.eightballpool");
                            ModulesActivity.this.startActivity(intent);
                            try {
                                Thread.sleep((long)4000L);
                            }
                            catch (InterruptedException interruptedException) {
                                interruptedException.printStackTrace();
                            }
                            Rect rect = new Rect(0, 0, 0, 0);
                            Rect rect2 = new Rect(0, 0, 0, 0);
                            if (Build.VERSION.SDK_INT >= 28) {
                                DisplayCutout displayCutout = ModulesActivity.this.getWindow().getDecorView().getRootWindowInsets().getDisplayCutout();
                                if (Build.VERSION.SDK_INT >= 29 && displayCutout != null) {
                                    rect = displayCutout.getBoundingRectTop();
                                    rect2 = displayCutout.getBoundingRectBottom();
                                }
                            }
                            ModulesActivity.this.startDaemon(this.val$activity);
                            ModulesActivity modulesActivity = ModulesActivity.this;
                            modulesActivity.XXXX(ModulesActivity.access$300((ModulesActivity)modulesActivity).x, ModulesActivity.access$300((ModulesActivity)ModulesActivity.this).y, ModulesActivity.this.getDPI(), rect.bottom, rect2.top, "");
                            System.loadLibrary((String)"native-lib");
                            ModulesActivity.this.startHackServices();
                            isHackLoaded = true;
                        }
                    }
                }

            }).start();
            return;
        }
        Toast.makeText((Context)this, (CharSequence)"Hack Already Running!", (int)0).show();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131558432);
        this.findViewById(2131362105).setVisibility(8);
        this.getCredentials();
    }

    public void onDestroy() {
        super.onDestroy();
        this.onUnload();
    }

    public void requestPermissionForReadExternalStorage() throws Exception {
        try {
            ActivityCompat.requestPermissions((Activity)this, (String[])new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, (int)41);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            throw exception;
        }
    }

    public void startHackServices() {
        this.startPatcher(this.getApplicationContext());
        this.getApplicationContext().startService(new Intent(this.getApplicationContext(), Overlay.class));
        Intent intent = new Intent(this.getApplicationContext(), TouchService.class);
        intent.putExtra("action", true);
        this.getApplicationContext().startService(intent);
    }

    void startPatcher(Context context) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays((Context)context)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("package:");
            stringBuilder.append(this.getPackageName());
            this.startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse((String)stringBuilder.toString())), 123);
            return;
        }
        this.startFloater(context);
    }

}

