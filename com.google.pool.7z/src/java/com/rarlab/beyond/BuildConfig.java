/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.rarlab.beyond;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.google.pool";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final int VERSION_CODE = 16;
    public static final String VERSION_NAME = "1.6";
}

