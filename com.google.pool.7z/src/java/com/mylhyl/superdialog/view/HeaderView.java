/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  java.lang.CharSequence
 *  java.lang.String
 */
package com.mylhyl.superdialog.view;

import android.content.Context;
import android.graphics.drawable.Drawable;
import com.mylhyl.superdialog.callback.ProviderHeader;
import com.mylhyl.superdialog.res.drawable.BgHeader;
import com.mylhyl.superdialog.view.Controller;
import com.mylhyl.superdialog.view.SuperTextView;

class HeaderView
extends SuperTextView {
    public HeaderView(Context context, Controller.Params params) {
        super(context);
        this.initData(params);
    }

    private void initData(Controller.Params params) {
        ProviderHeader providerHeader = params.mProviderHeader;
        this.setText((CharSequence)providerHeader.getTitle());
        this.setTextSize(providerHeader.getTextSize());
        this.setHeight(providerHeader.getHeight());
        this.setTextColor(providerHeader.getTextColor());
        this.setBackgroundDrawable((Drawable)new BgHeader(params));
    }
}

