/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  android.text.TextUtils
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  com.mylhyl.superdialog.SuperDialog
 *  com.mylhyl.superdialog.callback.ProviderFooterNegative
 *  com.mylhyl.superdialog.callback.ProviderFooterPositive
 *  com.mylhyl.superdialog.callback.ProviderFooterPositiveInput
 *  com.mylhyl.superdialog.view.BodyInputView
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.mylhyl.superdialog.view;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.mylhyl.superdialog.SuperDialog;
import com.mylhyl.superdialog.callback.ProviderFooterNegative;
import com.mylhyl.superdialog.callback.ProviderFooterPositive;
import com.mylhyl.superdialog.callback.ProviderFooterPositiveInput;
import com.mylhyl.superdialog.res.drawable.BgBtn;
import com.mylhyl.superdialog.view.BodyInputView;
import com.mylhyl.superdialog.view.Controller;
import com.mylhyl.superdialog.view.DividerView;
import com.mylhyl.superdialog.view.SuperTextView;

class FooterView
extends LinearLayout {
    private ProviderFooterPositive mFooterPositive;
    private SuperTextView mPositiveButton;

    public FooterView(Context context, Controller.Params params) {
        super(context);
        this.init(params);
    }

    private void init(Controller.Params params) {
        ProviderFooterPositive providerFooterPositive;
        final ProviderFooterNegative providerFooterNegative = params.mFooterNegative;
        this.mFooterPositive = params.mFooterPositive;
        this.setOrientation(0);
        int n = params.mRadius;
        if (providerFooterNegative != null) {
            final SuperDialog.OnClickNegativeListener onClickNegativeListener = providerFooterNegative.getOnNegativeListener();
            SuperTextView superTextView = new SuperTextView(this.getContext());
            superTextView.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2, 1.0f));
            superTextView.setClickable(true);
            superTextView.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    providerFooterNegative.dismiss();
                    SuperDialog.OnClickNegativeListener onClickNegativeListener2 = onClickNegativeListener;
                    if (onClickNegativeListener2 != null) {
                        onClickNegativeListener2.onClick(view);
                    }
                }
            });
            superTextView.setText((CharSequence)providerFooterNegative.getTitle());
            superTextView.setTextSize(providerFooterNegative.getTextSize());
            superTextView.setTextColor(providerFooterNegative.getTextColor());
            superTextView.setHeight(providerFooterNegative.getHeight());
            if (this.mFooterPositive != null) {
                BgBtn bgBtn = new BgBtn(0, 0, 0, n, params.mBackgroundColor);
                superTextView.setBackgroundDrawable((Drawable)bgBtn);
            } else {
                BgBtn bgBtn = new BgBtn(0, 0, n, n, params.mBackgroundColor);
                superTextView.setBackgroundDrawable((Drawable)bgBtn);
            }
            this.addView((View)superTextView);
        }
        if (providerFooterNegative != null && this.mFooterPositive != null) {
            this.addView((View)new DividerView(this.getContext()));
        }
        if ((providerFooterPositive = this.mFooterPositive) != null) {
            SuperTextView superTextView;
            final SuperDialog.OnClickPositiveListener onClickPositiveListener = providerFooterPositive.getOnPositiveListener();
            this.mPositiveButton = superTextView = new SuperTextView(this.getContext());
            superTextView.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2, 1.0f));
            this.mPositiveButton.setClickable(true);
            if (onClickPositiveListener != null) {
                this.mPositiveButton.setOnClickListener(new View.OnClickListener(){

                    public void onClick(View view) {
                        FooterView.this.mFooterPositive.dismiss();
                        SuperDialog.OnClickPositiveListener onClickPositiveListener2 = onClickPositiveListener;
                        if (onClickPositiveListener2 != null) {
                            onClickPositiveListener2.onClick(view);
                        }
                    }
                });
            }
            this.mPositiveButton.setText((CharSequence)this.mFooterPositive.getTitle());
            this.mPositiveButton.setTextSize(this.mFooterPositive.getTextSize());
            this.mPositiveButton.setTextColor(this.mFooterPositive.getTextColor());
            this.mPositiveButton.setHeight(this.mFooterPositive.getHeight());
            if (providerFooterNegative != null) {
                SuperTextView superTextView2 = this.mPositiveButton;
                BgBtn bgBtn = new BgBtn(0, 0, n, 0, params.mBackgroundColor);
                superTextView2.setBackgroundDrawable((Drawable)bgBtn);
            } else {
                SuperTextView superTextView3 = this.mPositiveButton;
                BgBtn bgBtn = new BgBtn(0, 0, n, n, params.mBackgroundColor);
                superTextView3.setBackgroundDrawable((Drawable)bgBtn);
            }
            this.addView((View)this.mPositiveButton);
        }
    }

    public void setOnClickPositiveInputListener(final BodyInputView bodyInputView) {
        ProviderFooterPositive providerFooterPositive = this.mFooterPositive;
        if (providerFooterPositive != null && providerFooterPositive instanceof ProviderFooterPositiveInput) {
            final SuperDialog.OnClickPositiveInputListener onClickPositiveInputListener = ((ProviderFooterPositiveInput)providerFooterPositive).getOnPositiveInputListener();
            this.mPositiveButton.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    SuperDialog.OnClickPositiveInputListener onClickPositiveInputListener2;
                    String string2 = bodyInputView.getInputText();
                    if (!TextUtils.isEmpty((CharSequence)string2)) {
                        FooterView.this.mFooterPositive.dismiss();
                    }
                    if ((onClickPositiveInputListener2 = onClickPositiveInputListener) != null) {
                        onClickPositiveInputListener2.onClick(string2, view);
                    }
                }
            });
        }
    }

}

