/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.widget.LinearLayout
 */
package com.mylhyl.superdialog.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import com.mylhyl.superdialog.auto.AutoLayoutConfig;

class AutoLinearLayout
extends LinearLayout {
    public AutoLinearLayout(Context context) {
        this(context, null);
    }

    public AutoLinearLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public AutoLinearLayout(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        AutoLayoutConfig.init(context);
    }

    public AutoLinearLayout(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        AutoLayoutConfig.init(context);
    }
}

