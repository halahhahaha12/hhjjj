/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.widget.TextView
 */
package com.mylhyl.superdialog.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;
import com.mylhyl.superdialog.auto.AutoUtils;

public class SuperTextView
extends TextView {
    public SuperTextView(Context context) {
        this(context, null);
    }

    public SuperTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public SuperTextView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init();
    }

    public SuperTextView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        this.init();
    }

    private void init() {
        this.setGravity(17);
    }

    public void setAutoPadding(int n, int n2, int n3, int n4) {
        super.setPadding(AutoUtils.scaleValue(n), AutoUtils.scaleValue(n2), AutoUtils.scaleValue(n3), AutoUtils.scaleValue(n4));
    }

    public void setHeight(int n) {
        super.setHeight(AutoUtils.scaleValue(n));
    }

    public void setTextSize(float f) {
        this.setTextSize(0, (float)AutoUtils.scaleValue((int)f));
    }
}

