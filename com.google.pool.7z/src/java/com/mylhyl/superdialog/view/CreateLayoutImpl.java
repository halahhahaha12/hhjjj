/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.AbsListView
 *  android.widget.AbsListView$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  com.mylhyl.superdialog.SuperDialog
 *  com.mylhyl.superdialog.callback.ProviderFooterNegative
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.mylhyl.superdialog.view;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.LinearLayout;
import com.mylhyl.superdialog.SuperDialog;
import com.mylhyl.superdialog.auto.AutoUtils;
import com.mylhyl.superdialog.callback.CreateLayout;
import com.mylhyl.superdialog.callback.ProviderFooterNegative;
import com.mylhyl.superdialog.res.drawable.BgBtn;
import com.mylhyl.superdialog.view.AutoLinearLayout;
import com.mylhyl.superdialog.view.BodyInputView;
import com.mylhyl.superdialog.view.BodyMultipleView;
import com.mylhyl.superdialog.view.BodySingleView;
import com.mylhyl.superdialog.view.Controller;
import com.mylhyl.superdialog.view.CreateLayoutImpl;
import com.mylhyl.superdialog.view.DividerView;
import com.mylhyl.superdialog.view.FooterView;
import com.mylhyl.superdialog.view.HeaderView;
import com.mylhyl.superdialog.view.SuperTextView;

class CreateLayoutImpl
implements CreateLayout {
    private Context mContext;
    private Controller.Params mParams;
    private LinearLayout mRoot;

    public CreateLayoutImpl(Context context, Controller.Params params) {
        this.mContext = context;
        this.mParams = params;
        AutoLinearLayout autoLinearLayout = new AutoLinearLayout(context);
        this.mRoot = autoLinearLayout;
        autoLinearLayout.setOrientation(1);
        this.mRoot.setAlpha(params.mAlpha);
    }

    @Override
    public void buildHead() {
        HeaderView headerView = new HeaderView(this.mContext, this.mParams);
        this.mRoot.addView((View)headerView);
    }

    @Override
    public View buildInputBody() {
        BodyInputView bodyInputView = new BodyInputView(this.mContext, this.mParams);
        this.mRoot.addView((View)bodyInputView);
        return bodyInputView;
    }

    @Override
    public void buildInputFooter(View view) {
        DividerView dividerView = new DividerView(this.mContext);
        dividerView.setVertical();
        this.mRoot.addView((View)dividerView);
        FooterView footerView = new FooterView(this.mContext, this.mParams);
        footerView.setOnClickPositiveInputListener((BodyInputView)view);
        this.mRoot.addView((View)footerView);
    }

    @Override
    public void buildMultipleBody() {
        this.mRoot.addView((View)new BodyMultipleView(this.mContext, this.mParams), (ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, -1));
    }

    @Override
    public void buildMultipleFooter() {
        ProviderFooterNegative providerFooterNegative = this.mParams.mFooterNegative;
        SuperDialog.OnClickNegativeListener onClickNegativeListener = providerFooterNegative.getOnNegativeListener();
        SuperTextView superTextView = new SuperTextView(this.mContext);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2, 1.0f);
        layoutParams.topMargin = AutoUtils.scaleValue(this.mParams.mItemsBottomMargin);
        superTextView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        superTextView.setClickable(true);
        superTextView.setOnClickListener(new View.OnClickListener(this, providerFooterNegative, onClickNegativeListener){
            final /* synthetic */ CreateLayoutImpl this$0;
            final /* synthetic */ ProviderFooterNegative val$footerNegative;
            final /* synthetic */ SuperDialog.OnClickNegativeListener val$onNegativeListener;
            {
                this.this$0 = createLayoutImpl;
                this.val$footerNegative = providerFooterNegative;
                this.val$onNegativeListener = onClickNegativeListener;
            }

            public void onClick(View view) {
                this.val$footerNegative.dismiss();
                SuperDialog.OnClickNegativeListener onClickNegativeListener = this.val$onNegativeListener;
                if (onClickNegativeListener != null) {
                    onClickNegativeListener.onClick(view);
                }
            }
        });
        superTextView.setText((CharSequence)providerFooterNegative.getTitle());
        superTextView.setTextSize(providerFooterNegative.getTextSize());
        superTextView.setTextColor(providerFooterNegative.getTextColor());
        superTextView.setHeight(providerFooterNegative.getHeight());
        int n = this.mParams.mRadius;
        BgBtn bgBtn = new BgBtn(n, n, n, n, this.mParams.mBackgroundColor);
        superTextView.setBackgroundDrawable((Drawable)bgBtn);
        this.mRoot.addView((View)superTextView);
    }

    @Override
    public void buildSingleBody() {
        this.mRoot.addView((View)new BodySingleView(this.mContext, this.mParams));
    }

    @Override
    public void buildSingleFooter() {
        DividerView dividerView = new DividerView(this.mContext);
        dividerView.setVertical();
        this.mRoot.addView((View)dividerView);
        this.mRoot.addView((View)new FooterView(this.mContext, this.mParams));
    }

    @Override
    public View buildView() {
        return this.mRoot;
    }

    @Override
    public View findMultipleBody() {
        int n = this.mRoot.getChildCount();
        for (int i = 0; i < n; ++i) {
            View view = this.mRoot.getChildAt(i);
            if (!(view instanceof BodyMultipleView)) continue;
            return view;
        }
        return null;
    }

    @Override
    public View findSingleBody() {
        int n = this.mRoot.getChildCount();
        for (int i = 0; i < n; ++i) {
            View view = this.mRoot.getChildAt(i);
            if (!(view instanceof BodySingleView)) continue;
            return view;
        }
        return null;
    }
}

