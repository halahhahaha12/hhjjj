/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.BaseAdapter
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.TextView
 *  com.mylhyl.superdialog.SuperDialog
 *  com.mylhyl.superdialog.callback.ProviderContentMultiple
 *  com.mylhyl.superdialog.callback.ProviderHeader
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.List
 */
package com.mylhyl.superdialog.view;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.mylhyl.superdialog.SuperDialog;
import com.mylhyl.superdialog.callback.ProviderContent;
import com.mylhyl.superdialog.callback.ProviderContentMultiple;
import com.mylhyl.superdialog.callback.ProviderHeader;
import com.mylhyl.superdialog.res.drawable.BgBtn;
import com.mylhyl.superdialog.view.Controller;
import com.mylhyl.superdialog.view.SuperTextView;
import java.util.Arrays;
import java.util.List;

class BodyMultipleView
extends ListView {
    private ItemAdapter mAdapter;
    private Controller.Params mParams;

    public BodyMultipleView(Context context, Controller.Params params) {
        super(context);
        this.mParams = params;
        this.initData();
    }

    private void initData() {
        final ProviderContentMultiple providerContentMultiple = (ProviderContentMultiple)this.mParams.mProviderContent;
        if (providerContentMultiple == null) {
            return;
        }
        this.mAdapter = new ItemAdapter(this.mParams, providerContentMultiple);
        this.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
        this.setSelector((Drawable)new ColorDrawable(0));
        this.setDivider((Drawable)new ColorDrawable(-2631717));
        this.setDividerHeight(1);
        this.setAdapter((ListAdapter)this.mAdapter);
        this.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            public void onItemClick(AdapterView<?> adapterView, View view, int n, long l) {
                providerContentMultiple.dismiss();
                if (providerContentMultiple.getItemClickListener() != null) {
                    providerContentMultiple.getItemClickListener().onItemClick(n);
                }
            }
        });
    }

    public void refreshItems() {
        this.mAdapter.notifyDataSetChanged();
    }

    class ItemAdapter<T>
    extends BaseAdapter {
        private int mBackgroundColor;
        private List<T> mItems;
        private ProviderContentMultiple mProviderContent;
        private ProviderHeader mProviderHeader;
        private int mRadius;

        public ItemAdapter(Controller.Params params, ProviderContentMultiple providerContentMultiple) {
            this.mRadius = params.mRadius;
            this.mBackgroundColor = params.mBackgroundColor;
            this.mProviderHeader = params.mProviderHeader;
            this.mProviderContent = providerContentMultiple;
            Object object = providerContentMultiple.getItems();
            if (object != null && object instanceof Iterable) {
                this.mItems = (List)object;
                return;
            }
            if (object != null && object.getClass().isArray()) {
                this.mItems = Arrays.asList((Object[])((Object[])object));
                return;
            }
            throw new IllegalArgumentException("entity must be an Array or an Iterable.");
        }

        public int getCount() {
            List<T> list = this.mItems;
            if (list != null) {
                return list.size();
            }
            return 0;
        }

        public T getItem(int n) {
            List<T> list = this.mItems;
            if (list != null) {
                return (T)list.get(n);
            }
            return null;
        }

        public long getItemId(int n) {
            return 0L;
        }

        public View getView(int n, View view, ViewGroup viewGroup) {
            ViewHolder viewHolder;
            Object object;
            if (view == null) {
                viewHolder = new ViewHolder();
                object = new SuperTextView(BodyMultipleView.this.getContext());
                ((SuperTextView)((Object)object)).setTextSize(this.mProviderContent.getTextSize());
                object.setTextColor(this.mProviderContent.getTextColor());
                ((SuperTextView)((Object)object)).setHeight(this.mProviderContent.getItemHeight());
                viewHolder.item = object;
                object.setTag((Object)viewHolder);
            } else {
                ViewHolder viewHolder2 = (ViewHolder)view.getTag();
                object = view;
                viewHolder = viewHolder2;
            }
            if (n == 0 && this.mProviderHeader == null) {
                if (this.getCount() == 1) {
                    TextView textView = viewHolder.item;
                    int n2 = this.mRadius;
                    BgBtn bgBtn = new BgBtn(n2, n2, n2, n2, this.mBackgroundColor);
                    textView.setBackgroundDrawable((Drawable)bgBtn);
                } else {
                    TextView textView = viewHolder.item;
                    int n3 = this.mRadius;
                    BgBtn bgBtn = new BgBtn(n3, n3, 0, 0, this.mBackgroundColor);
                    textView.setBackgroundDrawable((Drawable)bgBtn);
                }
            } else if (n == this.getCount() - 1) {
                TextView textView = viewHolder.item;
                int n4 = this.mRadius;
                BgBtn bgBtn = new BgBtn(0, 0, n4, n4, this.mBackgroundColor);
                textView.setBackgroundDrawable((Drawable)bgBtn);
            } else {
                TextView textView = viewHolder.item;
                BgBtn bgBtn = new BgBtn(0, 0, 0, 0, this.mBackgroundColor);
                textView.setBackgroundDrawable((Drawable)bgBtn);
            }
            viewHolder.item.setText((CharSequence)String.valueOf((Object)this.getItem(n).toString()));
            return object;
        }

        class ViewHolder {
            TextView item;

            ViewHolder() {
            }
        }

    }

}

