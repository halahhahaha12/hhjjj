/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  android.text.Editable
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  com.mylhyl.superdialog.callback.ProviderFooterNegative
 *  com.mylhyl.superdialog.callback.ProviderFooterPositive
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.mylhyl.superdialog.view;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.mylhyl.superdialog.callback.ProviderContent;
import com.mylhyl.superdialog.callback.ProviderContentInput;
import com.mylhyl.superdialog.callback.ProviderFooterNegative;
import com.mylhyl.superdialog.callback.ProviderFooterPositive;
import com.mylhyl.superdialog.callback.ProviderHeader;
import com.mylhyl.superdialog.res.drawable.BgBtn;
import com.mylhyl.superdialog.view.AutoLinearLayout;
import com.mylhyl.superdialog.view.Controller;
import com.mylhyl.superdialog.view.SuperEditText;

class BodyInputView
extends AutoLinearLayout {
    private SuperEditText mEditText;
    private Controller.Params mParams;

    public BodyInputView(Context context, Controller.Params params) {
        super(context);
        this.mParams = params;
        this.initData();
    }

    private void initData() {
        SuperEditText superEditText;
        if (this.mParams.mProviderHeader != null && this.mParams.mFooterNegative == null && this.mParams.mFooterPositive == null) {
            int n = this.mParams.mRadius;
            BgBtn bgBtn = new BgBtn(0, 0, n, n, this.mParams.mBackgroundColor);
            this.setBackgroundDrawable((Drawable)bgBtn);
        } else if (this.mParams.mProviderHeader == null && (this.mParams.mFooterNegative != null || this.mParams.mFooterPositive != null)) {
            int n = this.mParams.mRadius;
            BgBtn bgBtn = new BgBtn(n, n, 0, 0, this.mParams.mBackgroundColor);
            this.setBackgroundDrawable((Drawable)bgBtn);
        } else if (this.mParams.mFooterNegative == null && this.mParams.mFooterPositive == null && this.mParams.mProviderHeader == null) {
            int n = this.mParams.mRadius;
            BgBtn bgBtn = new BgBtn(n, n, n, n, this.mParams.mBackgroundColor);
            this.setBackgroundDrawable((Drawable)bgBtn);
        } else {
            this.setBackgroundColor(this.mParams.mBackgroundColor);
        }
        ProviderContentInput providerContentInput = (ProviderContentInput)this.mParams.mProviderContent;
        if (providerContentInput == null) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        int[] arrn = providerContentInput.getMargins();
        layoutParams.setMargins(arrn[0], arrn[1], arrn[2], arrn[3]);
        this.mEditText = superEditText = new SuperEditText(this.getContext());
        superEditText.setHint((CharSequence)providerContentInput.getItems());
        this.mEditText.setHintTextColor(providerContentInput.getHintTextColor());
        this.mEditText.setTextSize(providerContentInput.getTextSize());
        this.mEditText.setTextColor(providerContentInput.getTextColor());
        this.mEditText.setHeight(providerContentInput.getInputHeight());
        this.addView((View)this.mEditText, (ViewGroup.LayoutParams)layoutParams);
    }

    public String getInputText() {
        return this.mEditText.getText().toString();
    }
}

