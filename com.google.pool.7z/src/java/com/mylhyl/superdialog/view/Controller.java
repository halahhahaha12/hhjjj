/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.animation.Animation
 *  androidx.fragment.app.DialogFragment
 *  androidx.fragment.app.FragmentActivity
 *  com.mylhyl.superdialog.SuperDialog
 *  com.mylhyl.superdialog.callback.ProviderFooterNegative
 *  com.mylhyl.superdialog.callback.ProviderFooterPositive
 *  com.mylhyl.superdialog.callback.ProviderHeader
 *  com.mylhyl.superdialog.view.BodySingleView
 *  com.mylhyl.superdialog.view.Controller$Params$1
 *  com.mylhyl.superdialog.view.Controller$Params$2
 *  com.mylhyl.superdialog.view.Controller$Params$3
 *  com.mylhyl.superdialog.view.Controller$Params$4
 *  com.mylhyl.superdialog.view.Controller$Params$5
 *  com.mylhyl.superdialog.view.Controller$Params$6
 *  com.mylhyl.superdialog.view.Controller$Params$7
 *  com.mylhyl.superdialog.view.CreateLayoutImpl
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.mylhyl.superdialog.view;

import android.content.Context;
import android.view.View;
import android.view.animation.Animation;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import com.mylhyl.superdialog.SuperDialog;
import com.mylhyl.superdialog.callback.CreateLayout;
import com.mylhyl.superdialog.callback.ProviderContent;
import com.mylhyl.superdialog.callback.ProviderFooterNegative;
import com.mylhyl.superdialog.callback.ProviderFooterPositive;
import com.mylhyl.superdialog.callback.ProviderHeader;
import com.mylhyl.superdialog.view.BodyMultipleView;
import com.mylhyl.superdialog.view.BodySingleView;
import com.mylhyl.superdialog.view.Controller;
import com.mylhyl.superdialog.view.CreateLayoutImpl;
import java.io.Serializable;

public final class Controller {
    private CreateLayout createLayout;
    private Context mContext;
    private Params mParams;

    public Controller(Params params) {
        this.mContext = params.mActivity.getApplicationContext();
        this.mParams = params;
    }

    public void apply() {
        ProviderContent providerContent;
        this.createLayout = new CreateLayoutImpl(this.mContext, this.mParams);
        if (this.mParams.mProviderHeader != null) {
            this.createLayout.buildHead();
        }
        if ((providerContent = this.mParams.mProviderContent) != null && providerContent.getMode() == ProviderContent.Mode.MULTIPLE) {
            this.createLayout.buildMultipleBody();
            if (this.mParams.mFooterNegative != null || this.mParams.mFooterPositive != null) {
                this.createLayout.buildMultipleFooter();
                return;
            }
        } else if (providerContent != null && providerContent.getMode() == ProviderContent.Mode.SINGLE) {
            this.createLayout.buildSingleBody();
            if (this.mParams.mFooterNegative != null || this.mParams.mFooterPositive != null) {
                this.createLayout.buildSingleFooter();
                return;
            }
        } else {
            View view = this.createLayout.buildInputBody();
            if (this.mParams.mFooterNegative != null || this.mParams.mFooterPositive != null) {
                this.createLayout.buildInputFooter(view);
            }
        }
    }

    public View createView() {
        return this.createLayout.buildView();
    }

    public void refreshProviderContent(Animation animation) {
        BodySingleView bodySingleView;
        ProviderContent providerContent = this.mParams.mProviderContent;
        if (providerContent != null && providerContent.getMode() == ProviderContent.Mode.MULTIPLE) {
            BodyMultipleView bodyMultipleView = (BodyMultipleView)this.createLayout.findMultipleBody();
            if (bodyMultipleView != null) {
                bodyMultipleView.refreshItems();
            }
        } else if (providerContent != null && providerContent.getMode() == ProviderContent.Mode.SINGLE && (bodySingleView = (BodySingleView)this.createLayout.findSingleBody()) != null) {
            bodySingleView.refreshText();
        }
        if (animation != null) {
            this.createView().startAnimation(animation);
        }
    }

    public static class Params
    implements Serializable {
        public boolean isDimEnabled = true;
        public FragmentActivity mActivity;
        public float mAlpha = 1.0f;
        public int mAnimStyle;
        public View mAsDropDownAnchor = null;
        public int mAtLocationGravity = 0;
        public int mBackgroundColor = -460552;
        public boolean mCancelable = true;
        public boolean mCanceledOnTouchOutside = true;
        public SuperDialog.ConfigDialog mConfigDialog;
        public DialogFragment mDialogFragment;
        public ProviderFooterNegative mFooterNegative;
        public ProviderFooterPositive mFooterPositive;
        public int mGravity = 17;
        public int mItemsBottomMargin = 10;
        public int[] mPadding;
        public ProviderContent mProviderContent;
        public ProviderHeader mProviderHeader;
        public int mRadius = 30;
        public float mWidth = 0.9f;
        public int x;
        public int y;

        public Params(FragmentActivity fragmentActivity) {
            this.mActivity = fragmentActivity;
        }

        private void setProviderContent(ProviderContent providerContent) {
            this.mProviderContent = providerContent;
        }

        private void setProviderFooterNegative(ProviderFooterNegative providerFooterNegative) {
            this.mFooterNegative = providerFooterNegative;
        }

        private void setProviderFooterPositive(ProviderFooterPositive providerFooterPositive) {
            this.mFooterPositive = providerFooterPositive;
        }

        private void setProviderHeader(ProviderHeader providerHeader) {
            this.mProviderHeader = providerHeader;
        }

        public void setContentInput(String string2, int n, int n2, int n3, int[] arrn) {
            4 var6_6 = new 4(this, arrn, n3, string2, n, n2);
            this.setProviderContent((ProviderContent)var6_6);
        }

        public void setContentMultiple(Object object, int n, int n2, int n3, SuperDialog.OnItemClickListener onItemClickListener) {
            3 var6_6 = new 3(this, n3, onItemClickListener, object, n, n2);
            this.setProviderContent((ProviderContent)var6_6);
        }

        public void setContentSingle(String string2, int n, int n2, int[] arrn) {
            2 var5_5 = new 2(this, arrn, string2, n, n2);
            this.setProviderContent((ProviderContent)var5_5);
        }

        public void setNegativeButton(String string2, int n, int n2, int n3, SuperDialog.OnClickNegativeListener onClickNegativeListener) {
            5 var6_6 = new 5(this, string2, onClickNegativeListener, n2, n, n3);
            this.setProviderFooterNegative((ProviderFooterNegative)var6_6);
        }

        public void setPositiveButton(String string2, int n, int n2, int n3, SuperDialog.OnClickPositiveListener onClickPositiveListener) {
            6 var6_6 = new 6(this, string2, onClickPositiveListener, n2, n, n3);
            this.setProviderFooterPositive((ProviderFooterPositive)var6_6);
        }

        public void setPositiveInputButton(String string2, int n, int n2, int n3, SuperDialog.OnClickPositiveInputListener onClickPositiveInputListener) {
            7 var6_6 = new 7(this, string2, onClickPositiveInputListener, n2, n, n3);
            this.setProviderFooterPositive((ProviderFooterPositive)var6_6);
        }

        public void setTitle(String string2, int n, int n2, int n3) {
            1 var5_5 = new 1(this, string2, n, n2, n3);
            this.setProviderHeader((ProviderHeader)var5_5);
        }
    }

}

