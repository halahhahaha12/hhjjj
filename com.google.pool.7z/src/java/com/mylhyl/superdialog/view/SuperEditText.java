/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.util.AttributeSet
 *  android.widget.EditText
 */
package com.mylhyl.superdialog.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.EditText;
import com.mylhyl.superdialog.auto.AutoUtils;

public class SuperEditText
extends EditText {
    private Paint mPaint;

    public SuperEditText(Context context) {
        this(context, null);
    }

    public SuperEditText(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public SuperEditText(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init();
    }

    public SuperEditText(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        this.init();
    }

    private void init() {
        Paint paint;
        this.requestFocus();
        this.setFocusable(true);
        this.setFocusableInTouchMode(true);
        this.setGravity(51);
        this.mPaint = paint = new Paint();
        paint.setColor(-16777216);
        this.mPaint.setStrokeWidth(1.0f);
    }

    protected void onDraw(Canvas canvas) {
        canvas.drawLine(0.0f, 0.0f, (float)(-1 + this.getWidth()), 0.0f, this.mPaint);
        canvas.drawLine(0.0f, 0.0f, 0.0f, (float)(-1 + this.getHeight()), this.mPaint);
        canvas.drawLine((float)(-1 + this.getWidth()), 0.0f, (float)(-1 + this.getWidth()), (float)(-1 + this.getHeight()), this.mPaint);
        canvas.drawLine(0.0f, (float)(-1 + this.getHeight()), (float)(-1 + this.getWidth()), (float)(-1 + this.getHeight()), this.mPaint);
        super.onDraw(canvas);
    }

    public void setHeight(int n) {
        super.setHeight(AutoUtils.scaleValue(n));
    }

    public void setTextSize(float f) {
        this.setTextSize(0, (float)AutoUtils.scaleValue((int)f));
    }
}

