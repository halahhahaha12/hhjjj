/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  com.mylhyl.superdialog.callback.ProviderFooterNegative
 *  com.mylhyl.superdialog.callback.ProviderFooterPositive
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.mylhyl.superdialog.view;

import android.content.Context;
import android.graphics.drawable.Drawable;
import com.mylhyl.superdialog.callback.ProviderContent;
import com.mylhyl.superdialog.callback.ProviderContentSingle;
import com.mylhyl.superdialog.callback.ProviderFooterNegative;
import com.mylhyl.superdialog.callback.ProviderFooterPositive;
import com.mylhyl.superdialog.callback.ProviderHeader;
import com.mylhyl.superdialog.res.drawable.BgBtn;
import com.mylhyl.superdialog.view.Controller;
import com.mylhyl.superdialog.view.SuperTextView;

class BodySingleView
extends SuperTextView {
    private Controller.Params mParams;

    public BodySingleView(Context context, Controller.Params params) {
        super(context);
        this.mParams = params;
        this.initData();
    }

    private void initData() {
        if (this.mParams.mProviderHeader != null && this.mParams.mFooterNegative == null && this.mParams.mFooterPositive == null) {
            int n = this.mParams.mRadius;
            BgBtn bgBtn = new BgBtn(0, 0, n, n, this.mParams.mBackgroundColor);
            this.setBackgroundDrawable((Drawable)bgBtn);
        } else if (this.mParams.mProviderHeader == null && (this.mParams.mFooterNegative != null || this.mParams.mFooterPositive != null)) {
            int n = this.mParams.mRadius;
            BgBtn bgBtn = new BgBtn(n, n, 0, 0, this.mParams.mBackgroundColor);
            this.setBackgroundDrawable((Drawable)bgBtn);
        } else if (this.mParams.mFooterNegative == null && this.mParams.mFooterPositive == null && this.mParams.mProviderHeader == null) {
            int n = this.mParams.mRadius;
            BgBtn bgBtn = new BgBtn(n, n, n, n, this.mParams.mBackgroundColor);
            this.setBackgroundDrawable((Drawable)bgBtn);
        } else {
            this.setBackgroundColor(this.mParams.mBackgroundColor);
        }
        ProviderContentSingle providerContentSingle = (ProviderContentSingle)this.mParams.mProviderContent;
        if (providerContentSingle == null) {
            return;
        }
        this.setText((CharSequence)providerContentSingle.getItems());
        this.setTextSize(providerContentSingle.getTextSize());
        this.setTextColor(providerContentSingle.getTextColor());
        int[] arrn = providerContentSingle.getPadding();
        this.setAutoPadding(arrn[0], arrn[1], arrn[2], arrn[3]);
    }

    public void refreshText() {
        ProviderContent providerContent = this.mParams.mProviderContent;
        if (providerContent == null) {
            return;
        }
        this.setText((CharSequence)((String)providerContent.getItems()));
    }
}

