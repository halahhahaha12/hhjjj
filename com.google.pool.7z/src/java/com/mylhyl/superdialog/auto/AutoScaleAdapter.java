/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 */
package com.mylhyl.superdialog.auto;

import android.content.Context;
import com.mylhyl.superdialog.auto.AutoUtils;

class AutoScaleAdapter {
    private Context mContext;

    public AutoScaleAdapter(Context context) {
        this.mContext = context;
    }

    public float adapt(float f, int n, int n2) {
        if (n < 720 || n2 < 720) {
            float f2 = n > 480 && n2 > 480 ? (AutoUtils.getDevicePhysicalSize(this.mContext) < 4.0 ? 1.3f : 1.05f) : 1.2f;
            f *= f2;
        }
        return f;
    }
}

