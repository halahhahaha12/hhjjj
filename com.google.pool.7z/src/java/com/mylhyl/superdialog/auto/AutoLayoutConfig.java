/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package com.mylhyl.superdialog.auto;

import android.content.Context;
import com.mylhyl.superdialog.auto.AutoScaleAdapter;
import com.mylhyl.superdialog.auto.AutoUtils;

public class AutoLayoutConfig {
    private static final String KEY_DESIGN_HEIGHT = "design_height";
    private static final String KEY_DESIGN_WIDTH = "design_width";
    private static AutoLayoutConfig sInstance;
    private int mDesignHeight = 1920;
    private int mDesignWidth = 1080;
    private float mScale;
    private int mScreenHeight;
    private int mScreenWidth;

    private AutoLayoutConfig() {
    }

    private void checkParams() {
        if (this.mDesignHeight > 0 && this.mDesignWidth > 0) {
            return;
        }
        throw new RuntimeException("you must set design_width and design_height > 0");
    }

    public static AutoLayoutConfig getInstance() {
        AutoLayoutConfig autoLayoutConfig = sInstance;
        if (autoLayoutConfig != null) {
            return autoLayoutConfig;
        }
        throw new IllegalStateException("Must init before using.");
    }

    /*
     * Exception decompiling
     */
    private void getMetaData(Context var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void init(Context context) {
        if (sInstance == null) {
            AutoLayoutConfig autoLayoutConfig;
            sInstance = autoLayoutConfig = new AutoLayoutConfig();
            autoLayoutConfig.initInternal(context, new AutoScaleAdapter(context));
        }
    }

    private void initInternal(Context context, AutoScaleAdapter autoScaleAdapter) {
        int n;
        float f;
        int n2;
        float f2;
        int n3;
        int n4;
        int n5;
        float f3;
        int n6;
        this.getMetaData(context);
        this.checkParams();
        int[] arrn = AutoUtils.getRealScreenSize(context);
        this.mScreenWidth = n = arrn[0];
        this.mScreenHeight = n4 = arrn[1];
        if (n > n4) {
            int n7;
            int n8 = n + n4;
            this.mScreenHeight = n7 = n8 - n4;
            this.mScreenWidth = n8 - n7;
        }
        this.mScale = (f2 = (f = (float)(n5 = this.mScreenHeight)) / (float)(n3 = this.mScreenWidth)) <= (f3 = (float)(n6 = this.mDesignHeight)) / (float)(n2 = this.mDesignWidth) ? (float)n5 / (float)n6 : (float)n3 / (float)n2;
        if (autoScaleAdapter != null) {
            this.mScale = autoScaleAdapter.adapt(this.mScale, n3, n5);
        }
    }

    public float getScale() {
        return this.mScale;
    }
}

