/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.graphics.Rect
 *  android.os.Bundle
 *  android.util.DisplayMetrics
 *  android.view.Display
 *  android.view.View
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  androidx.fragment.app.DialogFragment
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.fragment.app.FragmentManager
 *  androidx.fragment.app.FragmentTransaction
 *  java.io.Serializable
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package com.mylhyl.superdialog;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.mylhyl.superdialog.SuperDialog;
import com.mylhyl.superdialog.auto.AutoUtils;
import com.mylhyl.superdialog.callback.ProviderContent;
import com.mylhyl.superdialog.view.Controller;
import java.io.Serializable;

abstract class BaseDialog
extends DialogFragment {
    protected Controller.Params mParams;

    BaseDialog() {
    }

    private int getSystemBarHeight() {
        Rect rect = new Rect();
        this.mParams.mActivity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
        return rect.top;
    }

    private int getSystemTitleHeight() {
        Rect rect = new Rect();
        this.mParams.mActivity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
        Rect rect2 = new Rect();
        this.mParams.mActivity.getWindow().findViewById(16908290).getDrawingRect(rect2);
        return rect.height() - rect2.height();
    }

    private void setDialogGravity(Dialog dialog) {
        Window window = dialog.getWindow();
        window.setBackgroundDrawableResource(17170445);
        WindowManager.LayoutParams layoutParams = window.getAttributes();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        this.getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        layoutParams.width = (int)((float)displayMetrics.widthPixels * this.mParams.mWidth);
        if (this.mParams.mAsDropDownAnchor != null) {
            View view = this.mParams.mAsDropDownAnchor;
            layoutParams.gravity = 8388659;
            int n = view.getHeight();
            int[] arrn = new int[2];
            view.getLocationOnScreen(arrn);
            int n2 = arrn[0];
            int n3 = arrn[1];
            layoutParams.x = n2 + this.mParams.x;
            layoutParams.y = n + (n3 + this.mParams.y) - this.getSystemBarHeight();
        } else if (this.mParams.mAtLocationGravity != 0) {
            layoutParams.gravity = this.mParams.mAtLocationGravity;
            layoutParams.x = this.mParams.x;
            layoutParams.y = this.mParams.y - this.getSystemBarHeight();
        } else {
            layoutParams.gravity = this.mParams.mGravity;
            if (this.mParams.mProviderContent.getMode() == ProviderContent.Mode.MULTIPLE && layoutParams.gravity == 80) {
                layoutParams.y = 20;
            }
        }
        if (this.mParams.mPadding != null) {
            int[] arrn = this.mParams.mPadding;
            layoutParams.width = -1;
            window.getDecorView().setPadding(AutoUtils.scaleValue(arrn[0]), AutoUtils.scaleValue(arrn[1]), AutoUtils.scaleValue(arrn[2]), AutoUtils.scaleValue(arrn[3]));
        }
        if (this.mParams.mAnimStyle != 0) {
            window.setWindowAnimations(this.mParams.mAnimStyle);
        }
        if (this.mParams.isDimEnabled) {
            window.addFlags(2);
        } else {
            window.clearFlags(2);
        }
        if (this.mParams.mConfigDialog != null) {
            this.mParams.mConfigDialog.onConfig(dialog, window, layoutParams, displayMetrics);
        }
        window.setAttributes(layoutParams);
    }

    public abstract View createView();

    public final Dialog onCreateDialog(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)this.getActivity());
        builder.setView(this.createView());
        AlertDialog alertDialog = builder.create();
        Controller.Params params = this.mParams;
        if (params != null) {
            params.mDialogFragment = this;
            alertDialog.setCanceledOnTouchOutside(this.mParams.mCanceledOnTouchOutside);
        }
        return alertDialog;
    }

    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
        this.mParams = null;
    }

    public void onStart() {
        Controller.Params params;
        super.onStart();
        Dialog dialog = this.getDialog();
        if (dialog != null && (params = this.mParams) != null) {
            this.setCancelable(params.mCancelable);
            this.setDialogGravity(dialog);
        }
    }

    public void show(FragmentManager fragmentManager, String string2) {
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.setTransition(4097);
        fragmentTransaction.add((Fragment)this, string2);
        fragmentTransaction.commitAllowingStateLoss();
    }

}

