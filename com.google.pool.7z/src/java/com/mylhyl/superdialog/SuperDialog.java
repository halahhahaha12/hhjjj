/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.content.DialogInterface
 *  android.util.DisplayMetrics
 *  android.view.View
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.view.animation.Animation
 *  androidx.fragment.app.DialogFragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.fragment.app.FragmentManager
 *  java.lang.Object
 *  java.lang.String
 */
package com.mylhyl.superdialog;

import android.app.Dialog;
import android.content.DialogInterface;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import com.mylhyl.superdialog.BaseDialog;
import com.mylhyl.superdialog.view.Controller;

public final class SuperDialog
extends BaseDialog {
    private Controller mController;

    private void refreshProviderContent(Animation animation) {
        this.mController.refreshProviderContent(animation);
    }

    private void setController(Builder builder) {
        Controller controller;
        this.mController = controller = new Controller(builder.mParams);
        controller.apply();
        this.mParams = builder.mParams;
    }

    @Override
    public View createView() {
        Controller controller = this.mController;
        if (controller == null) {
            return null;
        }
        return controller.createView();
    }

}

