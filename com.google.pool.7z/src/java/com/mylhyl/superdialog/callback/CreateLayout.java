/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  java.lang.Object
 */
package com.mylhyl.superdialog.callback;

import android.view.View;

public interface CreateLayout {
    public void buildHead();

    public View buildInputBody();

    public void buildInputFooter(View var1);

    public void buildMultipleBody();

    public void buildMultipleFooter();

    public void buildSingleBody();

    public void buildSingleFooter();

    public View buildView();

    public View findMultipleBody();

    public View findSingleBody();
}

