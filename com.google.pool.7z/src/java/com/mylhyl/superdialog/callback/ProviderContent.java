/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.mylhyl.superdialog.callback;

public abstract class ProviderContent {
    public Object getItems() {
        return null;
    }

    public abstract Mode getMode();

    public int getTextColor() {
        return -7368817;
    }

    public int getTextSize() {
        return 50;
    }

    public static final class Mode
    extends Enum<Mode> {
        private static final /* synthetic */ Mode[] $VALUES;
        public static final /* enum */ Mode INPUT;
        public static final /* enum */ Mode MULTIPLE;
        public static final /* enum */ Mode SINGLE;

        static {
            Mode mode;
            Mode mode2;
            Mode mode3;
            SINGLE = mode2 = new Mode();
            MULTIPLE = mode3 = new Mode();
            INPUT = mode = new Mode();
            $VALUES = new Mode[]{mode2, mode3, mode};
        }

        public static Mode valueOf(String string2) {
            return (Mode)Enum.valueOf(Mode.class, (String)string2);
        }

        public static Mode[] values() {
            return (Mode[])$VALUES.clone();
        }
    }

}

