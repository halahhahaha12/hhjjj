/*
 * Decompiled with CFR 0.0.
 */
package com.mylhyl.superdialog.callback;

import com.mylhyl.superdialog.callback.Provider;

public abstract class ProviderHeader
extends Provider {
    public int getHeight() {
        return 170;
    }

    public int getTextColor() {
        return -16777216;
    }

    public int getTextSize() {
        return 60;
    }
}

