/*
 * Decompiled with CFR 0.0.
 */
package com.mylhyl.superdialog.callback;

import com.mylhyl.superdialog.SuperDialog;
import com.mylhyl.superdialog.callback.ProviderFooterPositive;

public abstract class ProviderFooterPositiveInput
extends ProviderFooterPositive {
    public abstract SuperDialog.OnClickPositiveInputListener getOnPositiveInputListener();

    @Override
    public final SuperDialog.OnClickPositiveListener getOnPositiveListener() {
        return null;
    }
}

