/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.mylhyl.superdialog.SuperDialog
 *  java.lang.Object
 */
package com.mylhyl.superdialog.callback;

import com.mylhyl.superdialog.SuperDialog;
import com.mylhyl.superdialog.callback.ProviderContent;

public abstract class ProviderContentMultiple
extends ProviderContent {
    public abstract void dismiss();

    public abstract SuperDialog.OnItemClickListener getItemClickListener();

    public abstract int getItemHeight();

    @Override
    public Object getItems() {
        return null;
    }

    @Override
    public ProviderContent.Mode getMode() {
        return ProviderContent.Mode.MULTIPLE;
    }
}

