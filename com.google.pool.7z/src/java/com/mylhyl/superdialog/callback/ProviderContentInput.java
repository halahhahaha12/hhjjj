/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.mylhyl.superdialog.callback;

import com.mylhyl.superdialog.callback.ProviderContent;

public abstract class ProviderContentInput
extends ProviderContent {
    public abstract int getHintTextColor();

    public abstract int getInputHeight();

    @Override
    public String getItems() {
        return null;
    }

    public abstract int[] getMargins();

    @Override
    public ProviderContent.Mode getMode() {
        return ProviderContent.Mode.INPUT;
    }
}

