/*
 * Decompiled with CFR 0.0.
 */
package com.mylhyl.superdialog.callback;

import com.mylhyl.superdialog.SuperDialog;
import com.mylhyl.superdialog.callback.ProviderFooter;

public abstract class ProviderFooterPositive
extends ProviderFooter {
    public abstract SuperDialog.OnClickPositiveListener getOnPositiveListener();

    @Override
    public int getTextColor() {
        return -50384;
    }
}

