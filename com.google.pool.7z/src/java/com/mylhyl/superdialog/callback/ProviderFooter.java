/*
 * Decompiled with CFR 0.0.
 */
package com.mylhyl.superdialog.callback;

import com.mylhyl.superdialog.callback.Provider;

public abstract class ProviderFooter
extends Provider {
    public abstract void dismiss();

    public int getHeight() {
        return 150;
    }

    public abstract int getTextColor();

    public int getTextSize() {
        return 40;
    }
}

