/*
 * Decompiled with CFR 0.0.
 */
package com.mylhyl.superdialog.callback;

import com.mylhyl.superdialog.SuperDialog;
import com.mylhyl.superdialog.callback.ProviderFooter;

public abstract class ProviderFooterNegative
extends ProviderFooter {
    public abstract SuperDialog.OnClickNegativeListener getOnNegativeListener();
}

