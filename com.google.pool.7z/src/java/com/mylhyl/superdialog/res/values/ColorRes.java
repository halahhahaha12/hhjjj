/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.mylhyl.superdialog.res.values;

public class ColorRes {
    public static final int bgDialog = -460552;
    public static final int buttonPress = -1381654;
    public static final int content = -7368817;
    public static final int divider = -2631717;
    public static final int negativeButton = -16745729;
    public static final int positiveButton = -50384;
    public static final int title = -16777216;
}

