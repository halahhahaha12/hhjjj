/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.mylhyl.superdialog.res.values;

public class DimenRes {
    public static final int[] contentMargins;
    public static final int[] contentPadding;
    public static final int contentTextSize = 50;
    public static final int footerHeight = 150;
    public static final int footerTextSize = 40;
    public static final int headerHeight = 170;
    public static final int headerTextSize = 60;
    public static final int inputHeight = 340;
    public static final int radius = 30;

    static {
        contentPadding = new int[]{100, 125, 100, 125};
        contentMargins = new int[]{50, 45, 50, 55};
    }
}

