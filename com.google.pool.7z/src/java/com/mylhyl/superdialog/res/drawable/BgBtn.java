/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.ShapeDrawable
 *  android.graphics.drawable.StateListDrawable
 *  android.graphics.drawable.shapes.RoundRectShape
 *  android.graphics.drawable.shapes.Shape
 */
package com.mylhyl.superdialog.res.drawable;

import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.StateListDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import com.mylhyl.superdialog.res.drawable.BgRoundRectShape;

public class BgBtn
extends StateListDrawable {
    public BgBtn(int n, int n2, int n3, int n4, int n5) {
        ShapeDrawable shapeDrawable = new ShapeDrawable((Shape)new BgRoundRectShape(n, n2, n3, n4).getRoundRectShape());
        shapeDrawable.getPaint().setColor(-1381654);
        ShapeDrawable shapeDrawable2 = new ShapeDrawable((Shape)new BgRoundRectShape(n, n2, n3, n4).getRoundRectShape());
        shapeDrawable2.getPaint().setColor(n5);
        this.addState(new int[]{16842919}, (Drawable)shapeDrawable);
        this.addState(new int[]{-16842919}, (Drawable)shapeDrawable2);
    }
}

