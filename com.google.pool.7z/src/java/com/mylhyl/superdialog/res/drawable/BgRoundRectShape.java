/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.RectF
 *  android.graphics.drawable.shapes.RoundRectShape
 *  java.lang.Object
 */
package com.mylhyl.superdialog.res.drawable;

import android.graphics.RectF;
import android.graphics.drawable.shapes.RoundRectShape;

class BgRoundRectShape {
    private RoundRectShape mRoundRectShape;

    public BgRoundRectShape(int n, int n2, int n3, int n4) {
        float[] arrf = new float[8];
        if (n > 0) {
            float f;
            arrf[0] = f = (float)n;
            arrf[1] = f;
        }
        if (n2 > 0) {
            float f;
            arrf[2] = f = (float)n2;
            arrf[3] = f;
        }
        if (n3 > 0) {
            float f;
            arrf[4] = f = (float)n3;
            arrf[5] = f;
        }
        if (n4 > 0) {
            float f;
            arrf[6] = f = (float)n4;
            arrf[7] = f;
        }
        this.mRoundRectShape = new RoundRectShape(arrf, null, null);
    }

    public RoundRectShape getRoundRectShape() {
        return this.mRoundRectShape;
    }
}

