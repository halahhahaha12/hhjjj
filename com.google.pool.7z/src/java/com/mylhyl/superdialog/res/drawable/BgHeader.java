/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.drawable.ShapeDrawable
 *  android.graphics.drawable.shapes.RoundRectShape
 *  android.graphics.drawable.shapes.Shape
 */
package com.mylhyl.superdialog.res.drawable;

import android.graphics.Paint;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import com.mylhyl.superdialog.res.drawable.BgRoundRectShape;
import com.mylhyl.superdialog.view.Controller;

public class BgHeader
extends ShapeDrawable {
    public BgHeader(Controller.Params params) {
        this.getPaint().setColor(params.mBackgroundColor);
        int n = params.mRadius;
        this.setShape((Shape)new BgRoundRectShape(n, n, 0, 0).getRoundRectShape());
    }
}

