/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AppOpsManager
 *  android.app.NotificationManager
 *  android.content.Context
 *  android.content.ContextWrapper
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.AssetManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.provider.Settings
 *  android.provider.Settings$System
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.NoSuchFieldException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SafeVarargs
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Random
 */
package com.hjq.permissions;

import android.app.Activity;
import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import com.hjq.permissions.Permission;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

final class PermissionUtils {
    PermissionUtils() {
    }

    static /* varargs */ <T> ArrayList<T> asArrayList(T ... arrT) {
        if (arrT != null && arrT.length != 0) {
            ArrayList arrayList = new ArrayList(arrT.length);
            int n = arrT.length;
            for (int i = 0; i < n; ++i) {
                arrayList.add(arrT[i]);
            }
            return arrayList;
        }
        return null;
    }

    @SafeVarargs
    static /* varargs */ <T> ArrayList<T> asArrayLists(T[] ... arrT) {
        ArrayList arrayList = new ArrayList();
        if (arrT != null) {
            if (arrT.length == 0) {
                return arrayList;
            }
            int n = arrT.length;
            for (int i = 0; i < n; ++i) {
                arrayList.addAll(PermissionUtils.asArrayList(arrT[i]));
            }
        }
        return arrayList;
    }

    static boolean containsSpecialPermission(List<String> list) {
        if (list != null) {
            if (list.isEmpty()) {
                return false;
            }
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                if (!PermissionUtils.isSpecialPermission((String)iterator.next())) continue;
                return true;
            }
        }
        return false;
    }

    static Activity findActivity(Context context) {
        do {
            if (!(context instanceof Activity)) continue;
            return (Activity)context;
        } while (context instanceof ContextWrapper && (context = ((ContextWrapper)context).getBaseContext()) != null);
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static int findApkPathCookie(Context context) {
        AssetManager assetManager = context.getAssets();
        String string2 = context.getApplicationInfo().sourceDir;
        try {
            return (Integer)assetManager.getClass().getDeclaredMethod("addOverlayPath", new Class[]{String.class}).invoke((Object)assetManager, new Object[]{string2});
        }
        catch (Exception exception) {
            String[] arrstring;
            try {
                exception.printStackTrace();
                arrstring = (String[])assetManager.getClass().getDeclaredMethod("getApkPaths", new Class[0]).invoke((Object)assetManager, new Object[0]);
                if (arrstring == null) {
                    return 0;
                }
            }
            catch (Exception exception2) {
                exception2.printStackTrace();
                return 0;
            }
            int n = 0;
            while (n < arrstring.length) {
                boolean bl = arrstring[n].equals((Object)string2);
                if (bl) {
                    return n + 1;
                }
                ++n;
            }
            return 0;
        }
    }

    static List<String> getDeniedPermissions(Context context, List<String> list) {
        ArrayList arrayList = new ArrayList(list.size());
        if (!PermissionUtils.isAndroid6()) {
            return arrayList;
        }
        for (String string2 : list) {
            if (PermissionUtils.isGrantedPermission(context, string2)) continue;
            arrayList.add((Object)string2);
        }
        return arrayList;
    }

    static List<String> getDeniedPermissions(String[] arrstring, int[] arrn) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < arrn.length; ++i) {
            if (arrn[i] != -1) continue;
            arrayList.add((Object)arrstring[i]);
        }
        return arrayList;
    }

    static List<String> getGrantedPermissions(String[] arrstring, int[] arrn) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < arrn.length; ++i) {
            if (arrn[i] != 0) continue;
            arrayList.add((Object)arrstring[i]);
        }
        return arrayList;
    }

    static List<String> getManifestPermissions(Context context) {
        try {
            ArrayList<String> arrayList = PermissionUtils.asArrayList(context.getPackageManager().getPackageInfo((String)context.getPackageName(), (int)4096).requestedPermissions);
            return arrayList;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            nameNotFoundException.printStackTrace();
            return null;
        }
    }

    static int getPermissionStatus(Context context, String string2) {
        if (PermissionUtils.isGrantedPermission(context, string2)) {
            return 0;
        }
        return -1;
    }

    static int getRandomRequestCode() {
        return new Random().nextInt((int)Math.pow((double)2.0, (double)8.0));
    }

    static boolean isAndroid10() {
        return Build.VERSION.SDK_INT >= 29;
    }

    static boolean isAndroid11() {
        return Build.VERSION.SDK_INT >= 30;
    }

    static boolean isAndroid6() {
        return Build.VERSION.SDK_INT >= 23;
    }

    static boolean isAndroid7() {
        return Build.VERSION.SDK_INT >= 24;
    }

    static boolean isAndroid8() {
        return Build.VERSION.SDK_INT >= 26;
    }

    static boolean isAndroid9() {
        return Build.VERSION.SDK_INT >= 28;
    }

    static boolean isGrantedInstallPermission(Context context) {
        if (PermissionUtils.isAndroid8()) {
            return context.getPackageManager().canRequestPackageInstalls();
        }
        return true;
    }

    static boolean isGrantedNotifyPermission(Context context) {
        if (PermissionUtils.isAndroid7()) {
            return ((NotificationManager)context.getSystemService(NotificationManager.class)).areNotificationsEnabled();
        }
        if (PermissionUtils.isAndroid6()) {
            void var2_13;
            AppOpsManager appOpsManager = (AppOpsManager)context.getSystemService("appops");
            try {
                Class class_ = appOpsManager.getClass();
                Class[] arrclass = new Class[]{Integer.TYPE, Integer.TYPE, String.class};
                Method method = class_.getMethod("checkOpNoThrow", arrclass);
                int n = (Integer)appOpsManager.getClass().getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class);
                Object[] arrobject = new Object[]{n, context.getApplicationInfo().uid, context.getPackageName()};
                int n2 = (Integer)method.invoke((Object)appOpsManager, arrobject);
                return n2 == 0;
            }
            catch (RuntimeException runtimeException) {
            }
            catch (IllegalAccessException illegalAccessException) {
            }
            catch (InvocationTargetException invocationTargetException) {
            }
            catch (NoSuchFieldException noSuchFieldException) {
            }
            catch (NoSuchMethodException noSuchMethodException) {
                // empty catch block
            }
            var2_13.printStackTrace();
        }
        return true;
    }

    static boolean isGrantedPermission(Context context, String string2) {
        if (!PermissionUtils.isAndroid6()) {
            return true;
        }
        if ("android.permission.MANAGE_EXTERNAL_STORAGE".equals((Object)string2)) {
            return PermissionUtils.isGrantedStoragePermission(context);
        }
        if ("android.permission.REQUEST_INSTALL_PACKAGES".equals((Object)string2)) {
            return PermissionUtils.isGrantedInstallPermission(context);
        }
        if ("android.permission.SYSTEM_ALERT_WINDOW".equals((Object)string2)) {
            return PermissionUtils.isGrantedWindowPermission(context);
        }
        if ("android.permission.NOTIFICATION_SERVICE".equals((Object)string2)) {
            return PermissionUtils.isGrantedNotifyPermission(context);
        }
        if ("android.permission.WRITE_SETTINGS".equals((Object)string2)) {
            return PermissionUtils.isGrantedSettingPermission(context);
        }
        if (!PermissionUtils.isAndroid10()) {
            if ("android.permission.ACCESS_BACKGROUND_LOCATION".equals((Object)string2)) {
                return context.checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0;
            }
            if ("android.permission.ACTIVITY_RECOGNITION".equals((Object)string2)) {
                return context.checkSelfPermission("android.permission.BODY_SENSORS") == 0;
            }
            if ("android.permission.ACCESS_MEDIA_LOCATION".equals((Object)string2)) {
                return true;
            }
        }
        if (!PermissionUtils.isAndroid9() && "android.permission.ACCEPT_HANDOVER".equals((Object)string2)) {
            return true;
        }
        if (!PermissionUtils.isAndroid8()) {
            if ("android.permission.ANSWER_PHONE_CALLS".equals((Object)string2)) {
                return true;
            }
            if ("android.permission.READ_PHONE_NUMBERS".equals((Object)string2)) {
                return context.checkSelfPermission("android.permission.READ_PHONE_STATE") == 0;
            }
        }
        return context.checkSelfPermission(string2) == 0;
    }

    static boolean isGrantedPermissions(Context context, List<String> list) {
        if (!PermissionUtils.isAndroid6()) {
            return true;
        }
        if (list != null) {
            if (list.isEmpty()) {
                return false;
            }
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                if (PermissionUtils.isGrantedPermission(context, (String)iterator.next())) continue;
                return false;
            }
            return true;
        }
        return false;
    }

    static boolean isGrantedSettingPermission(Context context) {
        if (PermissionUtils.isAndroid6()) {
            return Settings.System.canWrite((Context)context);
        }
        return true;
    }

    static boolean isGrantedStoragePermission(Context context) {
        if (PermissionUtils.isAndroid11()) {
            return Environment.isExternalStorageManager();
        }
        return PermissionUtils.isGrantedPermissions(context, PermissionUtils.asArrayList(Permission.Group.STORAGE));
    }

    static boolean isGrantedWindowPermission(Context context) {
        if (PermissionUtils.isAndroid6()) {
            return Settings.canDrawOverlays((Context)context);
        }
        return true;
    }

    static boolean isPermissionPermanentDenied(Activity activity, String string2) {
        if (!PermissionUtils.isAndroid6()) {
            return false;
        }
        if (PermissionUtils.isSpecialPermission(string2)) {
            return false;
        }
        if (PermissionUtils.isAndroid10() && "android.permission.ACCESS_BACKGROUND_LOCATION".equals((Object)string2) && !PermissionUtils.isGrantedPermission((Context)activity, "android.permission.ACCESS_BACKGROUND_LOCATION") && !PermissionUtils.isGrantedPermission((Context)activity, "android.permission.ACCESS_FINE_LOCATION")) {
            return true ^ activity.shouldShowRequestPermissionRationale("android.permission.ACCESS_FINE_LOCATION");
        }
        if (!PermissionUtils.isAndroid10()) {
            if ("android.permission.ACCESS_BACKGROUND_LOCATION".equals((Object)string2)) {
                boolean bl = PermissionUtils.isGrantedPermission((Context)activity, "android.permission.ACCESS_FINE_LOCATION");
                boolean bl2 = false;
                if (!bl) {
                    boolean bl3 = activity.shouldShowRequestPermissionRationale("android.permission.ACCESS_FINE_LOCATION");
                    bl2 = false;
                    if (!bl3) {
                        bl2 = true;
                    }
                }
                return bl2;
            }
            if ("android.permission.ACTIVITY_RECOGNITION".equals((Object)string2)) {
                boolean bl = PermissionUtils.isGrantedPermission((Context)activity, "android.permission.BODY_SENSORS");
                boolean bl4 = false;
                if (!bl) {
                    boolean bl5 = activity.shouldShowRequestPermissionRationale("android.permission.BODY_SENSORS");
                    bl4 = false;
                    if (!bl5) {
                        bl4 = true;
                    }
                }
                return bl4;
            }
            if ("android.permission.ACCESS_MEDIA_LOCATION".equals((Object)string2)) {
                return false;
            }
        }
        if (!PermissionUtils.isAndroid9() && "android.permission.ACCEPT_HANDOVER".equals((Object)string2)) {
            return false;
        }
        if (!PermissionUtils.isAndroid8()) {
            if ("android.permission.ANSWER_PHONE_CALLS".equals((Object)string2)) {
                return true;
            }
            if ("android.permission.READ_PHONE_NUMBERS".equals((Object)string2)) {
                boolean bl = PermissionUtils.isGrantedPermission((Context)activity, "android.permission.READ_PHONE_STATE");
                boolean bl6 = false;
                if (!bl) {
                    boolean bl7 = activity.shouldShowRequestPermissionRationale("android.permission.READ_PHONE_STATE");
                    bl6 = false;
                    if (!bl7) {
                        bl6 = true;
                    }
                }
                return bl6;
            }
        }
        boolean bl = PermissionUtils.isGrantedPermission((Context)activity, string2);
        boolean bl8 = false;
        if (!bl) {
            boolean bl9 = activity.shouldShowRequestPermissionRationale(string2);
            bl8 = false;
            if (!bl9) {
                bl8 = true;
            }
        }
        return bl8;
    }

    static boolean isPermissionPermanentDenied(Activity activity, List<String> list) {
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            if (!PermissionUtils.isPermissionPermanentDenied(activity, (String)iterator.next())) continue;
            return true;
        }
        return false;
    }

    static boolean isSpecialPermission(String string2) {
        return "android.permission.MANAGE_EXTERNAL_STORAGE".equals((Object)string2) || "android.permission.REQUEST_INSTALL_PACKAGES".equals((Object)string2) || "android.permission.SYSTEM_ALERT_WINDOW".equals((Object)string2) || "android.permission.NOTIFICATION_SERVICE".equals((Object)string2) || "android.permission.WRITE_SETTINGS".equals((Object)string2);
        {
        }
    }
}

