/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.hjq.permissions;

final class ManifestRegisterException
extends RuntimeException {
    ManifestRegisterException() {
        super("No permissions are registered in the manifest file");
    }

    ManifestRegisterException(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append(": Permissions are not registered in the manifest file");
        super(stringBuilder.toString());
    }
}

