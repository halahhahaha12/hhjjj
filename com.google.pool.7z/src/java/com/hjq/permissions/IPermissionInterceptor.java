/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.hjq.permissions;

import android.app.Activity;
import com.hjq.permissions.OnPermissionCallback;
import java.util.List;

public interface IPermissionInterceptor {
    public void deniedPermissions(Activity var1, OnPermissionCallback var2, List<String> var3, boolean var4);

    public void grantedPermissions(Activity var1, OnPermissionCallback var2, List<String> var3, boolean var4);

    public void requestPermissions(Activity var1, OnPermissionCallback var2, List<String> var3);
}

