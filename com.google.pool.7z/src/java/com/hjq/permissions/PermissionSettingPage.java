/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.net.Uri
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 */
package com.hjq.permissions;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import com.hjq.permissions.PermissionUtils;
import java.util.List;

final class PermissionSettingPage {
    PermissionSettingPage() {
    }

    private static boolean areActivityIntent(Context context, Intent intent) {
        return true ^ context.getPackageManager().queryIntentActivities(intent, 65536).isEmpty();
    }

    static Intent getApplicationDetailsIntent(Context context) {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(PermissionSettingPage.getPackageNameUri(context));
        return intent;
    }

    static Intent getInstallPermissionIntent(Context context) {
        Intent intent;
        if (PermissionUtils.isAndroid8()) {
            intent = new Intent("android.settings.MANAGE_UNKNOWN_APP_SOURCES");
            intent.setData(PermissionSettingPage.getPackageNameUri(context));
        } else {
            intent = null;
        }
        if (intent == null || !PermissionSettingPage.areActivityIntent(context, intent)) {
            intent = PermissionSettingPage.getApplicationDetailsIntent(context);
        }
        return intent;
    }

    static Intent getNotifyPermissionIntent(Context context) {
        Intent intent;
        if (PermissionUtils.isAndroid8()) {
            intent = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
            intent.putExtra("android.provider.extra.APP_PACKAGE", context.getPackageName());
        } else {
            intent = null;
        }
        if (intent == null || !PermissionSettingPage.areActivityIntent(context, intent)) {
            intent = PermissionSettingPage.getApplicationDetailsIntent(context);
        }
        return intent;
    }

    private static Uri getPackageNameUri(Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("package:");
        stringBuilder.append(context.getPackageName());
        return Uri.parse((String)stringBuilder.toString());
    }

    static Intent getSettingPermissionIntent(Context context) {
        Intent intent;
        if (PermissionUtils.isAndroid6()) {
            intent = new Intent("android.settings.action.MANAGE_WRITE_SETTINGS");
            intent.setData(PermissionSettingPage.getPackageNameUri(context));
        } else {
            intent = null;
        }
        if (intent == null || !PermissionSettingPage.areActivityIntent(context, intent)) {
            intent = PermissionSettingPage.getApplicationDetailsIntent(context);
        }
        return intent;
    }

    static Intent getSmartPermissionIntent(Context context, List<String> list) {
        if (list != null && !list.isEmpty() && PermissionUtils.containsSpecialPermission(list)) {
            if (PermissionUtils.isAndroid11() && list.size() == 3 && list.contains((Object)"android.permission.MANAGE_EXTERNAL_STORAGE") && list.contains((Object)"android.permission.READ_EXTERNAL_STORAGE") && list.contains((Object)"android.permission.WRITE_EXTERNAL_STORAGE")) {
                return PermissionSettingPage.getStoragePermissionIntent(context);
            }
            if (list.size() == 1) {
                String string2 = (String)list.get(0);
                if ("android.permission.MANAGE_EXTERNAL_STORAGE".equals((Object)string2)) {
                    return PermissionSettingPage.getStoragePermissionIntent(context);
                }
                if ("android.permission.REQUEST_INSTALL_PACKAGES".equals((Object)string2)) {
                    return PermissionSettingPage.getInstallPermissionIntent(context);
                }
                if ("android.permission.SYSTEM_ALERT_WINDOW".equals((Object)string2)) {
                    return PermissionSettingPage.getWindowPermissionIntent(context);
                }
                if ("android.permission.NOTIFICATION_SERVICE".equals((Object)string2)) {
                    return PermissionSettingPage.getNotifyPermissionIntent(context);
                }
                if ("android.permission.WRITE_SETTINGS".equals((Object)string2)) {
                    return PermissionSettingPage.getSettingPermissionIntent(context);
                }
            }
            return PermissionSettingPage.getApplicationDetailsIntent(context);
        }
        return PermissionSettingPage.getApplicationDetailsIntent(context);
    }

    static Intent getStoragePermissionIntent(Context context) {
        Intent intent;
        if (PermissionUtils.isAndroid11()) {
            intent = new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION");
            intent.setData(PermissionSettingPage.getPackageNameUri(context));
        } else {
            intent = null;
        }
        if (intent == null || !PermissionSettingPage.areActivityIntent(context, intent)) {
            intent = PermissionSettingPage.getApplicationDetailsIntent(context);
        }
        return intent;
    }

    static Intent getWindowPermissionIntent(Context context) {
        Intent intent;
        if (PermissionUtils.isAndroid6()) {
            intent = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION");
            intent.setData(PermissionSettingPage.getPackageNameUri(context));
        } else {
            intent = null;
        }
        if (intent == null || !PermissionSettingPage.areActivityIntent(context, intent)) {
            intent = PermissionSettingPage.getApplicationDetailsIntent(context);
        }
        return intent;
    }
}

