/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.hjq.permissions;

import java.util.List;

public interface OnPermissionCallback {
    public void onDenied(List<String> var1, boolean var2);

    public void onGranted(List<String> var1, boolean var2);
}

