/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.res.AssetManager
 *  android.content.res.XmlResourceParser
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Field
 *  java.util.ArrayList
 *  java.util.List
 *  org.xmlpull.v1.XmlPullParserException
 */
package com.hjq.permissions;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.AssetManager;
import android.content.res.XmlResourceParser;
import android.os.Build;
import com.hjq.permissions.ManifestRegisterException;
import com.hjq.permissions.Permission;
import com.hjq.permissions.PermissionUtils;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParserException;

final class PermissionChecker {
    PermissionChecker() {
    }

    static boolean checkActivityStatus(Activity activity, boolean bl) {
        if (activity == null) {
            if (!bl) {
                return false;
            }
            throw new IllegalArgumentException("The instance of the Context must be an Activity object");
        }
        if (activity.isFinishing()) {
            if (!bl) {
                return false;
            }
            throw new IllegalStateException("The Activity has been finishing, Please manually determine the status of the Activity");
        }
        if (Build.VERSION.SDK_INT >= 17 && activity.isDestroyed()) {
            if (!bl) {
                return false;
            }
            throw new IllegalStateException("The Activity has been destroyed, Please manually determine the status of the Activity");
        }
        return true;
    }

    static void checkLocationPermission(List<String> list) {
        if (!list.contains((Object)"android.permission.ACCESS_BACKGROUND_LOCATION")) {
            return;
        }
        if (list.contains((Object)"android.permission.ACCESS_COARSE_LOCATION") && !list.contains((Object)"android.permission.ACCESS_FINE_LOCATION")) {
            throw new IllegalArgumentException("The application for background location permissions must include precise location permissions");
        }
        for (String string2 : list) {
            if ("android.permission.ACCESS_FINE_LOCATION".equals((Object)string2) || "android.permission.ACCESS_COARSE_LOCATION".equals((Object)string2) || "android.permission.ACCESS_BACKGROUND_LOCATION".equals((Object)string2)) continue;
            throw new IllegalArgumentException("Because it includes background location permissions, do not apply for permissions unrelated to location");
        }
    }

    static boolean checkPermissionArgument(List<String> list, boolean bl) {
        IllegalArgumentException illegalArgumentException;
        if (list != null && !list.isEmpty()) {
            if (bl) {
                ArrayList arrayList = new ArrayList();
                Field[] arrfield = Permission.class.getDeclaredFields();
                if (arrfield.length == 0) {
                    return true;
                }
                for (Field field : arrfield) {
                    if (!String.class.equals((Object)field.getType())) continue;
                    try {
                        arrayList.add((Object)((String)field.get(null)));
                    }
                    catch (IllegalAccessException illegalAccessException) {
                        illegalAccessException.printStackTrace();
                    }
                }
                for (String string2 : list) {
                    if (arrayList.contains((Object)string2)) continue;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("The ");
                    stringBuilder.append(string2);
                    stringBuilder.append(" is not a dangerous permission or special permission");
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
            }
            return true;
        }
        if (!bl) {
            return false;
        }
        illegalArgumentException = new IllegalArgumentException("The requested permission cannot be empty");
        throw illegalArgumentException;
    }

    static void checkPermissionManifest(Context context, List<String> list) {
        ManifestRegisterException manifestRegisterException;
        List<String> list2 = PermissionUtils.getManifestPermissions(context);
        if (list2 != null && !list2.isEmpty()) {
            int n = Build.VERSION.SDK_INT >= 24 ? context.getApplicationInfo().minSdkVersion : 23;
            for (String string2 : list) {
                if (n < 30 && "android.permission.MANAGE_EXTERNAL_STORAGE".equals((Object)string2)) {
                    if (list2.contains((Object)"android.permission.READ_EXTERNAL_STORAGE")) {
                        if (!list2.contains((Object)"android.permission.WRITE_EXTERNAL_STORAGE")) {
                            throw new ManifestRegisterException("android.permission.WRITE_EXTERNAL_STORAGE");
                        }
                    } else {
                        throw new ManifestRegisterException("android.permission.READ_EXTERNAL_STORAGE");
                    }
                }
                if (n < 29 && "android.permission.ACTIVITY_RECOGNITION".equals((Object)string2) && !list2.contains((Object)"android.permission.BODY_SENSORS")) {
                    throw new ManifestRegisterException("android.permission.BODY_SENSORS");
                }
                if (n < 26 && "android.permission.READ_PHONE_NUMBERS".equals((Object)string2) && !list2.contains((Object)"android.permission.READ_PHONE_STATE")) {
                    throw new ManifestRegisterException("android.permission.READ_PHONE_STATE");
                }
                if ("android.permission.NOTIFICATION_SERVICE".equals((Object)string2) || list2.contains((Object)string2)) continue;
                throw new ManifestRegisterException(string2);
            }
            return;
        }
        manifestRegisterException = new ManifestRegisterException();
        throw manifestRegisterException;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void checkStoragePermission(Context context, List<String> list, boolean bl) {
        void var4_9;
        if (!(list.contains((Object)"android.permission.MANAGE_EXTERNAL_STORAGE") || list.contains((Object)"android.permission.READ_EXTERNAL_STORAGE") || list.contains((Object)"android.permission.WRITE_EXTERNAL_STORAGE"))) {
            return;
        }
        int n = PermissionUtils.findApkPathCookie(context);
        if (n == 0) {
            return;
        }
        try {
            XmlResourceParser xmlResourceParser = context.getAssets().openXmlResourceParser(n, "AndroidManifest.xml");
            while (xmlResourceParser.getEventType() != 1) {
                if (xmlResourceParser.getEventType() == 2 && "application".equals((Object)xmlResourceParser.getName())) {
                    int n2 = context.getApplicationInfo().targetSdkVersion;
                    boolean bl2 = xmlResourceParser.getAttributeBooleanValue("http://schemas.android.com/apk/res/android", "requestLegacyExternalStorage", false);
                    if (!(n2 < 29 || bl2 || !list.contains((Object)"android.permission.MANAGE_EXTERNAL_STORAGE") && bl)) {
                        throw new IllegalStateException("Please register the android:requestLegacyExternalStorage=\"true\" attribute in the manifest file");
                    }
                    if (n2 < 30 || list.contains((Object)"android.permission.MANAGE_EXTERNAL_STORAGE") || bl) break;
                    throw new IllegalArgumentException("Please adapt the scoped storage, or use the MANAGE_EXTERNAL_STORAGE permission");
                }
                xmlResourceParser.next();
            }
            xmlResourceParser.close();
            return;
        }
        catch (XmlPullParserException xmlPullParserException) {
        }
        catch (IOException iOException) {
            // empty catch block
        }
        var4_9.printStackTrace();
    }

    static void checkTargetSdkVersion(Context context, List<String> list) {
        int n = list.contains((Object)"android.permission.MANAGE_EXTERNAL_STORAGE") ? 30 : (list.contains((Object)"android.permission.ACCEPT_HANDOVER") ? 28 : (!(list.contains((Object)"android.permission.ACCESS_BACKGROUND_LOCATION") || list.contains((Object)"android.permission.ACTIVITY_RECOGNITION") || list.contains((Object)"android.permission.ACCESS_MEDIA_LOCATION")) ? (!(list.contains((Object)"android.permission.REQUEST_INSTALL_PACKAGES") || list.contains((Object)"android.permission.ANSWER_PHONE_CALLS") || list.contains((Object)"android.permission.READ_PHONE_NUMBERS")) ? 23 : 26) : 29));
        if (context.getApplicationInfo().targetSdkVersion >= n) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("The targetSdkVersion SDK must be ");
        stringBuilder.append(n);
        stringBuilder.append(" or more");
        throw new RuntimeException(stringBuilder.toString());
    }

    static void optimizeDeprecatedPermission(List<String> list) {
        if (list.contains((Object)"android.permission.MANAGE_EXTERNAL_STORAGE")) {
            if (!list.contains((Object)"android.permission.READ_EXTERNAL_STORAGE") && !list.contains((Object)"android.permission.WRITE_EXTERNAL_STORAGE")) {
                if (!PermissionUtils.isAndroid11()) {
                    list.add((Object)"android.permission.READ_EXTERNAL_STORAGE");
                    list.add((Object)"android.permission.WRITE_EXTERNAL_STORAGE");
                }
            } else {
                throw new IllegalArgumentException("If you have applied for MANAGE_EXTERNAL_STORAGE permissions, do not apply for the READ_EXTERNAL_STORAGE and WRITE_EXTERNAL_STORAGE permissions");
            }
        }
        if (!PermissionUtils.isAndroid8() && list.contains((Object)"android.permission.READ_PHONE_NUMBERS") && !list.contains((Object)"android.permission.READ_PHONE_STATE")) {
            list.add((Object)"android.permission.READ_PHONE_STATE");
        }
        if (!PermissionUtils.isAndroid10() && list.contains((Object)"android.permission.ACTIVITY_RECOGNITION") && !list.contains((Object)"android.permission.BODY_SENSORS")) {
            list.add((Object)"android.permission.BODY_SENSORS");
        }
    }
}

