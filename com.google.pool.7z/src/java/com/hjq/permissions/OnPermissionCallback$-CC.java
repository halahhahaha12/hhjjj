/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.List
 */
package com.hjq.permissions;

import com.hjq.permissions.OnPermissionCallback;
import java.util.List;

public final class OnPermissionCallback$-CC {
    public static void $default$onDenied(OnPermissionCallback onPermissionCallback, List list, boolean bl) {
    }
}

