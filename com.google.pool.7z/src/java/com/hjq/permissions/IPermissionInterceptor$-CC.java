/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 */
package com.hjq.permissions;

import android.app.Activity;
import com.hjq.permissions.IPermissionInterceptor;
import com.hjq.permissions.OnPermissionCallback;
import com.hjq.permissions.PermissionFragment;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class IPermissionInterceptor$-CC {
    public static void $default$deniedPermissions(IPermissionInterceptor iPermissionInterceptor, Activity activity, OnPermissionCallback onPermissionCallback, List list, boolean bl) {
        onPermissionCallback.onDenied((List<String>)list, bl);
    }

    public static void $default$grantedPermissions(IPermissionInterceptor iPermissionInterceptor, Activity activity, OnPermissionCallback onPermissionCallback, List list, boolean bl) {
        onPermissionCallback.onGranted((List<String>)list, bl);
    }

    public static void $default$requestPermissions(IPermissionInterceptor iPermissionInterceptor, Activity activity, OnPermissionCallback onPermissionCallback, List list) {
        PermissionFragment.beginRequest(activity, (ArrayList<String>)new ArrayList((Collection)list), onPermissionCallback);
    }
}

