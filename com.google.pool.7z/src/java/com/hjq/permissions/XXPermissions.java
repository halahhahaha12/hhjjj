/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Fragment
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  com.hjq.permissions.XXPermissions$1
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.List
 */
package com.hjq.permissions;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import androidx.fragment.app.FragmentActivity;
import com.hjq.permissions.IPermissionInterceptor;
import com.hjq.permissions.OnPermissionCallback;
import com.hjq.permissions.PermissionChecker;
import com.hjq.permissions.PermissionSettingPage;
import com.hjq.permissions.PermissionUtils;
import com.hjq.permissions.XXPermissions;
import java.util.Collection;
import java.util.List;

public final class XXPermissions {
    public static final int REQUEST_CODE = 1025;
    private static Boolean sDebugMode;
    private static IPermissionInterceptor sPermissionInterceptor;
    private static boolean sScopedStorage;
    private final Context mContext;
    private List<String> mPermissions;

    private XXPermissions(Context context) {
        this.mContext = context;
    }

    public static List<String> getDenied(Context context, List<String> list) {
        return PermissionUtils.getDeniedPermissions(context, list);
    }

    public static /* varargs */ List<String> getDenied(Context context, String ... arrstring) {
        return XXPermissions.getDenied(context, PermissionUtils.asArrayList(arrstring));
    }

    public static /* varargs */ List<String> getDenied(Context context, String[] ... arrstring) {
        return XXPermissions.getDenied(context, PermissionUtils.asArrayLists(arrstring));
    }

    static IPermissionInterceptor getInterceptor() {
        if (sPermissionInterceptor == null) {
            sPermissionInterceptor = new 1();
        }
        return sPermissionInterceptor;
    }

    private static boolean isDebugMode(Context context) {
        if (sDebugMode == null) {
            boolean bl = (2 & context.getApplicationInfo().flags) != 0;
            sDebugMode = bl;
        }
        return sDebugMode;
    }

    public static boolean isGranted(Context context, List<String> list) {
        return PermissionUtils.isGrantedPermissions(context, list);
    }

    public static /* varargs */ boolean isGranted(Context context, String ... arrstring) {
        return XXPermissions.isGranted(context, PermissionUtils.asArrayList(arrstring));
    }

    public static /* varargs */ boolean isGranted(Context context, String[] ... arrstring) {
        return XXPermissions.isGranted(context, PermissionUtils.asArrayLists(arrstring));
    }

    public static boolean isPermanentDenied(Activity activity, List<String> list) {
        return PermissionUtils.isPermissionPermanentDenied(activity, list);
    }

    public static /* varargs */ boolean isPermanentDenied(Activity activity, String ... arrstring) {
        return XXPermissions.isPermanentDenied(activity, PermissionUtils.asArrayList(arrstring));
    }

    public static /* varargs */ boolean isPermanentDenied(Activity activity, String[] ... arrstring) {
        return XXPermissions.isPermanentDenied(activity, PermissionUtils.asArrayLists(arrstring));
    }

    private static boolean isScopedStorage() {
        return sScopedStorage;
    }

    public static boolean isSpecial(String string2) {
        return PermissionUtils.isSpecialPermission(string2);
    }

    public static void setDebugMode(boolean bl) {
        sDebugMode = bl;
    }

    public static void setInterceptor(IPermissionInterceptor iPermissionInterceptor) {
        sPermissionInterceptor = iPermissionInterceptor;
    }

    public static void setScopedStorage(boolean bl) {
        sScopedStorage = bl;
    }

    public static void startPermissionActivity(Activity activity) {
        (List)null;
        XXPermissions.startPermissionActivity(activity, null);
    }

    public static void startPermissionActivity(Activity activity, List<String> list) {
        XXPermissions.startPermissionActivity(activity, list, 1025);
    }

    public static void startPermissionActivity(Activity activity, List<String> list, int n) {
        activity.startActivityForResult(PermissionSettingPage.getSmartPermissionIntent((Context)activity, list), n);
    }

    public static /* varargs */ void startPermissionActivity(Activity activity, String ... arrstring) {
        XXPermissions.startPermissionActivity(activity, PermissionUtils.asArrayList(arrstring));
    }

    public static /* varargs */ void startPermissionActivity(Activity activity, String[] ... arrstring) {
        XXPermissions.startPermissionActivity(activity, PermissionUtils.asArrayLists(arrstring));
    }

    public static void startPermissionActivity(Fragment fragment) {
        (List)null;
        XXPermissions.startPermissionActivity(fragment, null);
    }

    public static void startPermissionActivity(Fragment fragment, List<String> list) {
        XXPermissions.startPermissionActivity(fragment, list, 1025);
    }

    public static void startPermissionActivity(Fragment fragment, List<String> list, int n) {
        Activity activity = fragment.getActivity();
        if (activity == null) {
            return;
        }
        fragment.startActivityForResult(PermissionSettingPage.getSmartPermissionIntent((Context)activity, list), n);
    }

    public static /* varargs */ void startPermissionActivity(Fragment fragment, String ... arrstring) {
        XXPermissions.startPermissionActivity(fragment, PermissionUtils.asArrayList(arrstring));
    }

    public static /* varargs */ void startPermissionActivity(Fragment fragment, String[] ... arrstring) {
        XXPermissions.startPermissionActivity(fragment, PermissionUtils.asArrayLists(arrstring));
    }

    public static void startPermissionActivity(Context context) {
        (List)null;
        XXPermissions.startPermissionActivity(context, null);
    }

    public static void startPermissionActivity(Context context, List<String> list) {
        Activity activity = PermissionUtils.findActivity(context);
        if (activity != null) {
            XXPermissions.startPermissionActivity(activity, list);
            return;
        }
        Intent intent = PermissionSettingPage.getSmartPermissionIntent(context, list);
        if (!(context instanceof Activity)) {
            intent.addFlags(268435456);
        }
        context.startActivity(intent);
    }

    public static /* varargs */ void startPermissionActivity(Context context, String ... arrstring) {
        XXPermissions.startPermissionActivity(context, PermissionUtils.asArrayList(arrstring));
    }

    public static /* varargs */ void startPermissionActivity(Context context, String[] ... arrstring) {
        XXPermissions.startPermissionActivity(context, PermissionUtils.asArrayLists(arrstring));
    }

    public static void startPermissionActivity(androidx.fragment.app.Fragment fragment) {
        (List)null;
        XXPermissions.startPermissionActivity(fragment, null);
    }

    public static void startPermissionActivity(androidx.fragment.app.Fragment fragment, List<String> list) {
        XXPermissions.startPermissionActivity(fragment, list, 1025);
    }

    public static void startPermissionActivity(androidx.fragment.app.Fragment fragment, List<String> list, int n) {
        FragmentActivity fragmentActivity = fragment.getActivity();
        if (fragmentActivity == null) {
            return;
        }
        fragment.startActivityForResult(PermissionSettingPage.getSmartPermissionIntent((Context)fragmentActivity, list), n);
    }

    public static /* varargs */ void startPermissionActivity(androidx.fragment.app.Fragment fragment, String ... arrstring) {
        XXPermissions.startPermissionActivity(fragment, PermissionUtils.asArrayList(arrstring));
    }

    public static /* varargs */ void startPermissionActivity(androidx.fragment.app.Fragment fragment, String[] ... arrstring) {
        XXPermissions.startPermissionActivity(fragment, PermissionUtils.asArrayLists(arrstring));
    }

    public static XXPermissions with(Fragment fragment) {
        return XXPermissions.with((Context)fragment.getActivity());
    }

    public static XXPermissions with(Context context) {
        return new XXPermissions(context);
    }

    public static XXPermissions with(androidx.fragment.app.Fragment fragment) {
        return XXPermissions.with((Context)fragment.getActivity());
    }

    public XXPermissions permission(List<String> list) {
        List<String> list2 = this.mPermissions;
        if (list2 == null) {
            this.mPermissions = list;
            return this;
        }
        list2.addAll(list);
        return this;
    }

    public /* varargs */ XXPermissions permission(String ... arrstring) {
        return this.permission((List<String>)PermissionUtils.asArrayList(arrstring));
    }

    public /* varargs */ XXPermissions permission(String[] ... arrstring) {
        return this.permission((List<String>)PermissionUtils.asArrayLists(arrstring));
    }

    public void request(OnPermissionCallback onPermissionCallback) {
        Context context = this.mContext;
        if (context == null) {
            return;
        }
        boolean bl = XXPermissions.isDebugMode(context);
        Activity activity = PermissionUtils.findActivity(this.mContext);
        if (!PermissionChecker.checkActivityStatus(activity, bl)) {
            return;
        }
        if (!PermissionChecker.checkPermissionArgument(this.mPermissions, bl)) {
            return;
        }
        if (bl) {
            PermissionChecker.checkStoragePermission(this.mContext, this.mPermissions, XXPermissions.isScopedStorage());
            PermissionChecker.checkLocationPermission(this.mPermissions);
            PermissionChecker.checkTargetSdkVersion(this.mContext, this.mPermissions);
        }
        PermissionChecker.optimizeDeprecatedPermission(this.mPermissions);
        if (bl) {
            PermissionChecker.checkPermissionManifest(this.mContext, this.mPermissions);
        }
        if (PermissionUtils.isGrantedPermissions(this.mContext, this.mPermissions)) {
            if (onPermissionCallback != null) {
                onPermissionCallback.onGranted(this.mPermissions, true);
            }
            return;
        }
        XXPermissions.getInterceptor().requestPermissions(activity, onPermissionCallback, this.mPermissions);
    }
}

