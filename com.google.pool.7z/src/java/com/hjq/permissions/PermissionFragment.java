/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Fragment
 *  android.app.FragmentManager
 *  android.app.FragmentTransaction
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.SparseBooleanArray
 *  android.view.View
 *  android.view.Window
 *  com.hjq.permissions.PermissionFragment$1
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.hjq.permissions;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.Window;
import com.hjq.permissions.OnPermissionCallback;
import com.hjq.permissions.PermissionFragment;
import com.hjq.permissions.PermissionSettingPage;
import com.hjq.permissions.PermissionUtils;
import com.hjq.permissions.XXPermissions;
import java.util.ArrayList;
import java.util.List;

public final class PermissionFragment
extends Fragment
implements Runnable {
    private static final String REQUEST_CODE = "request_code";
    private static final SparseBooleanArray REQUEST_CODE_ARRAY = new SparseBooleanArray();
    private static final String REQUEST_PERMISSIONS = "request_permissions";
    private static final String USE_INTERCEPTOR = "use_interceptor";
    private OnPermissionCallback mCallBack;
    private boolean mDangerousRequest;
    private int mScreenOrientation;
    private boolean mSpecialRequest;

    static /* synthetic */ void access$000(Activity activity, ArrayList arrayList, boolean bl, OnPermissionCallback onPermissionCallback) {
        PermissionFragment.beginRequest(activity, (ArrayList<String>)arrayList, bl, onPermissionCallback);
    }

    public static void beginRequest(Activity activity, ArrayList<String> arrayList, OnPermissionCallback onPermissionCallback) {
        PermissionFragment.beginRequest(activity, arrayList, true, onPermissionCallback);
    }

    private static void beginRequest(Activity activity, ArrayList<String> arrayList, boolean bl, OnPermissionCallback onPermissionCallback) {
        int n;
        SparseBooleanArray sparseBooleanArray;
        PermissionFragment permissionFragment = new PermissionFragment();
        Bundle bundle = new Bundle();
        while ((sparseBooleanArray = REQUEST_CODE_ARRAY).get(n = PermissionUtils.getRandomRequestCode())) {
        }
        sparseBooleanArray.put(n, true);
        bundle.putInt(REQUEST_CODE, n);
        bundle.putStringArrayList(REQUEST_PERMISSIONS, arrayList);
        bundle.putBoolean(USE_INTERCEPTOR, bl);
        permissionFragment.setArguments(bundle);
        permissionFragment.setRetainInstance(true);
        permissionFragment.setCallBack(onPermissionCallback);
        permissionFragment.attachActivity(activity);
    }

    public void attachActivity(Activity activity) {
        activity.getFragmentManager().beginTransaction().add((Fragment)this, this.toString()).commitAllowingStateLoss();
    }

    public void detachActivity(Activity activity) {
        activity.getFragmentManager().beginTransaction().remove((Fragment)this).commitAllowingStateLoss();
    }

    public void onActivityResult(int n, int n2, Intent intent) {
        Activity activity = this.getActivity();
        Bundle bundle = this.getArguments();
        if (activity != null && bundle != null && n == bundle.getInt(REQUEST_CODE)) {
            if (this.mDangerousRequest) {
                return;
            }
            this.mDangerousRequest = true;
            activity.getWindow().getDecorView().postDelayed((Runnable)this, 200L);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void onAttach(Context var1_1) {
        super.onAttach(var1_1);
        var2_2 = this.getActivity();
        if (var2_2 == null) {
            return;
        }
        this.mScreenOrientation = var3_3 = var2_2.getRequestedOrientation();
        if (var3_3 != -1) {
            return;
        }
        var4_4 = var2_2.getResources().getConfiguration().orientation;
        if (var4_4 != 2) ** GOTO lbl13
        try {
            var2_2.setRequestedOrientation(0);
            return;
lbl13: // 1 sources:
            if (var4_4 != 1) return;
            var2_2.setRequestedOrientation(1);
            return;
        }
        catch (IllegalStateException var5_5) {}
        var5_5.printStackTrace();
    }

    public void onDestroy() {
        super.onDestroy();
        this.mCallBack = null;
    }

    public void onDetach() {
        super.onDetach();
        Activity activity = this.getActivity();
        if (activity != null) {
            if (this.mScreenOrientation != -1) {
                return;
            }
            activity.setRequestedOrientation(-1);
        }
    }

    public void onRequestPermissionsResult(int n, String[] arrstring, int[] arrn) {
        Bundle bundle = this.getArguments();
        Activity activity = this.getActivity();
        if (activity != null && bundle != null && this.mCallBack != null) {
            if (n != bundle.getInt(REQUEST_CODE)) {
                return;
            }
            boolean bl = bundle.getBoolean(USE_INTERCEPTOR);
            OnPermissionCallback onPermissionCallback = this.mCallBack;
            this.mCallBack = null;
            for (int i = 0; i < arrstring.length; ++i) {
                String string2 = arrstring[i];
                if (PermissionUtils.isSpecialPermission(string2)) {
                    arrn[i] = PermissionUtils.getPermissionStatus((Context)activity, string2);
                    continue;
                }
                if (!PermissionUtils.isAndroid10() && ("android.permission.ACCESS_BACKGROUND_LOCATION".equals((Object)string2) || "android.permission.ACTIVITY_RECOGNITION".equals((Object)string2) || "android.permission.ACCESS_MEDIA_LOCATION".equals((Object)string2))) {
                    arrn[i] = PermissionUtils.getPermissionStatus((Context)activity, string2);
                    continue;
                }
                if (!PermissionUtils.isAndroid9() && "android.permission.ACCEPT_HANDOVER".equals((Object)string2)) {
                    arrn[i] = PermissionUtils.getPermissionStatus((Context)activity, string2);
                    continue;
                }
                if (PermissionUtils.isAndroid8() || !"android.permission.ANSWER_PHONE_CALLS".equals((Object)string2) && !"android.permission.READ_PHONE_NUMBERS".equals((Object)string2)) continue;
                arrn[i] = PermissionUtils.getPermissionStatus((Context)activity, string2);
            }
            REQUEST_CODE_ARRAY.delete(n);
            this.detachActivity(activity);
            List<String> list = PermissionUtils.getGrantedPermissions(arrstring, arrn);
            if (list.size() == arrstring.length) {
                if (bl) {
                    XXPermissions.getInterceptor().grantedPermissions(activity, onPermissionCallback, list, true);
                    return;
                }
                onPermissionCallback.onGranted(list, true);
                return;
            }
            List<String> list2 = PermissionUtils.getDeniedPermissions(arrstring, arrn);
            if (bl) {
                XXPermissions.getInterceptor().deniedPermissions(activity, onPermissionCallback, list2, PermissionUtils.isPermissionPermanentDenied(activity, list2));
            } else {
                onPermissionCallback.onDenied(list2, PermissionUtils.isPermissionPermanentDenied(activity, list2));
            }
            if (!list.isEmpty()) {
                if (bl) {
                    XXPermissions.getInterceptor().grantedPermissions(activity, onPermissionCallback, list, false);
                    return;
                }
                onPermissionCallback.onDenied(list, false);
            }
        }
    }

    public void onResume() {
        super.onResume();
        if (this.mSpecialRequest) {
            return;
        }
        this.mSpecialRequest = true;
        this.requestSpecialPermission();
    }

    public void requestDangerousPermission() {
        Activity activity = this.getActivity();
        Bundle bundle = this.getArguments();
        if (activity != null) {
            if (bundle == null) {
                return;
            }
            int n = bundle.getInt(REQUEST_CODE);
            ArrayList arrayList = bundle.getStringArrayList(REQUEST_PERMISSIONS);
            if (arrayList != null) {
                if (arrayList.size() == 0) {
                    return;
                }
                boolean bl = PermissionUtils.isAndroid10();
                ArrayList arrayList2 = null;
                if (bl) {
                    boolean bl2 = arrayList.contains((Object)"android.permission.ACCESS_BACKGROUND_LOCATION");
                    arrayList2 = null;
                    if (bl2) {
                        arrayList2 = new ArrayList();
                        if (arrayList.contains((Object)"android.permission.ACCESS_COARSE_LOCATION")) {
                            arrayList2.add((Object)"android.permission.ACCESS_COARSE_LOCATION");
                        }
                        if (arrayList.contains((Object)"android.permission.ACCESS_FINE_LOCATION")) {
                            arrayList2.add((Object)"android.permission.ACCESS_FINE_LOCATION");
                        }
                    }
                }
                if (arrayList2 != null && !arrayList2.isEmpty()) {
                    PermissionFragment.beginRequest(activity, (ArrayList<String>)arrayList2, false, (OnPermissionCallback)new 1(this, activity, arrayList, n));
                    return;
                }
                this.requestPermissions((String[])arrayList.toArray((Object[])new String[-1 + arrayList.size()]), this.getArguments().getInt(REQUEST_CODE));
            }
        }
    }

    public void requestSpecialPermission() {
        Bundle bundle = this.getArguments();
        Activity activity = this.getActivity();
        if (bundle != null) {
            if (activity == null) {
                return;
            }
            ArrayList arrayList = bundle.getStringArrayList(REQUEST_PERMISSIONS);
            boolean bl = PermissionUtils.containsSpecialPermission((List<String>)arrayList);
            boolean bl2 = false;
            if (bl) {
                boolean bl3 = arrayList.contains((Object)"android.permission.MANAGE_EXTERNAL_STORAGE");
                bl2 = false;
                if (bl3) {
                    boolean bl4 = PermissionUtils.isGrantedStoragePermission((Context)activity);
                    bl2 = false;
                    if (!bl4) {
                        boolean bl5 = PermissionUtils.isAndroid11();
                        bl2 = false;
                        if (bl5) {
                            this.startActivityForResult(PermissionSettingPage.getStoragePermissionIntent((Context)activity), this.getArguments().getInt(REQUEST_CODE));
                            bl2 = true;
                        }
                    }
                }
                if (arrayList.contains((Object)"android.permission.REQUEST_INSTALL_PACKAGES") && !PermissionUtils.isGrantedInstallPermission((Context)activity)) {
                    this.startActivityForResult(PermissionSettingPage.getInstallPermissionIntent((Context)activity), this.getArguments().getInt(REQUEST_CODE));
                    bl2 = true;
                }
                if (arrayList.contains((Object)"android.permission.SYSTEM_ALERT_WINDOW") && !PermissionUtils.isGrantedWindowPermission((Context)activity)) {
                    this.startActivityForResult(PermissionSettingPage.getWindowPermissionIntent((Context)activity), this.getArguments().getInt(REQUEST_CODE));
                    bl2 = true;
                }
                if (arrayList.contains((Object)"android.permission.NOTIFICATION_SERVICE") && !PermissionUtils.isGrantedNotifyPermission((Context)activity)) {
                    this.startActivityForResult(PermissionSettingPage.getNotifyPermissionIntent((Context)activity), this.getArguments().getInt(REQUEST_CODE));
                    bl2 = true;
                }
                if (arrayList.contains((Object)"android.permission.WRITE_SETTINGS") && !PermissionUtils.isGrantedSettingPermission((Context)activity)) {
                    this.startActivityForResult(PermissionSettingPage.getSettingPermissionIntent((Context)activity), this.getArguments().getInt(REQUEST_CODE));
                    bl2 = true;
                }
            }
            if (!bl2) {
                this.requestDangerousPermission();
            }
        }
    }

    public void run() {
        if (!this.isAdded()) {
            return;
        }
        this.requestDangerousPermission();
    }

    public void setCallBack(OnPermissionCallback onPermissionCallback) {
        this.mCallBack = onPermissionCallback;
    }
}

