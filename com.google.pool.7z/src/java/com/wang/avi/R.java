/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.wang.avi;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int indicatorColor = 2130903541;
        public static final int indicatorName = 2130903545;
        public static final int maxHeight = 2130903745;
        public static final int maxWidth = 2130903749;
        public static final int minHeight = 2130903754;
        public static final int minWidth = 2130903758;

        private attr() {
        }
    }

    public static final class string {
        public static final int app_name = 2131755037;

        private string() {
        }
    }

    public static final class style {
        public static final int AVLoadingIndicatorView = 2131820544;
        public static final int AVLoadingIndicatorView_Large = 2131820545;
        public static final int AVLoadingIndicatorView_Small = 2131820546;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] AVLoadingIndicatorView = new int[]{2130903541, 2130903545, 2130903745, 2130903749, 2130903754, 2130903758};
        public static final int AVLoadingIndicatorView_indicatorColor = 0;
        public static final int AVLoadingIndicatorView_indicatorName = 1;
        public static final int AVLoadingIndicatorView_maxHeight = 2;
        public static final int AVLoadingIndicatorView_maxWidth = 3;
        public static final int AVLoadingIndicatorView_minHeight = 4;
        public static final int AVLoadingIndicatorView_minWidth = 5;

        private styleable() {
        }
    }

}

