/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallRotateIndicator;
import java.util.ArrayList;

public class BallRotateIndicator
extends Indicator {
    float degress;
    private Matrix mMatrix = new Matrix();
    float scaleFloat = 0.5f;

    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = this.getWidth() / 10;
        float f2 = this.getWidth() / 2;
        float f3 = this.getHeight() / 2;
        canvas.rotate(this.degress, (float)this.centerX(), (float)this.centerY());
        canvas.save();
        float f4 = 2.0f * f;
        canvas.translate(f2 - f4 - f, f3);
        float f5 = this.scaleFloat;
        canvas.scale(f5, f5);
        canvas.drawCircle(0.0f, 0.0f, f, paint);
        canvas.restore();
        canvas.save();
        canvas.translate(f2, f3);
        float f6 = this.scaleFloat;
        canvas.scale(f6, f6);
        canvas.drawCircle(0.0f, 0.0f, f, paint);
        canvas.restore();
        canvas.save();
        canvas.translate(f + (f2 + f4), f3);
        float f7 = this.scaleFloat;
        canvas.scale(f7, f7);
        canvas.drawCircle(0.0f, 0.0f, f, paint);
        canvas.restore();
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{0.5f, 1.0f, 0.5f});
        valueAnimator.setDuration(1000L);
        valueAnimator.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ BallRotateIndicator this$0;
            {
                this.this$0 = ballRotateIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.this$0.scaleFloat = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.postInvalidate();
            }
        });
        ValueAnimator valueAnimator2 = ValueAnimator.ofFloat((float[])new float[]{0.0f, 180.0f, 360.0f});
        this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ BallRotateIndicator this$0;
            {
                this.this$0 = ballRotateIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.this$0.degress = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.postInvalidate();
            }
        });
        valueAnimator2.setDuration(1000L);
        valueAnimator2.setRepeatCount(-1);
        arrayList.add((Object)valueAnimator);
        arrayList.add((Object)valueAnimator2);
        return arrayList;
    }
}

