/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.LineScalePartyIndicator;
import java.util.ArrayList;

public class LineScalePartyIndicator
extends Indicator {
    public static final float SCALE = 1.0f;
    float[] scaleFloats = new float[]{1.0f, 1.0f, 1.0f, 1.0f, 1.0f};

    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = this.getWidth() / 9;
        float f2 = this.getHeight() / 2;
        for (int i = 0; i < 4; ++i) {
            canvas.save();
            float f3 = f * (float)(2 + i * 2);
            float f4 = f / 2.0f;
            canvas.translate(f3 - f4, f2);
            float[] arrf = this.scaleFloats;
            canvas.scale(arrf[i], arrf[i]);
            canvas.drawRoundRect(new RectF(-f / 2.0f, (float)(-this.getHeight()) / 2.5f, f4, (float)this.getHeight() / 2.5f), 5.0f, 5.0f, paint);
            canvas.restore();
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        long[] arrl = new long[]{1260L, 430L, 1010L, 730L};
        long[] arrl2 = new long[]{770L, 290L, 280L, 740L};
        for (int i = 0; i < 4; ++i) {
            ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.4f, 1.0f});
            valueAnimator.setDuration(arrl[i]);
            valueAnimator.setRepeatCount(-1);
            valueAnimator.setStartDelay(arrl2[i]);
            this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ LineScalePartyIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = lineScalePartyIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.scaleFloats[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            arrayList.add((Object)valueAnimator);
        }
        return arrayList;
    }
}

