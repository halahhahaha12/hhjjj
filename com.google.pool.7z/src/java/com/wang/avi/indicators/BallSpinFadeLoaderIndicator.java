/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  java.lang.Double
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallSpinFadeLoaderIndicator;
import java.util.ArrayList;

public class BallSpinFadeLoaderIndicator
extends Indicator {
    public static final int ALPHA = 255;
    public static final float SCALE = 1.0f;
    int[] alphas = new int[]{255, 255, 255, 255, 255, 255, 255, 255};
    float[] scaleFloats = new float[]{1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f};

    Point circleAt(int n, int n2, float f, double d) {
        double d2 = n / 2;
        double d3 = f;
        double d4 = Math.cos((double)d);
        Double.isNaN((double)d3);
        double d5 = d4 * d3;
        Double.isNaN((double)d2);
        float f2 = (float)(d2 + d5);
        double d6 = n2 / 2;
        double d7 = Math.sin((double)d);
        Double.isNaN((double)d3);
        double d8 = d3 * d7;
        Double.isNaN((double)d6);
        return new Object(f2, (float)(d6 + d8)){
            public float x;
            public float y;
            {
                this.x = f;
                this.y = f2;
            }
        };
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = this.getWidth() / 10;
        for (int i = 0; i < 8; ++i) {
            canvas.save();
            int n = this.getWidth();
            int n2 = this.getHeight();
            float f2 = (float)(this.getWidth() / 2) - f;
            double d = i;
            Double.isNaN((double)d);
            Point point = this.circleAt(n, n2, f2, 0.7853981633974483 * d);
            canvas.translate(point.x, point.y);
            float[] arrf = this.scaleFloats;
            canvas.scale(arrf[i], arrf[i]);
            paint.setAlpha(this.alphas[i]);
            canvas.drawCircle(0.0f, 0.0f, f, paint);
            canvas.restore();
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        int[] arrn = new int[]{0, 120, 240, 360, 480, 600, 720, 780, 840};
        for (int i = 0; i < 8; ++i) {
            ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.4f, 1.0f});
            valueAnimator.setDuration(1000L);
            valueAnimator.setRepeatCount(-1);
            valueAnimator.setStartDelay((long)arrn[i]);
            this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallSpinFadeLoaderIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballSpinFadeLoaderIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.scaleFloats[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            ValueAnimator valueAnimator2 = ValueAnimator.ofInt((int[])new int[]{255, 77, 255});
            valueAnimator2.setDuration(1000L);
            valueAnimator2.setRepeatCount(-1);
            valueAnimator2.setStartDelay((long)arrn[i]);
            this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallSpinFadeLoaderIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballSpinFadeLoaderIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.alphas[this.val$index] = (java.lang.Integer)valueAnimator.getAnimatedValue();
                    this.this$0.postInvalidate();
                }
            });
            arrayList.add((Object)valueAnimator);
            arrayList.add((Object)valueAnimator2);
        }
        return arrayList;
    }

}

