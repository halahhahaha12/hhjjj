/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallPulseIndicator;
import java.util.ArrayList;

public class BallPulseIndicator
extends Indicator {
    public static final float SCALE = 1.0f;
    private float[] scaleFloats = new float[]{1.0f, 1.0f, 1.0f};

    static /* synthetic */ float[] access$000(BallPulseIndicator ballPulseIndicator) {
        return ballPulseIndicator.scaleFloats;
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = ((float)Math.min((int)this.getWidth(), (int)this.getHeight()) - 8.0f) / 6.0f;
        float f2 = this.getWidth() / 2;
        float f3 = 2.0f * f;
        float f4 = f2 - (f3 + 4.0f);
        float f5 = this.getHeight() / 2;
        for (int i = 0; i < 3; ++i) {
            canvas.save();
            float f6 = i;
            canvas.translate(f4 + f3 * f6 + f6 * 4.0f, f5);
            float[] arrf = this.scaleFloats;
            canvas.scale(arrf[i], arrf[i]);
            canvas.drawCircle(0.0f, 0.0f, f, paint);
            canvas.restore();
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        int[] arrn = new int[]{120, 240, 360};
        for (int i = 0; i < 3; ++i) {
            ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.3f, 1.0f});
            valueAnimator.setDuration(750L);
            valueAnimator.setRepeatCount(-1);
            valueAnimator.setStartDelay((long)arrn[i]);
            this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallPulseIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballPulseIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    BallPulseIndicator.access$000((BallPulseIndicator)this.this$0)[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            arrayList.add((Object)valueAnimator);
        }
        return arrayList;
    }
}

