/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.TimeInterpolator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  android.view.animation.LinearInterpolator
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.animation.LinearInterpolator;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.CubeTransitionIndicator;
import java.util.ArrayList;

public class CubeTransitionIndicator
extends Indicator {
    float degrees;
    float scaleFloat = 1.0f;
    float[] translateX = new float[2];
    float[] translateY = new float[2];

    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = this.getWidth() / 5;
        float f2 = this.getHeight() / 5;
        for (int i = 0; i < 2; ++i) {
            canvas.save();
            canvas.translate(this.translateX[i], this.translateY[i]);
            canvas.rotate(this.degrees);
            float f3 = this.scaleFloat;
            canvas.scale(f3, f3);
            canvas.drawRect(new RectF(-f / 2.0f, -f2 / 2.0f, f / 2.0f, f2 / 2.0f), paint);
            canvas.restore();
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        float f = this.getWidth() / 5;
        float f2 = this.getHeight() / 5;
        for (int i = 0; i < 2; ++i) {
            this.translateX[i] = f;
            float[] arrf = new float[]{f, (float)this.getWidth() - f, (float)this.getWidth() - f, f, f};
            ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])arrf);
            if (i == 1) {
                float[] arrf2 = new float[]{(float)this.getWidth() - f, f, f, (float)this.getWidth() - f, (float)this.getWidth() - f};
                valueAnimator = ValueAnimator.ofFloat((float[])arrf2);
            }
            valueAnimator.setInterpolator((TimeInterpolator)new LinearInterpolator());
            valueAnimator.setDuration(1600L);
            valueAnimator.setRepeatCount(-1);
            valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ CubeTransitionIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = cubeTransitionIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.translateX[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            this.translateY[i] = f2;
            float[] arrf3 = new float[]{f2, f2, (float)this.getHeight() - f2, (float)this.getHeight() - f2, f2};
            ValueAnimator valueAnimator2 = ValueAnimator.ofFloat((float[])arrf3);
            if (i == 1) {
                float[] arrf4 = new float[]{(float)this.getHeight() - f2, (float)this.getHeight() - f2, f2, f2, (float)this.getHeight() - f2};
                valueAnimator2 = ValueAnimator.ofFloat((float[])arrf4);
            }
            valueAnimator2.setDuration(1600L);
            valueAnimator2.setInterpolator((TimeInterpolator)new LinearInterpolator());
            valueAnimator2.setRepeatCount(-1);
            this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ CubeTransitionIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = cubeTransitionIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.translateY[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            arrayList.add((Object)valueAnimator);
            arrayList.add((Object)valueAnimator2);
        }
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.5f, 1.0f, 0.5f, 1.0f});
        valueAnimator.setDuration(1600L);
        valueAnimator.setInterpolator((TimeInterpolator)new LinearInterpolator());
        valueAnimator.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ CubeTransitionIndicator this$0;
            {
                this.this$0 = cubeTransitionIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.this$0.scaleFloat = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.postInvalidate();
            }
        });
        ValueAnimator valueAnimator3 = ValueAnimator.ofFloat((float[])new float[]{0.0f, 180.0f, 360.0f, 540.0f, 720.0f});
        valueAnimator3.setDuration(1600L);
        valueAnimator3.setInterpolator((TimeInterpolator)new LinearInterpolator());
        valueAnimator3.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator3, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ CubeTransitionIndicator this$0;
            {
                this.this$0 = cubeTransitionIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.this$0.degrees = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.postInvalidate();
            }
        });
        arrayList.add((Object)valueAnimator);
        arrayList.add((Object)valueAnimator3);
        return arrayList;
    }
}

