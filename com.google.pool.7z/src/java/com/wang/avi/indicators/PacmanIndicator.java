/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.TimeInterpolator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  android.view.animation.LinearInterpolator
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.animation.LinearInterpolator;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.PacmanIndicator;
import java.util.ArrayList;

public class PacmanIndicator
extends Indicator {
    private int alpha;
    private float degrees1;
    private float degrees2;
    private float translateX;

    static /* synthetic */ float access$002(PacmanIndicator pacmanIndicator, float f) {
        pacmanIndicator.translateX = f;
        return f;
    }

    static /* synthetic */ int access$102(PacmanIndicator pacmanIndicator, int n) {
        pacmanIndicator.alpha = n;
        return n;
    }

    static /* synthetic */ float access$202(PacmanIndicator pacmanIndicator, float f) {
        pacmanIndicator.degrees1 = f;
        return f;
    }

    static /* synthetic */ float access$302(PacmanIndicator pacmanIndicator, float f) {
        pacmanIndicator.degrees2 = f;
        return f;
    }

    private void drawCircle(Canvas canvas, Paint paint) {
        float f = this.getWidth() / 11;
        paint.setAlpha(this.alpha);
        canvas.drawCircle(this.translateX, (float)(this.getHeight() / 2), f, paint);
    }

    private void drawPacman(Canvas canvas, Paint paint) {
        float f = this.getWidth() / 2;
        float f2 = this.getHeight() / 2;
        canvas.save();
        canvas.translate(f, f2);
        canvas.rotate(this.degrees1);
        paint.setAlpha(255);
        float f3 = -f / 1.7f;
        float f4 = -f2 / 1.7f;
        float f5 = f / 1.7f;
        float f6 = f2 / 1.7f;
        canvas.drawArc(new RectF(f3, f4, f5, f6), 0.0f, 270.0f, true, paint);
        canvas.restore();
        canvas.save();
        canvas.translate(f, f2);
        canvas.rotate(this.degrees2);
        paint.setAlpha(255);
        canvas.drawArc(new RectF(f3, f4, f5, f6), 90.0f, 270.0f, true, paint);
        canvas.restore();
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        this.drawPacman(canvas, paint);
        this.drawCircle(canvas, paint);
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        float f = this.getWidth() / 11;
        float[] arrf = new float[]{(float)this.getWidth() - f, this.getWidth() / 2};
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])arrf);
        valueAnimator.setDuration(650L);
        valueAnimator.setInterpolator((TimeInterpolator)new LinearInterpolator());
        valueAnimator.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ PacmanIndicator this$0;
            {
                this.this$0 = pacmanIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                PacmanIndicator.access$002(this.this$0, ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue());
                this.this$0.postInvalidate();
            }
        });
        ValueAnimator valueAnimator2 = ValueAnimator.ofInt((int[])new int[]{255, 122});
        valueAnimator2.setDuration(650L);
        valueAnimator2.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ PacmanIndicator this$0;
            {
                this.this$0 = pacmanIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                PacmanIndicator.access$102(this.this$0, (java.lang.Integer)valueAnimator.getAnimatedValue());
                this.this$0.postInvalidate();
            }
        });
        ValueAnimator valueAnimator3 = ValueAnimator.ofFloat((float[])new float[]{0.0f, 45.0f, 0.0f});
        valueAnimator3.setDuration(650L);
        valueAnimator3.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator3, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ PacmanIndicator this$0;
            {
                this.this$0 = pacmanIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                PacmanIndicator.access$202(this.this$0, ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue());
                this.this$0.postInvalidate();
            }
        });
        ValueAnimator valueAnimator4 = ValueAnimator.ofFloat((float[])new float[]{0.0f, -45.0f, 0.0f});
        valueAnimator4.setDuration(650L);
        valueAnimator4.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator4, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ PacmanIndicator this$0;
            {
                this.this$0 = pacmanIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                PacmanIndicator.access$302(this.this$0, ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue());
                this.this$0.postInvalidate();
            }
        });
        arrayList.add((Object)valueAnimator);
        arrayList.add((Object)valueAnimator2);
        arrayList.add((Object)valueAnimator3);
        arrayList.add((Object)valueAnimator4);
        return arrayList;
    }
}

