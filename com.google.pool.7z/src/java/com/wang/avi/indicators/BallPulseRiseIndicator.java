/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.TimeInterpolator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Camera
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.view.animation.LinearInterpolator
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.graphics.Camera;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.animation.LinearInterpolator;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallPulseRiseIndicator;
import java.util.ArrayList;

public class BallPulseRiseIndicator
extends Indicator {
    private float degress;
    private Camera mCamera = new Camera();
    private Matrix mMatrix = new Matrix();

    static /* synthetic */ float access$002(BallPulseRiseIndicator ballPulseRiseIndicator, float f) {
        ballPulseRiseIndicator.degress = f;
        return f;
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        this.mMatrix.reset();
        this.mCamera.save();
        this.mCamera.rotateX(this.degress);
        this.mCamera.getMatrix(this.mMatrix);
        this.mCamera.restore();
        this.mMatrix.preTranslate((float)(-this.centerX()), (float)(-this.centerY()));
        this.mMatrix.postTranslate((float)this.centerX(), (float)this.centerY());
        canvas.concat(this.mMatrix);
        float f = this.getWidth() / 10;
        float f2 = this.getWidth() / 4;
        float f3 = 2.0f * f;
        canvas.drawCircle(f2, f3, f, paint);
        canvas.drawCircle((float)(3 * this.getWidth() / 4), f3, f, paint);
        canvas.drawCircle(f, (float)this.getHeight() - f3, f, paint);
        canvas.drawCircle((float)(this.getWidth() / 2), (float)this.getHeight() - f3, f, paint);
        canvas.drawCircle((float)this.getWidth() - f, (float)this.getHeight() - f3, f, paint);
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{0.0f, 360.0f});
        this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ BallPulseRiseIndicator this$0;
            {
                this.this$0 = ballPulseRiseIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                BallPulseRiseIndicator.access$002(this.this$0, ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue());
                this.this$0.postInvalidate();
            }
        });
        valueAnimator.setInterpolator((TimeInterpolator)new LinearInterpolator());
        valueAnimator.setRepeatCount(-1);
        valueAnimator.setDuration(1500L);
        arrayList.add((Object)valueAnimator);
        return arrayList;
    }
}

