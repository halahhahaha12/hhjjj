/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.TimeInterpolator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Camera
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  android.view.animation.LinearInterpolator
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.graphics.Camera;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.animation.LinearInterpolator;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.SquareSpinIndicator;
import java.util.ArrayList;

public class SquareSpinIndicator
extends Indicator {
    private Camera mCamera = new Camera();
    private Matrix mMatrix = new Matrix();
    private float rotateX;
    private float rotateY;

    static /* synthetic */ float access$002(SquareSpinIndicator squareSpinIndicator, float f) {
        squareSpinIndicator.rotateX = f;
        return f;
    }

    static /* synthetic */ float access$102(SquareSpinIndicator squareSpinIndicator, float f) {
        squareSpinIndicator.rotateY = f;
        return f;
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        this.mMatrix.reset();
        this.mCamera.save();
        this.mCamera.rotateX(this.rotateX);
        this.mCamera.rotateY(this.rotateY);
        this.mCamera.getMatrix(this.mMatrix);
        this.mCamera.restore();
        this.mMatrix.preTranslate((float)(-this.centerX()), (float)(-this.centerY()));
        this.mMatrix.postTranslate((float)this.centerX(), (float)this.centerY());
        canvas.concat(this.mMatrix);
        canvas.drawRect(new RectF((float)(this.getWidth() / 5), (float)(this.getHeight() / 5), (float)(4 * this.getWidth() / 5), (float)(4 * this.getHeight() / 5)), paint);
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{0.0f, 180.0f, 180.0f, 0.0f, 0.0f});
        this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ SquareSpinIndicator this$0;
            {
                this.this$0 = squareSpinIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                SquareSpinIndicator.access$002(this.this$0, ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue());
                this.this$0.postInvalidate();
            }
        });
        valueAnimator.setInterpolator((TimeInterpolator)new LinearInterpolator());
        valueAnimator.setRepeatCount(-1);
        valueAnimator.setDuration(2500L);
        ValueAnimator valueAnimator2 = ValueAnimator.ofFloat((float[])new float[]{0.0f, 0.0f, 180.0f, 180.0f, 0.0f});
        this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ SquareSpinIndicator this$0;
            {
                this.this$0 = squareSpinIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                SquareSpinIndicator.access$102(this.this$0, ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue());
                this.this$0.postInvalidate();
            }
        });
        valueAnimator2.setInterpolator((TimeInterpolator)new LinearInterpolator());
        valueAnimator2.setRepeatCount(-1);
        valueAnimator2.setDuration(2500L);
        arrayList.add((Object)valueAnimator);
        arrayList.add((Object)valueAnimator2);
        return arrayList;
    }
}

