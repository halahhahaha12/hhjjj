/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.RectF
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallClipRotateIndicator;
import java.util.ArrayList;

public class BallClipRotateIndicator
extends Indicator {
    float degrees;
    float scaleFloat = 1.0f;

    @Override
    public void draw(Canvas canvas, Paint paint) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3.0f);
        float f = this.getWidth() / 2;
        float f2 = this.getHeight() / 2;
        canvas.translate(f, f2);
        float f3 = this.scaleFloat;
        canvas.scale(f3, f3);
        canvas.rotate(this.degrees);
        canvas.drawArc(new RectF(12.0f + -f, 12.0f + -f2, f + 0.0f - 12.0f, f2 + 0.0f - 12.0f), -45.0f, 270.0f, false, paint);
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.6f, 0.5f, 1.0f});
        valueAnimator.setDuration(750L);
        valueAnimator.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ BallClipRotateIndicator this$0;
            {
                this.this$0 = ballClipRotateIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.this$0.scaleFloat = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.postInvalidate();
            }
        });
        ValueAnimator valueAnimator2 = ValueAnimator.ofFloat((float[])new float[]{0.0f, 180.0f, 360.0f});
        valueAnimator2.setDuration(750L);
        valueAnimator2.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ BallClipRotateIndicator this$0;
            {
                this.this$0 = ballClipRotateIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.this$0.degrees = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.postInvalidate();
            }
        });
        arrayList.add((Object)valueAnimator);
        arrayList.add((Object)valueAnimator2);
        return arrayList;
    }
}

