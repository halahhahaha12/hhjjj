/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.SemiCircleSpinIndicator;
import java.util.ArrayList;

public class SemiCircleSpinIndicator
extends Indicator {
    private float degress;

    static /* synthetic */ float access$002(SemiCircleSpinIndicator semiCircleSpinIndicator, float f) {
        semiCircleSpinIndicator.degress = f;
        return f;
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        canvas.rotate(this.degress, (float)this.centerX(), (float)this.centerY());
        canvas.drawArc(new RectF(0.0f, 0.0f, (float)this.getWidth(), (float)this.getHeight()), -60.0f, 120.0f, false, paint);
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{0.0f, 180.0f, 360.0f});
        this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ SemiCircleSpinIndicator this$0;
            {
                this.this$0 = semiCircleSpinIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                SemiCircleSpinIndicator.access$002(this.this$0, ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue());
                this.this$0.postInvalidate();
            }
        });
        valueAnimator.setDuration(600L);
        valueAnimator.setRepeatCount(-1);
        arrayList.add((Object)valueAnimator);
        return arrayList;
    }
}

