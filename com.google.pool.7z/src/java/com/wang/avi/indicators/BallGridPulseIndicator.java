/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallGridPulseIndicator;
import java.util.ArrayList;

public class BallGridPulseIndicator
extends Indicator {
    public static final int ALPHA = 255;
    public static final float SCALE = 1.0f;
    int[] alphas = new int[]{255, 255, 255, 255, 255, 255, 255, 255, 255};
    float[] scaleFloats = new float[]{1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f};

    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = ((float)this.getWidth() - 16.0f) / 6.0f;
        float f2 = this.getWidth() / 2;
        float f3 = 2.0f * f;
        float f4 = f3 + 4.0f;
        float f5 = f2 - f4;
        float f6 = (float)(this.getWidth() / 2) - f4;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                canvas.save();
                float f7 = j;
                float f8 = f5 + f3 * f7 + f7 * 4.0f;
                float f9 = i;
                canvas.translate(f8, f6 + f3 * f9 + f9 * 4.0f);
                float[] arrf = this.scaleFloats;
                int n = j + i * 3;
                canvas.scale(arrf[n], arrf[n]);
                paint.setAlpha(this.alphas[n]);
                canvas.drawCircle(0.0f, 0.0f, f, paint);
                canvas.restore();
            }
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        int[] arrn = new int[]{720, 1020, 1280, 1420, 1450, 1180, 870, 1450, 1060};
        int[] arrn2 = new int[]{-60, 250, -170, 480, 310, 30, 460, 780, 450};
        for (int i = 0; i < 9; ++i) {
            ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.5f, 1.0f});
            valueAnimator.setDuration((long)arrn[i]);
            valueAnimator.setRepeatCount(-1);
            valueAnimator.setStartDelay((long)arrn2[i]);
            this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallGridPulseIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballGridPulseIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.scaleFloats[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            ValueAnimator valueAnimator2 = ValueAnimator.ofInt((int[])new int[]{255, 210, 122, 255});
            valueAnimator2.setDuration((long)arrn[i]);
            valueAnimator2.setRepeatCount(-1);
            valueAnimator2.setStartDelay((long)arrn2[i]);
            this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallGridPulseIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballGridPulseIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.alphas[this.val$index] = (java.lang.Integer)valueAnimator.getAnimatedValue();
                    this.this$0.postInvalidate();
                }
            });
            arrayList.add((Object)valueAnimator);
            arrayList.add((Object)valueAnimator2);
        }
        return arrayList;
    }
}

