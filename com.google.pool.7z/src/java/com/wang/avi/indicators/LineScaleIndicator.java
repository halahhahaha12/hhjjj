/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.LineScaleIndicator;
import java.util.ArrayList;

public class LineScaleIndicator
extends Indicator {
    public static final float SCALE = 1.0f;
    float[] scaleYFloats = new float[]{1.0f, 1.0f, 1.0f, 1.0f, 1.0f};

    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = this.getWidth() / 11;
        float f2 = this.getHeight() / 2;
        for (int i = 0; i < 5; ++i) {
            canvas.save();
            float f3 = f * (float)(2 + i * 2);
            float f4 = f / 2.0f;
            canvas.translate(f3 - f4, f2);
            canvas.scale(1.0f, this.scaleYFloats[i]);
            canvas.drawRoundRect(new RectF(-f / 2.0f, (float)(-this.getHeight()) / 2.5f, f4, (float)this.getHeight() / 2.5f), 5.0f, 5.0f, paint);
            canvas.restore();
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        long[] arrl = new long[]{100L, 200L, 300L, 400L, 500L};
        for (int i = 0; i < 5; ++i) {
            ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.4f, 1.0f});
            valueAnimator.setDuration(1000L);
            valueAnimator.setRepeatCount(-1);
            valueAnimator.setStartDelay(arrl[i]);
            this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ LineScaleIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = lineScaleIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.scaleYFloats[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            arrayList.add((Object)valueAnimator);
        }
        return arrayList;
    }
}

