/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  java.lang.Double
 */
package com.wang.avi.indicators;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import com.wang.avi.indicators.BallSpinFadeLoaderIndicator;

public class LineSpinFadeLoaderIndicator
extends BallSpinFadeLoaderIndicator {
    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = this.getWidth() / 10;
        for (int i = 0; i < 8; ++i) {
            canvas.save();
            int n = this.getWidth();
            int n2 = this.getHeight();
            float f2 = (float)this.getWidth() / 2.5f - f;
            double d = i;
            Double.isNaN((double)d);
            BallSpinFadeLoaderIndicator.Point point = this.circleAt(n, n2, f2, 0.7853981633974483 * d);
            canvas.translate(point.x, point.y);
            canvas.scale(this.scaleFloats[i], this.scaleFloats[i]);
            canvas.rotate((float)(i * 45));
            paint.setAlpha(this.alphas[i]);
            float f3 = -f;
            canvas.drawRoundRect(new RectF(f3, f3 / 1.5f, f * 1.5f, f / 1.5f), 5.0f, 5.0f, paint);
            canvas.restore();
        }
    }
}

