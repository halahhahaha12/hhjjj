/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallPulseSyncIndicator;
import java.util.ArrayList;

public class BallPulseSyncIndicator
extends Indicator {
    float[] translateYFloats = new float[3];

    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = ((float)this.getWidth() - 8.0f) / 6.0f;
        float f2 = this.getWidth() / 2;
        float f3 = 2.0f * f;
        float f4 = f2 - (f3 + 4.0f);
        for (int i = 0; i < 3; ++i) {
            canvas.save();
            float f5 = i;
            canvas.translate(f4 + f3 * f5 + f5 * 4.0f, this.translateYFloats[i]);
            canvas.drawCircle(0.0f, 0.0f, f, paint);
            canvas.restore();
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        float f = ((float)this.getWidth() - 8.0f) / 6.0f;
        int[] arrn = new int[]{70, 140, 210};
        for (int i = 0; i < 3; ++i) {
            float[] arrf = new float[]{this.getHeight() / 2, (float)(this.getHeight() / 2) - 2.0f * f, this.getHeight() / 2};
            ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])arrf);
            valueAnimator.setDuration(600L);
            valueAnimator.setRepeatCount(-1);
            valueAnimator.setStartDelay((long)arrn[i]);
            this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallPulseSyncIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballPulseSyncIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.translateYFloats[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            arrayList.add((Object)valueAnimator);
        }
        return arrayList;
    }
}

