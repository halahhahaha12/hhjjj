/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallBeatIndicator;
import java.util.ArrayList;

public class BallBeatIndicator
extends Indicator {
    public static final int ALPHA = 255;
    public static final float SCALE = 1.0f;
    int[] alphas = new int[]{255, 255, 255};
    private float[] scaleFloats = new float[]{1.0f, 1.0f, 1.0f};

    static /* synthetic */ float[] access$000(BallBeatIndicator ballBeatIndicator) {
        return ballBeatIndicator.scaleFloats;
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = ((float)this.getWidth() - 8.0f) / 6.0f;
        float f2 = this.getWidth() / 2;
        float f3 = 2.0f * f;
        float f4 = f2 - (f3 + 4.0f);
        float f5 = this.getHeight() / 2;
        for (int i = 0; i < 3; ++i) {
            canvas.save();
            float f6 = i;
            canvas.translate(f4 + f3 * f6 + f6 * 4.0f, f5);
            float[] arrf = this.scaleFloats;
            canvas.scale(arrf[i], arrf[i]);
            paint.setAlpha(this.alphas[i]);
            canvas.drawCircle(0.0f, 0.0f, f, paint);
            canvas.restore();
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        int[] arrn = new int[]{350, 0, 350};
        for (int i = 0; i < 3; ++i) {
            ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.75f, 1.0f});
            valueAnimator.setDuration(700L);
            valueAnimator.setRepeatCount(-1);
            valueAnimator.setStartDelay((long)arrn[i]);
            this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallBeatIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballBeatIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    BallBeatIndicator.access$000((BallBeatIndicator)this.this$0)[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            ValueAnimator valueAnimator2 = ValueAnimator.ofInt((int[])new int[]{255, 51, 255});
            valueAnimator2.setDuration(700L);
            valueAnimator2.setRepeatCount(-1);
            valueAnimator2.setStartDelay((long)arrn[i]);
            this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallBeatIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballBeatIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.alphas[this.val$index] = (java.lang.Integer)valueAnimator.getAnimatedValue();
                    this.this$0.postInvalidate();
                }
            });
            arrayList.add((Object)valueAnimator);
            arrayList.add((Object)valueAnimator2);
        }
        return arrayList;
    }
}

