/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.TimeInterpolator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.view.animation.LinearInterpolator
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.animation.LinearInterpolator;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallScaleMultipleIndicator;
import java.util.ArrayList;

public class BallScaleMultipleIndicator
extends Indicator {
    int[] alphaInts = new int[]{255, 255, 255};
    float[] scaleFloats = new float[]{1.0f, 1.0f, 1.0f};

    @Override
    public void draw(Canvas canvas, Paint paint) {
        for (int i = 0; i < 3; ++i) {
            paint.setAlpha(this.alphaInts[i]);
            float[] arrf = this.scaleFloats;
            canvas.scale(arrf[i], arrf[i], (float)(this.getWidth() / 2), (float)(this.getHeight() / 2));
            canvas.drawCircle((float)(this.getWidth() / 2), (float)(this.getHeight() / 2), (float)(this.getWidth() / 2) - 4.0f, paint);
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        long[] arrl = new long[]{0L, 200L, 400L};
        for (int i = 0; i < 3; ++i) {
            ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{0.0f, 1.0f});
            valueAnimator.setInterpolator((TimeInterpolator)new LinearInterpolator());
            valueAnimator.setDuration(1000L);
            valueAnimator.setRepeatCount(-1);
            this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallScaleMultipleIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballScaleMultipleIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.scaleFloats[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            valueAnimator.setStartDelay(arrl[i]);
            ValueAnimator valueAnimator2 = ValueAnimator.ofInt((int[])new int[]{255, 0});
            valueAnimator2.setInterpolator((TimeInterpolator)new LinearInterpolator());
            valueAnimator2.setDuration(1000L);
            valueAnimator2.setRepeatCount(-1);
            this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallScaleMultipleIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballScaleMultipleIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.alphaInts[this.val$index] = (java.lang.Integer)valueAnimator.getAnimatedValue();
                    this.this$0.postInvalidate();
                }
            });
            valueAnimator.setStartDelay(arrl[i]);
            arrayList.add((Object)valueAnimator);
            arrayList.add((Object)valueAnimator2);
        }
        return arrayList;
    }
}

