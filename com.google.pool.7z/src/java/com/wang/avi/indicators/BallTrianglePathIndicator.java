/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.TimeInterpolator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.view.animation.LinearInterpolator
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.animation.LinearInterpolator;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallTrianglePathIndicator;
import java.util.ArrayList;

public class BallTrianglePathIndicator
extends Indicator {
    float[] translateX = new float[3];
    float[] translateY = new float[3];

    @Override
    public void draw(Canvas canvas, Paint paint) {
        paint.setStrokeWidth(3.0f);
        paint.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < 3; ++i) {
            canvas.save();
            canvas.translate(this.translateX[i], this.translateY[i]);
            canvas.drawCircle(0.0f, 0.0f, (float)(this.getWidth() / 10), paint);
            canvas.restore();
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        float f = this.getWidth() / 5;
        float f2 = this.getWidth() / 5;
        for (int i = 0; i < 3; ++i) {
            float[] arrf = new float[]{this.getWidth() / 2, (float)this.getWidth() - f, f, this.getWidth() / 2};
            ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])arrf);
            if (i == 1) {
                float[] arrf2 = new float[]{(float)this.getWidth() - f, f, this.getWidth() / 2, (float)this.getWidth() - f};
                valueAnimator = ValueAnimator.ofFloat((float[])arrf2);
            } else if (i == 2) {
                float[] arrf3 = new float[]{f, this.getWidth() / 2, (float)this.getWidth() - f, f};
                valueAnimator = ValueAnimator.ofFloat((float[])arrf3);
            }
            float[] arrf4 = new float[]{f2, (float)this.getHeight() - f2, (float)this.getHeight() - f2, f2};
            ValueAnimator valueAnimator2 = ValueAnimator.ofFloat((float[])arrf4);
            if (i == 1) {
                float[] arrf5 = new float[]{(float)this.getHeight() - f2, (float)this.getHeight() - f2, f2, (float)this.getHeight() - f2};
                valueAnimator2 = ValueAnimator.ofFloat((float[])arrf5);
            } else if (i == 2) {
                float[] arrf6 = new float[]{(float)this.getHeight() - f2, f2, (float)this.getHeight() - f2, (float)this.getHeight() - f2};
                valueAnimator2 = ValueAnimator.ofFloat((float[])arrf6);
            }
            valueAnimator.setDuration(2000L);
            valueAnimator.setInterpolator((TimeInterpolator)new LinearInterpolator());
            valueAnimator.setRepeatCount(-1);
            this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallTrianglePathIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballTrianglePathIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.translateX[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            valueAnimator2.setDuration(2000L);
            valueAnimator2.setInterpolator((TimeInterpolator)new LinearInterpolator());
            valueAnimator2.setRepeatCount(-1);
            this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallTrianglePathIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballTrianglePathIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.translateY[this.val$index] = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                    this.this$0.postInvalidate();
                }
            });
            arrayList.add((Object)valueAnimator);
            arrayList.add((Object)valueAnimator2);
        }
        return arrayList;
    }
}

