/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallGridBeatIndicator;
import java.util.ArrayList;

public class BallGridBeatIndicator
extends Indicator {
    public static final int ALPHA = 255;
    int[] alphas = new int[]{255, 255, 255, 255, 255, 255, 255, 255, 255};

    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = ((float)this.getWidth() - 16.0f) / 6.0f;
        float f2 = this.getWidth() / 2;
        float f3 = 2.0f * f;
        float f4 = f3 + 4.0f;
        float f5 = f2 - f4;
        float f6 = (float)(this.getWidth() / 2) - f4;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                canvas.save();
                float f7 = j;
                float f8 = f5 + f3 * f7 + f7 * 4.0f;
                float f9 = i;
                canvas.translate(f8, f6 + f3 * f9 + f9 * 4.0f);
                paint.setAlpha(this.alphas[j + i * 3]);
                canvas.drawCircle(0.0f, 0.0f, f, paint);
                canvas.restore();
            }
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        int[] arrn = new int[]{960, 930, 1190, 1130, 1340, 940, 1200, 820, 1190};
        int[] arrn2 = new int[]{360, 400, 680, 410, 710, -150, -120, 10, 320};
        for (int i = 0; i < 9; ++i) {
            ValueAnimator valueAnimator = ValueAnimator.ofInt((int[])new int[]{255, 168, 255});
            valueAnimator.setDuration((long)arrn[i]);
            valueAnimator.setRepeatCount(-1);
            valueAnimator.setStartDelay((long)arrn2[i]);
            this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this, i){
                final /* synthetic */ BallGridBeatIndicator this$0;
                final /* synthetic */ int val$index;
                {
                    this.this$0 = ballGridBeatIndicator;
                    this.val$index = n;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.this$0.alphas[this.val$index] = (java.lang.Integer)valueAnimator.getAnimatedValue();
                    this.this$0.postInvalidate();
                }
            });
            arrayList.add((Object)valueAnimator);
        }
        return arrayList;
    }
}

