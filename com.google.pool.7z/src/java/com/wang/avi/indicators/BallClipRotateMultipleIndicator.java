/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.RectF
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallClipRotateMultipleIndicator;
import java.util.ArrayList;

public class BallClipRotateMultipleIndicator
extends Indicator {
    float degrees;
    float scaleFloat = 1.0f;

    @Override
    public void draw(Canvas canvas, Paint paint) {
        paint.setStrokeWidth(3.0f);
        paint.setStyle(Paint.Style.STROKE);
        float f = this.getWidth() / 2;
        float f2 = this.getHeight() / 2;
        canvas.save();
        canvas.translate(f, f2);
        float f3 = this.scaleFloat;
        canvas.scale(f3, f3);
        canvas.rotate(this.degrees);
        float[] arrf = new float[]{135.0f, -45.0f};
        int n = 0;
        for (int i = 0; i < 2; ++i) {
            canvas.drawArc(new RectF(12.0f + -f, 12.0f + -f2, f - 12.0f, f2 - 12.0f), arrf[i], 90.0f, false, paint);
        }
        canvas.restore();
        canvas.translate(f, f2);
        float f4 = this.scaleFloat;
        canvas.scale(f4, f4);
        canvas.rotate(-this.degrees);
        float[] arrf2 = new float[]{225.0f, 45.0f};
        while (n < 2) {
            canvas.drawArc(new RectF(12.0f + -f / 1.8f, 12.0f + -f2 / 1.8f, f / 1.8f - 12.0f, f2 / 1.8f - 12.0f), arrf2[n], 90.0f, false, paint);
            ++n;
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ArrayList arrayList = new ArrayList();
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.6f, 1.0f});
        valueAnimator.setDuration(1000L);
        valueAnimator.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ BallClipRotateMultipleIndicator this$0;
            {
                this.this$0 = ballClipRotateMultipleIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.this$0.scaleFloat = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.postInvalidate();
            }
        });
        ValueAnimator valueAnimator2 = ValueAnimator.ofFloat((float[])new float[]{0.0f, 180.0f, 360.0f});
        valueAnimator2.setDuration(1000L);
        valueAnimator2.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ BallClipRotateMultipleIndicator this$0;
            {
                this.this$0 = ballClipRotateMultipleIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.this$0.degrees = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.postInvalidate();
            }
        });
        arrayList.add((Object)valueAnimator);
        arrayList.add((Object)valueAnimator2);
        return arrayList;
    }
}

