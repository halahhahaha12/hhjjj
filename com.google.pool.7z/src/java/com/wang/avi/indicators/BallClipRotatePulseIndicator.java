/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.RectF
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.wang.avi.indicators;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import com.wang.avi.Indicator;
import com.wang.avi.indicators.BallClipRotatePulseIndicator;
import java.util.ArrayList;

public class BallClipRotatePulseIndicator
extends Indicator {
    float degrees;
    float scaleFloat1;
    float scaleFloat2;

    @Override
    public void draw(Canvas canvas, Paint paint) {
        float f = this.getWidth() / 2;
        float f2 = this.getHeight() / 2;
        canvas.save();
        canvas.translate(f, f2);
        float f3 = this.scaleFloat1;
        canvas.scale(f3, f3);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(0.0f, 0.0f, f / 2.5f, paint);
        canvas.restore();
        canvas.translate(f, f2);
        float f4 = this.scaleFloat2;
        canvas.scale(f4, f4);
        canvas.rotate(this.degrees);
        paint.setStrokeWidth(3.0f);
        paint.setStyle(Paint.Style.STROKE);
        float[] arrf = new float[]{225.0f, 45.0f};
        for (int i = 0; i < 2; ++i) {
            canvas.drawArc(new RectF(12.0f + -f, 12.0f + -f2, f - 12.0f, f2 - 12.0f), arrf[i], 90.0f, false, paint);
        }
    }

    @Override
    public ArrayList<ValueAnimator> onCreateAnimators() {
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.3f, 1.0f});
        valueAnimator.setDuration(1000L);
        valueAnimator.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ BallClipRotatePulseIndicator this$0;
            {
                this.this$0 = ballClipRotatePulseIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.this$0.scaleFloat1 = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.postInvalidate();
            }
        });
        ValueAnimator valueAnimator2 = ValueAnimator.ofFloat((float[])new float[]{1.0f, 0.6f, 1.0f});
        valueAnimator2.setDuration(1000L);
        valueAnimator2.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator2, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ BallClipRotatePulseIndicator this$0;
            {
                this.this$0 = ballClipRotatePulseIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.this$0.scaleFloat2 = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.postInvalidate();
            }
        });
        ValueAnimator valueAnimator3 = ValueAnimator.ofFloat((float[])new float[]{0.0f, 180.0f, 360.0f});
        valueAnimator3.setDuration(1000L);
        valueAnimator3.setRepeatCount(-1);
        this.addUpdateListener(valueAnimator3, new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ BallClipRotatePulseIndicator this$0;
            {
                this.this$0 = ballClipRotatePulseIndicator;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.this$0.degrees = ((java.lang.Float)valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.postInvalidate();
            }
        });
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)valueAnimator);
        arrayList.add((Object)valueAnimator2);
        arrayList.add((Object)valueAnimator3);
        return arrayList;
    }
}

