/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Rect
 *  android.graphics.drawable.Animatable
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 */
package com.wang.avi;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public abstract class Indicator
extends Drawable
implements Animatable {
    private static final Rect ZERO_BOUNDS_RECT = new Rect();
    private int alpha = 255;
    protected Rect drawBounds = ZERO_BOUNDS_RECT;
    private ArrayList<ValueAnimator> mAnimators;
    private boolean mHasAnimators;
    private Paint mPaint;
    private HashMap<ValueAnimator, ValueAnimator.AnimatorUpdateListener> mUpdateListeners = new HashMap();

    public Indicator() {
        Paint paint;
        this.mPaint = paint = new Paint();
        paint.setColor(-1);
        this.mPaint.setStyle(Paint.Style.FILL);
        this.mPaint.setAntiAlias(true);
    }

    private void ensureAnimators() {
        if (!this.mHasAnimators) {
            this.mAnimators = this.onCreateAnimators();
            this.mHasAnimators = true;
        }
    }

    private boolean isStarted() {
        Iterator iterator = this.mAnimators.iterator();
        if (iterator.hasNext()) {
            return ((ValueAnimator)iterator.next()).isStarted();
        }
        return false;
    }

    private void startAnimators() {
        for (int i = 0; i < this.mAnimators.size(); ++i) {
            ValueAnimator valueAnimator = (ValueAnimator)this.mAnimators.get(i);
            ValueAnimator.AnimatorUpdateListener animatorUpdateListener = (ValueAnimator.AnimatorUpdateListener)this.mUpdateListeners.get((Object)valueAnimator);
            if (animatorUpdateListener != null) {
                valueAnimator.addUpdateListener(animatorUpdateListener);
            }
            valueAnimator.start();
        }
    }

    private void stopAnimators() {
        ArrayList<ValueAnimator> arrayList = this.mAnimators;
        if (arrayList != null) {
            for (ValueAnimator valueAnimator : arrayList) {
                if (valueAnimator == null || !valueAnimator.isStarted()) continue;
                valueAnimator.removeAllUpdateListeners();
                valueAnimator.end();
            }
        }
    }

    public void addUpdateListener(ValueAnimator valueAnimator, ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        this.mUpdateListeners.put((Object)valueAnimator, (Object)animatorUpdateListener);
    }

    public int centerX() {
        return this.drawBounds.centerX();
    }

    public int centerY() {
        return this.drawBounds.centerY();
    }

    public void draw(Canvas canvas) {
        this.draw(canvas, this.mPaint);
    }

    public abstract void draw(Canvas var1, Paint var2);

    public float exactCenterX() {
        return this.drawBounds.exactCenterX();
    }

    public float exactCenterY() {
        return this.drawBounds.exactCenterY();
    }

    public int getAlpha() {
        return this.alpha;
    }

    public int getColor() {
        return this.mPaint.getColor();
    }

    public Rect getDrawBounds() {
        return this.drawBounds;
    }

    public int getHeight() {
        return this.drawBounds.height();
    }

    public int getOpacity() {
        return -1;
    }

    public int getWidth() {
        return this.drawBounds.width();
    }

    public boolean isRunning() {
        Iterator iterator = this.mAnimators.iterator();
        if (iterator.hasNext()) {
            return ((ValueAnimator)iterator.next()).isRunning();
        }
        return false;
    }

    protected void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        this.setDrawBounds(rect);
    }

    public abstract ArrayList<ValueAnimator> onCreateAnimators();

    public void postInvalidate() {
        this.invalidateSelf();
    }

    public void setAlpha(int n) {
        this.alpha = n;
    }

    public void setColor(int n) {
        this.mPaint.setColor(n);
    }

    public void setColorFilter(ColorFilter colorFilter) {
    }

    public void setDrawBounds(int n, int n2, int n3, int n4) {
        this.drawBounds = new Rect(n, n2, n3, n4);
    }

    public void setDrawBounds(Rect rect) {
        this.setDrawBounds(rect.left, rect.top, rect.right, rect.bottom);
    }

    public void start() {
        this.ensureAnimators();
        if (this.mAnimators == null) {
            return;
        }
        if (this.isStarted()) {
            return;
        }
        this.startAnimators();
        this.invalidateSelf();
    }

    public void stop() {
        this.stopAnimators();
    }
}

