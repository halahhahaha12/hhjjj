/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Rect
 *  android.graphics.drawable.Animatable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$Callback
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.View
 *  android.view.animation.Animation
 *  android.view.animation.AnimationUtils
 *  com.wang.avi.indicators.BallPulseIndicator
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalAccessException
 *  java.lang.InstantiationException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Package
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 */
package com.wang.avi;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.wang.avi.Indicator;
import com.wang.avi.R;
import com.wang.avi.indicators.BallPulseIndicator;

public class AVLoadingIndicatorView
extends View {
    private static final BallPulseIndicator DEFAULT_INDICATOR = new BallPulseIndicator();
    private static final int MIN_DELAY = 500;
    private static final int MIN_SHOW_TIME = 500;
    private static final String TAG = "AVLoadingIndicatorView";
    private final Runnable mDelayedHide = new Runnable(){

        public void run() {
            AVLoadingIndicatorView.this.mPostedHide = false;
            AVLoadingIndicatorView.this.mStartTime = -1L;
            AVLoadingIndicatorView.this.setVisibility(8);
        }
    };
    private final Runnable mDelayedShow = new Runnable(){

        public void run() {
            AVLoadingIndicatorView.this.mPostedShow = false;
            if (!AVLoadingIndicatorView.this.mDismissed) {
                AVLoadingIndicatorView.this.mStartTime = System.currentTimeMillis();
                AVLoadingIndicatorView.this.setVisibility(0);
            }
        }
    };
    private boolean mDismissed = false;
    private Indicator mIndicator;
    private int mIndicatorColor;
    int mMaxHeight;
    int mMaxWidth;
    int mMinHeight;
    int mMinWidth;
    private boolean mPostedHide = false;
    private boolean mPostedShow = false;
    private boolean mShouldStartAnimationDrawable;
    private long mStartTime = -1L;

    public AVLoadingIndicatorView(Context context) {
        super(context);
        this.init(context, null, 0, 0);
    }

    public AVLoadingIndicatorView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init(context, attributeSet, 0, R.style.AVLoadingIndicatorView);
    }

    public AVLoadingIndicatorView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init(context, attributeSet, n, R.style.AVLoadingIndicatorView);
    }

    public AVLoadingIndicatorView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        this.init(context, attributeSet, n, R.style.AVLoadingIndicatorView);
    }

    private void init(Context context, AttributeSet attributeSet, int n, int n2) {
        this.mMinWidth = 24;
        this.mMaxWidth = 48;
        this.mMinHeight = 24;
        this.mMaxHeight = 48;
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, R.styleable.AVLoadingIndicatorView, n, n2);
        this.mMinWidth = typedArray.getDimensionPixelSize(R.styleable.AVLoadingIndicatorView_minWidth, this.mMinWidth);
        this.mMaxWidth = typedArray.getDimensionPixelSize(R.styleable.AVLoadingIndicatorView_maxWidth, this.mMaxWidth);
        this.mMinHeight = typedArray.getDimensionPixelSize(R.styleable.AVLoadingIndicatorView_minHeight, this.mMinHeight);
        this.mMaxHeight = typedArray.getDimensionPixelSize(R.styleable.AVLoadingIndicatorView_maxHeight, this.mMaxHeight);
        String string2 = typedArray.getString(R.styleable.AVLoadingIndicatorView_indicatorName);
        this.mIndicatorColor = typedArray.getColor(R.styleable.AVLoadingIndicatorView_indicatorColor, -1);
        this.setIndicator(string2);
        if (this.mIndicator == null) {
            this.setIndicator((Indicator)DEFAULT_INDICATOR);
        }
        typedArray.recycle();
    }

    private void removeCallbacks() {
        this.removeCallbacks(this.mDelayedHide);
        this.removeCallbacks(this.mDelayedShow);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void updateDrawableBounds(int var1_1, int var2_2) {
        var3_3 = var1_1 - (this.getPaddingRight() + this.getPaddingLeft());
        var4_4 = var2_2 - (this.getPaddingTop() + this.getPaddingBottom());
        var5_5 = this.mIndicator;
        if (var5_5 == null) return;
        var6_6 = var5_5.getIntrinsicWidth();
        var7_7 = this.mIndicator.getIntrinsicHeight();
        var8_8 = (float)var6_6 / (float)var7_7;
        var9_9 = var3_3;
        var10_10 = var4_4;
        var11_11 = var9_9 / var10_10;
        var12_12 = var8_8 FCMPL var11_11;
        var13_13 = 0;
        if (var12_12 == false) ** GOTO lbl27
        if (!(var11_11 > var8_8)) {
            var15_17 = (int)(var9_9 * (1.0f / var8_8));
            var16_18 = (var4_4 - var15_17) / 2;
            var17_19 = var15_17 + var16_18;
            var14_20 = var16_18;
            var4_4 = var17_19;
            var13_13 = 0;
        } else {
            var18_14 = (int)(var10_10 * var8_8);
            var19_15 = (var3_3 - var18_14) / 2;
            var20_16 = var18_14 + var19_15;
            var13_13 = var19_15;
            var3_3 = var20_16;
lbl27: // 2 sources:
            var14_20 = 0;
        }
        this.mIndicator.setBounds(var13_13, var14_20, var3_3, var4_4);
    }

    private void updateDrawableState() {
        int[] arrn = this.getDrawableState();
        Indicator indicator = this.mIndicator;
        if (indicator != null && indicator.isStateful()) {
            this.mIndicator.setState(arrn);
        }
    }

    void drawTrack(Canvas canvas) {
        Indicator indicator = this.mIndicator;
        if (indicator != null) {
            int n = canvas.save();
            canvas.translate((float)this.getPaddingLeft(), (float)this.getPaddingTop());
            indicator.draw(canvas);
            canvas.restoreToCount(n);
            if (this.mShouldStartAnimationDrawable && indicator instanceof Animatable) {
                ((Animatable)indicator).start();
                this.mShouldStartAnimationDrawable = false;
            }
        }
    }

    public void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Indicator indicator = this.mIndicator;
        if (indicator != null) {
            indicator.setHotspot(f, f2);
        }
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        this.updateDrawableState();
    }

    public Indicator getIndicator() {
        return this.mIndicator;
    }

    public void hide() {
        this.mDismissed = true;
        this.removeCallbacks(this.mDelayedShow);
        long l = System.currentTimeMillis();
        long l2 = this.mStartTime;
        long l3 = l - l2;
        if (l3 < 500L && l2 != -1L) {
            if (!this.mPostedHide) {
                this.postDelayed(this.mDelayedHide, 500L - l3);
                this.mPostedHide = true;
                return;
            }
        } else {
            this.setVisibility(8);
        }
    }

    public void invalidateDrawable(Drawable drawable2) {
        if (this.verifyDrawable(drawable2)) {
            Rect rect = drawable2.getBounds();
            int n = this.getScrollX() + this.getPaddingLeft();
            int n2 = this.getScrollY() + this.getPaddingTop();
            this.invalidate(n + rect.left, n2 + rect.top, n + rect.right, n2 + rect.bottom);
            return;
        }
        super.invalidateDrawable(drawable2);
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.startAnimation();
        this.removeCallbacks();
    }

    protected void onDetachedFromWindow() {
        this.stopAnimation();
        super.onDetachedFromWindow();
        this.removeCallbacks();
    }

    protected void onDraw(Canvas canvas) {
        AVLoadingIndicatorView aVLoadingIndicatorView = this;
        synchronized (aVLoadingIndicatorView) {
            super.onDraw(canvas);
            this.drawTrack(canvas);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onMeasure(int n, int n2) {
        AVLoadingIndicatorView aVLoadingIndicatorView = this;
        synchronized (aVLoadingIndicatorView) {
            int n3;
            int n4;
            Indicator indicator = this.mIndicator;
            if (indicator != null) {
                n4 = Math.max((int)this.mMinWidth, (int)Math.min((int)this.mMaxWidth, (int)indicator.getIntrinsicWidth()));
                n3 = Math.max((int)this.mMinHeight, (int)Math.min((int)this.mMaxHeight, (int)indicator.getIntrinsicHeight()));
            } else {
                n3 = 0;
                n4 = 0;
            }
            this.updateDrawableState();
            int n5 = n4 + (this.getPaddingLeft() + this.getPaddingRight());
            int n6 = n3 + (this.getPaddingTop() + this.getPaddingBottom());
            this.setMeasuredDimension(AVLoadingIndicatorView.resolveSizeAndState((int)n5, (int)n, (int)0), AVLoadingIndicatorView.resolveSizeAndState((int)n6, (int)n2, (int)0));
            return;
        }
    }

    protected void onSizeChanged(int n, int n2, int n3, int n4) {
        this.updateDrawableBounds(n, n2);
    }

    protected void onVisibilityChanged(View view, int n) {
        super.onVisibilityChanged(view, n);
        if (n != 8 && n != 4) {
            this.startAnimation();
            return;
        }
        this.stopAnimation();
    }

    public void setIndicator(Indicator indicator) {
        Indicator indicator2 = this.mIndicator;
        if (indicator2 != indicator) {
            if (indicator2 != null) {
                indicator2.setCallback(null);
                this.unscheduleDrawable((Drawable)this.mIndicator);
            }
            this.mIndicator = indicator;
            this.setIndicatorColor(this.mIndicatorColor);
            if (indicator != null) {
                indicator.setCallback((Drawable.Callback)this);
            }
            this.postInvalidate();
        }
    }

    public void setIndicator(String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (!string2.contains((CharSequence)".")) {
            stringBuilder.append(this.getClass().getPackage().getName());
            stringBuilder.append(".indicators");
            stringBuilder.append(".");
        }
        stringBuilder.append(string2);
        try {
            this.setIndicator((Indicator)((Object)Class.forName((String)stringBuilder.toString()).newInstance()));
            return;
        }
        catch (IllegalAccessException illegalAccessException) {
            illegalAccessException.printStackTrace();
            return;
        }
        catch (InstantiationException instantiationException) {
            instantiationException.printStackTrace();
            return;
        }
        catch (ClassNotFoundException classNotFoundException) {
            Log.e((String)TAG, (String)"Didn't find your class , check the name again !");
            return;
        }
    }

    public void setIndicatorColor(int n) {
        this.mIndicatorColor = n;
        this.mIndicator.setColor(n);
    }

    public void setVisibility(int n) {
        if (this.getVisibility() != n) {
            super.setVisibility(n);
            if (n != 8 && n != 4) {
                this.startAnimation();
                return;
            }
            this.stopAnimation();
        }
    }

    public void show() {
        this.mStartTime = -1L;
        this.mDismissed = false;
        this.removeCallbacks(this.mDelayedHide);
        if (!this.mPostedShow) {
            this.postDelayed(this.mDelayedShow, 500L);
            this.mPostedShow = true;
        }
    }

    public void smoothToHide() {
        this.startAnimation(AnimationUtils.loadAnimation((Context)this.getContext(), (int)17432577));
        this.setVisibility(8);
    }

    public void smoothToShow() {
        this.startAnimation(AnimationUtils.loadAnimation((Context)this.getContext(), (int)17432576));
        this.setVisibility(0);
    }

    void startAnimation() {
        if (this.getVisibility() != 0) {
            return;
        }
        if (this.mIndicator instanceof Animatable) {
            this.mShouldStartAnimationDrawable = true;
        }
        this.postInvalidate();
    }

    void stopAnimation() {
        Indicator indicator = this.mIndicator;
        if (indicator instanceof Animatable) {
            indicator.stop();
            this.mShouldStartAnimationDrawable = false;
        }
        this.postInvalidate();
    }

    protected boolean verifyDrawable(Drawable drawable2) {
        return drawable2 == this.mIndicator || super.verifyDrawable(drawable2);
        {
        }
    }

}

