/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.value.LottieValueCallback;

public final class LottieDrawable$$ExternalSyntheticLambda1
implements LottieDrawable.LazyCompositionTask {
    public final /* synthetic */ LottieDrawable f$0;
    public final /* synthetic */ KeyPath f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ LottieValueCallback f$3;

    public /* synthetic */ LottieDrawable$$ExternalSyntheticLambda1(LottieDrawable lottieDrawable, KeyPath keyPath, Object object, LottieValueCallback lottieValueCallback) {
        this.f$0 = lottieDrawable;
        this.f$1 = keyPath;
        this.f$2 = object;
        this.f$3 = lottieValueCallback;
    }

    @Override
    public final void run(LottieComposition lottieComposition) {
        this.f$0.lambda$addValueCallback$14$com-airbnb-lottie-LottieDrawable(this.f$1, this.f$2, this.f$3, lottieComposition);
    }
}

