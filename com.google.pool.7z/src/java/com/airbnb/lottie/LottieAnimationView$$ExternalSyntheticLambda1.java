/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.LottieAnimationView
 *  java.lang.Object
 *  java.lang.Throwable
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieListener;

public final class LottieAnimationView$$ExternalSyntheticLambda1
implements LottieListener {
    public static final /* synthetic */ LottieAnimationView$$ExternalSyntheticLambda1 INSTANCE;

    static /* synthetic */ {
        INSTANCE = new LottieAnimationView$$ExternalSyntheticLambda1();
    }

    private /* synthetic */ LottieAnimationView$$ExternalSyntheticLambda1() {
    }

    public final void onResult(Object object) {
        LottieAnimationView.lambda$static$0((Throwable)((Throwable)object));
    }
}

