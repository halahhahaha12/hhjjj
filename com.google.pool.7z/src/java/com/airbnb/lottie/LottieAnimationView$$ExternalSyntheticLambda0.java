/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.LottieAnimationView
 *  java.lang.Object
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieListener;

public final class LottieAnimationView$$ExternalSyntheticLambda0
implements LottieListener {
    public final /* synthetic */ LottieAnimationView f$0;

    public /* synthetic */ LottieAnimationView$$ExternalSyntheticLambda0(LottieAnimationView lottieAnimationView) {
        this.f$0 = lottieAnimationView;
    }

    public final void onResult(Object object) {
        this.f$0.setComposition((LottieComposition)object);
    }
}

