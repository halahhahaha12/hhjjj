/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  android.graphics.Paint
 *  com.airbnb.lottie.model.animatable.AnimatableColorValue
 *  com.airbnb.lottie.model.animatable.AnimatableFloatValue
 *  com.airbnb.lottie.model.layer.BaseLayer
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 */
package com.airbnb.lottie.animation.keyframe;

import android.graphics.Color;
import android.graphics.Paint;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.model.animatable.AnimatableColorValue;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.parser.DropShadowEffect;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.LottieValueCallback;

public class DropShadowKeyframeAnimation
implements BaseKeyframeAnimation.AnimationListener {
    private static final double DEG_TO_RAD = 0.017453292519943295;
    private final BaseKeyframeAnimation<Integer, Integer> color;
    private final BaseKeyframeAnimation<Float, Float> direction;
    private final BaseKeyframeAnimation<Float, Float> distance;
    private boolean isDirty = true;
    private final BaseKeyframeAnimation.AnimationListener listener;
    private final BaseKeyframeAnimation<Float, Float> opacity;
    private final BaseKeyframeAnimation<Float, Float> radius;

    public DropShadowKeyframeAnimation(BaseKeyframeAnimation.AnimationListener animationListener, BaseLayer baseLayer, DropShadowEffect dropShadowEffect) {
        BaseKeyframeAnimation baseKeyframeAnimation;
        BaseKeyframeAnimation baseKeyframeAnimation2;
        BaseKeyframeAnimation baseKeyframeAnimation3;
        BaseKeyframeAnimation baseKeyframeAnimation4;
        BaseKeyframeAnimation baseKeyframeAnimation5;
        this.listener = animationListener;
        this.color = baseKeyframeAnimation2 = dropShadowEffect.getColor().createAnimation();
        baseKeyframeAnimation2.addUpdateListener(this);
        baseLayer.addAnimation(baseKeyframeAnimation2);
        this.opacity = baseKeyframeAnimation = dropShadowEffect.getOpacity().createAnimation();
        baseKeyframeAnimation.addUpdateListener(this);
        baseLayer.addAnimation(baseKeyframeAnimation);
        this.direction = baseKeyframeAnimation4 = dropShadowEffect.getDirection().createAnimation();
        baseKeyframeAnimation4.addUpdateListener(this);
        baseLayer.addAnimation(baseKeyframeAnimation4);
        this.distance = baseKeyframeAnimation3 = dropShadowEffect.getDistance().createAnimation();
        baseKeyframeAnimation3.addUpdateListener(this);
        baseLayer.addAnimation(baseKeyframeAnimation3);
        this.radius = baseKeyframeAnimation5 = dropShadowEffect.getRadius().createAnimation();
        baseKeyframeAnimation5.addUpdateListener(this);
        baseLayer.addAnimation(baseKeyframeAnimation5);
    }

    public void applyTo(Paint paint) {
        if (!this.isDirty) {
            return;
        }
        this.isDirty = false;
        double d = this.direction.getValue().floatValue();
        Double.isNaN((double)d);
        double d2 = d * 0.017453292519943295;
        float f = this.distance.getValue().floatValue();
        float f2 = f * (float)Math.sin((double)d2);
        float f3 = f * (float)Math.cos((double)(d2 + 3.141592653589793));
        int n = this.color.getValue();
        int n2 = Color.argb((int)Math.round((float)this.opacity.getValue().floatValue()), (int)Color.red((int)n), (int)Color.green((int)n), (int)Color.blue((int)n));
        paint.setShadowLayer(this.radius.getValue().floatValue(), f2, f3, n2);
    }

    @Override
    public void onValueChanged() {
        this.isDirty = true;
        this.listener.onValueChanged();
    }

    public void setColorCallback(LottieValueCallback<Integer> lottieValueCallback) {
        this.color.setValueCallback(lottieValueCallback);
    }

    public void setDirectionCallback(LottieValueCallback<Float> lottieValueCallback) {
        this.direction.setValueCallback(lottieValueCallback);
    }

    public void setDistanceCallback(LottieValueCallback<Float> lottieValueCallback) {
        this.distance.setValueCallback(lottieValueCallback);
    }

    public void setOpacityCallback(final LottieValueCallback<Float> lottieValueCallback) {
        if (lottieValueCallback == null) {
            this.opacity.setValueCallback(null);
            return;
        }
        this.opacity.setValueCallback(new LottieValueCallback<Float>(){

            @Override
            public Float getValue(LottieFrameInfo<Float> lottieFrameInfo) {
                Float f = lottieValueCallback.getValue(lottieFrameInfo);
                if (f == null) {
                    return null;
                }
                return Float.valueOf((float)(2.55f * f.floatValue()));
            }
        });
    }

    public void setRadiusCallback(LottieValueCallback<Float> lottieValueCallback) {
        this.radius.setValueCallback(lottieValueCallback);
    }

}

