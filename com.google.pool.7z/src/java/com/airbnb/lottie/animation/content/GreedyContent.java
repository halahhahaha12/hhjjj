/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ListIterator
 */
package com.airbnb.lottie.animation.content;

import com.airbnb.lottie.animation.content.Content;
import java.util.ListIterator;

interface GreedyContent {
    public void absorbContent(ListIterator<Content> var1);
}

