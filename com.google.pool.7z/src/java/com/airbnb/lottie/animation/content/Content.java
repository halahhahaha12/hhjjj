/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.airbnb.lottie.animation.content;

import java.util.List;

public interface Content {
    public String getName();

    public void setContents(List<Content> var1, List<Content> var2);
}

