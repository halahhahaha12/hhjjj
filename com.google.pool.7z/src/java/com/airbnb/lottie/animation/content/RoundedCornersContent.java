/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.PointF
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.airbnb.lottie.animation.content;

import android.graphics.PointF;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.ShapeModifierContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.model.CubicCurveData;
import com.airbnb.lottie.model.animatable.AnimatableValue;
import com.airbnb.lottie.model.content.RoundedCorners;
import com.airbnb.lottie.model.content.ShapeData;
import com.airbnb.lottie.model.layer.BaseLayer;
import java.util.ArrayList;
import java.util.List;

public class RoundedCornersContent
implements ShapeModifierContent,
BaseKeyframeAnimation.AnimationListener {
    private static final float ROUNDED_CORNER_MAGIC_NUMBER = 0.5519f;
    private final LottieDrawable lottieDrawable;
    private final String name;
    private final BaseKeyframeAnimation<Float, Float> roundedCorners;
    private ShapeData shapeData;

    public RoundedCornersContent(LottieDrawable lottieDrawable, BaseLayer baseLayer, RoundedCorners roundedCorners) {
        this.lottieDrawable = lottieDrawable;
        this.name = roundedCorners.getName();
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = roundedCorners.getCornerRadius().createAnimation();
        this.roundedCorners = baseKeyframeAnimation;
        baseLayer.addAnimation(baseKeyframeAnimation);
        baseKeyframeAnimation.addUpdateListener(this);
    }

    private static int floorDiv(int n, int n2) {
        int n3 = n / n2;
        if ((n ^ n2) < 0 && n2 * n3 != n) {
            --n3;
        }
        return n3;
    }

    private static int floorMod(int n, int n2) {
        return n - n2 * RoundedCornersContent.floorDiv(n, n2);
    }

    private ShapeData getShapeData(ShapeData shapeData) {
        List<CubicCurveData> list = shapeData.getCurves();
        boolean bl = shapeData.isClosed();
        int n = 0;
        for (int i = list.size() - 1; i >= 0; --i) {
            CubicCurveData cubicCurveData = (CubicCurveData)list.get(i);
            CubicCurveData cubicCurveData2 = (CubicCurveData)list.get(RoundedCornersContent.floorMod(i - 1, list.size()));
            PointF pointF = i == 0 && !bl ? shapeData.getInitialPoint() : cubicCurveData2.getVertex();
            PointF pointF2 = i == 0 && !bl ? pointF : cubicCurveData2.getControlPoint2();
            PointF pointF3 = cubicCurveData.getControlPoint1();
            boolean bl2 = !shapeData.isClosed() && i == 0 && i == list.size() - 1;
            if (pointF2.equals((Object)pointF) && pointF3.equals((Object)pointF) && !bl2) {
                n += 2;
                continue;
            }
            ++n;
        }
        ShapeData shapeData2 = this.shapeData;
        if (shapeData2 == null || shapeData2.getCurves().size() != n) {
            ArrayList arrayList = new ArrayList(n);
            for (int i = 0; i < n; ++i) {
                arrayList.add((Object)new CubicCurveData());
            }
            this.shapeData = new ShapeData(new PointF(0.0f, 0.0f), false, (List<CubicCurveData>)arrayList);
        }
        this.shapeData.setClosed(bl);
        return this.shapeData;
    }

    @Override
    public String getName() {
        return this.name;
    }

    public BaseKeyframeAnimation<Float, Float> getRoundedCorners() {
        return this.roundedCorners;
    }

    @Override
    public ShapeData modifyShape(ShapeData shapeData) {
        List<CubicCurveData> list = shapeData.getCurves();
        if (list.size() <= 2) {
            return shapeData;
        }
        float f = this.roundedCorners.getValue().floatValue();
        if (f == 0.0f) {
            return shapeData;
        }
        ShapeData shapeData2 = this.getShapeData(shapeData);
        shapeData2.setInitialPoint(shapeData.getInitialPoint().x, shapeData.getInitialPoint().y);
        List<CubicCurveData> list2 = shapeData2.getCurves();
        boolean bl = shapeData.isClosed();
        int n = 0;
        for (int i = 0; i < list.size(); ++i) {
            List<CubicCurveData> list3;
            boolean bl2;
            CubicCurveData cubicCurveData = (CubicCurveData)list.get(i);
            CubicCurveData cubicCurveData2 = (CubicCurveData)list.get(RoundedCornersContent.floorMod(i - 1, list.size()));
            CubicCurveData cubicCurveData3 = (CubicCurveData)list.get(RoundedCornersContent.floorMod(i - 2, list.size()));
            PointF pointF = i == 0 && !bl ? shapeData.getInitialPoint() : cubicCurveData2.getVertex();
            PointF pointF2 = i == 0 && !bl ? pointF : cubicCurveData2.getControlPoint2();
            PointF pointF3 = cubicCurveData.getControlPoint1();
            PointF pointF4 = cubicCurveData3.getVertex();
            PointF pointF5 = cubicCurveData.getVertex();
            boolean bl3 = !shapeData.isClosed() && i == 0 && i == -1 + list.size();
            if (pointF2.equals((Object)pointF) && pointF3.equals((Object)pointF) && !bl3) {
                float f2 = pointF.x - pointF4.x;
                float f3 = pointF.y - pointF4.y;
                float f4 = pointF5.x - pointF.x;
                float f5 = pointF5.y - pointF.y;
                list3 = list;
                double d = f2;
                bl2 = bl;
                float f6 = (float)Math.hypot((double)d, (double)f3);
                float f7 = (float)Math.hypot((double)f4, (double)f5);
                float f8 = Math.min((float)(f / f6), (float)0.5f);
                float f9 = Math.min((float)(f / f7), (float)0.5f);
                float f10 = pointF.x + f8 * (pointF4.x - pointF.x);
                float f11 = pointF.y + f8 * (pointF4.y - pointF.y);
                float f12 = pointF.x + f9 * (pointF5.x - pointF.x);
                float f13 = pointF.y + f9 * (pointF5.y - pointF.y);
                float f14 = f10 - 0.5519f * (f10 - pointF.x);
                float f15 = f11 - 0.5519f * (f11 - pointF.y);
                float f16 = f12 - 0.5519f * (f12 - pointF.x);
                float f17 = f13 - 0.5519f * (f13 - pointF.y);
                CubicCurveData cubicCurveData4 = (CubicCurveData)list2.get(RoundedCornersContent.floorMod(n - 1, list2.size()));
                CubicCurveData cubicCurveData5 = (CubicCurveData)list2.get(n);
                cubicCurveData4.setControlPoint2(f10, f11);
                cubicCurveData4.setVertex(f10, f11);
                if (i == 0) {
                    shapeData2.setInitialPoint(f10, f11);
                }
                cubicCurveData5.setControlPoint1(f14, f15);
                int n2 = n + 1;
                CubicCurveData cubicCurveData6 = (CubicCurveData)list2.get(n2);
                cubicCurveData5.setControlPoint2(f16, f17);
                cubicCurveData5.setVertex(f12, f13);
                cubicCurveData6.setControlPoint1(f12, f13);
                n = n2 + 1;
            } else {
                list3 = list;
                bl2 = bl;
                CubicCurveData cubicCurveData7 = (CubicCurveData)list2.get(RoundedCornersContent.floorMod(n - 1, list2.size()));
                CubicCurveData cubicCurveData8 = (CubicCurveData)list2.get(n);
                cubicCurveData7.setControlPoint2(cubicCurveData2.getVertex().x, cubicCurveData2.getVertex().y);
                cubicCurveData7.setVertex(cubicCurveData2.getVertex().x, cubicCurveData2.getVertex().y);
                cubicCurveData8.setControlPoint1(cubicCurveData.getVertex().x, cubicCurveData.getVertex().y);
                ++n;
            }
            list = list3;
            bl = bl2;
        }
        return shapeData2;
    }

    @Override
    public void onValueChanged() {
        this.lottieDrawable.invalidateSelf();
    }

    @Override
    public void setContents(List<Content> list, List<Content> list2) {
    }
}

