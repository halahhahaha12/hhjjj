/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.airbnb.lottie.animation.content;

import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.model.KeyPathElement;

public interface KeyPathElementContent
extends KeyPathElement,
Content {
}

