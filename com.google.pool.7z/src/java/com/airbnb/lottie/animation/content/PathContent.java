/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Path
 *  java.lang.Object
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Path;
import com.airbnb.lottie.animation.content.Content;

interface PathContent
extends Content {
    public Path getPath();
}

