/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.model.animatable.AnimatableIntegerValue
 *  com.airbnb.lottie.model.animatable.AnimatableShapeValue
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.airbnb.lottie.parser;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.model.animatable.AnimatableIntegerValue;
import com.airbnb.lottie.model.animatable.AnimatableShapeValue;
import com.airbnb.lottie.model.content.Mask;
import com.airbnb.lottie.parser.AnimatableValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.utils.Logger;
import java.io.IOException;

class MaskParser {
    private MaskParser() {
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static Mask parse(JsonReader var0, LottieComposition var1_1) throws IOException {
        var0.beginObject();
        var2_2 = null;
        var3_3 = null;
        var4_4 = null;
        var5_5 = false;
        block24 : do {
            block27 : {
                if (!var0.hasNext()) {
                    var0.endObject();
                    return new Mask(var2_2, var3_3, var4_4, var5_5);
                }
                var6_6 = var0.nextName();
                var6_6.hashCode();
                var8_7 = var6_6.hashCode();
                var9_8 = 3;
                switch (var8_7) {
                    case 3357091: {
                        if (!var6_6.equals((Object)"mode")) break;
                        var10_9 = 3;
                        ** break;
                    }
                    case 104433: {
                        if (!var6_6.equals((Object)"inv")) break;
                        var10_9 = 2;
                        ** break;
                    }
                    case 3588: {
                        if (!var6_6.equals((Object)"pt")) break;
                        var10_9 = 1;
                        ** break;
                    }
                    case 111: {
                        if (var6_6.equals((Object)"o")) break block27;
                    }
                }
                var10_9 = -1;
                ** break;
            }
            var10_9 = 0;
lbl33: // 5 sources:
            switch (var10_9) {
                default: {
                    var0.skipValue();
                    continue block24;
                }
                case 3: {
                    var11_10 = var0.nextString();
                    var11_10.hashCode();
                    switch (var11_10.hashCode()) {
                        case 115: {
                            if (!var11_10.equals((Object)"s")) {
                                break;
                            }
                            ** GOTO lbl58
                        }
                        case 110: {
                            if (!var11_10.equals((Object)"n")) break;
                            var9_8 = 2;
                            ** break;
                        }
                        case 105: {
                            if (!var11_10.equals((Object)"i")) break;
                            var9_8 = 1;
                            ** break;
                        }
                        case 97: {
                            if (var11_10.equals((Object)"a")) ** GOTO lbl57
                        }
                    }
                    var9_8 = -1;
                    ** break;
lbl57: // 1 sources:
                    var9_8 = 0;
lbl58: // 5 sources:
                    switch (var9_8) {
                        default: {
                            var13_11 = new StringBuilder();
                            var13_11.append("Unknown mask mode ");
                            var13_11.append(var6_6);
                            var13_11.append(". Defaulting to Add.");
                            Logger.warning(var13_11.toString());
                            var2_2 = Mask.MaskMode.MASK_MODE_ADD;
                            continue block24;
                        }
                        case 3: {
                            var2_2 = Mask.MaskMode.MASK_MODE_SUBTRACT;
                            continue block24;
                        }
                        case 2: {
                            var2_2 = Mask.MaskMode.MASK_MODE_NONE;
                            continue block24;
                        }
                        case 1: {
                            var1_1.addWarning("Animation contains intersect masks. They are not supported but will be treated like add masks.");
                            var2_2 = Mask.MaskMode.MASK_MODE_INTERSECT;
                            continue block24;
                        }
                        case 0: 
                    }
                    var2_2 = Mask.MaskMode.MASK_MODE_ADD;
                    continue block24;
                }
                case 2: {
                    var5_5 = var0.nextBoolean();
                    continue block24;
                }
                case 1: {
                    var3_3 = AnimatableValueParser.parseShapeData(var0, var1_1);
                    continue block24;
                }
                case 0: 
            }
            var4_4 = AnimatableValueParser.parseInteger(var0, var1_1);
        } while (true);
    }
}

