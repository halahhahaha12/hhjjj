/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package com.airbnb.lottie.parser.moshi;

final class JsonDataException
extends RuntimeException {
    JsonDataException(String string2) {
        super(string2);
    }
}

