/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieCompositionFactory;
import com.airbnb.lottie.LottieListener;
import java.util.concurrent.atomic.AtomicBoolean;

public final class LottieCompositionFactory$$ExternalSyntheticLambda2
implements LottieListener {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ AtomicBoolean f$1;

    public /* synthetic */ LottieCompositionFactory$$ExternalSyntheticLambda2(String string2, AtomicBoolean atomicBoolean) {
        this.f$0 = string2;
        this.f$1 = atomicBoolean;
    }

    public final void onResult(Object object) {
        LottieCompositionFactory.lambda$cache$10(this.f$0, this.f$1, (Throwable)object);
    }
}

