/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.core.os.TraceCompat
 *  com.airbnb.lottie.L$1
 *  com.airbnb.lottie.network.DefaultLottieNetworkFetcher
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 */
package com.airbnb.lottie;

import android.content.Context;
import androidx.core.os.TraceCompat;
import com.airbnb.lottie.L;
import com.airbnb.lottie.network.DefaultLottieNetworkFetcher;
import com.airbnb.lottie.network.LottieNetworkCacheProvider;
import com.airbnb.lottie.network.LottieNetworkFetcher;
import com.airbnb.lottie.network.NetworkCache;
import com.airbnb.lottie.network.NetworkFetcher;

public class L {
    public static boolean DBG = false;
    private static final int MAX_DEPTH = 20;
    public static final String TAG = "LOTTIE";
    private static LottieNetworkCacheProvider cacheProvider;
    private static int depthPastMaxDepth;
    private static LottieNetworkFetcher fetcher;
    private static volatile NetworkCache networkCache;
    private static volatile NetworkFetcher networkFetcher;
    private static String[] sections;
    private static long[] startTimeNs;
    private static int traceDepth;
    private static boolean traceEnabled;

    private L() {
    }

    public static void beginSection(String string2) {
        if (!traceEnabled) {
            return;
        }
        int n = traceDepth;
        if (n == 20) {
            depthPastMaxDepth = 1 + depthPastMaxDepth;
            return;
        }
        L.sections[n] = string2;
        L.startTimeNs[n] = System.nanoTime();
        TraceCompat.beginSection((String)string2);
        traceDepth = 1 + traceDepth;
    }

    public static float endSection(String string2) {
        int n;
        int n2 = depthPastMaxDepth;
        if (n2 > 0) {
            depthPastMaxDepth = n2 - 1;
            return 0.0f;
        }
        if (!traceEnabled) {
            return 0.0f;
        }
        traceDepth = n = -1 + traceDepth;
        if (n != -1) {
            if (string2.equals((Object)sections[n])) {
                TraceCompat.endSection();
                return (float)(System.nanoTime() - startTimeNs[traceDepth]) / 1000000.0f;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unbalanced trace call ");
            stringBuilder.append(string2);
            stringBuilder.append(". Expected ");
            stringBuilder.append(sections[traceDepth]);
            stringBuilder.append(".");
            throw new IllegalStateException(stringBuilder.toString());
        }
        throw new IllegalStateException("Can't end trace section. There are none.");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static NetworkCache networkCache(Context context) {
        Context context2 = context.getApplicationContext();
        NetworkCache networkCache = L.networkCache;
        if (networkCache != null) {
            return networkCache;
        }
        Class<NetworkCache> class_ = NetworkCache.class;
        synchronized (NetworkCache.class) {
            NetworkCache networkCache2 = L.networkCache;
            if (networkCache2 == null) {
                LottieNetworkCacheProvider lottieNetworkCacheProvider = cacheProvider;
                if (lottieNetworkCacheProvider == null) {
                    lottieNetworkCacheProvider = new 1(context2);
                }
                L.networkCache = networkCache2 = new NetworkCache(lottieNetworkCacheProvider);
            }
            // ** MonitorExit[var6_3] (shouldn't be in output)
            return networkCache2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static NetworkFetcher networkFetcher(Context context) {
        NetworkFetcher networkFetcher = L.networkFetcher;
        if (networkFetcher != null) {
            return networkFetcher;
        }
        Class<NetworkFetcher> class_ = NetworkFetcher.class;
        synchronized (NetworkFetcher.class) {
            NetworkFetcher networkFetcher2 = L.networkFetcher;
            if (networkFetcher2 == null) {
                NetworkCache networkCache = L.networkCache(context);
                LottieNetworkFetcher lottieNetworkFetcher = fetcher;
                if (lottieNetworkFetcher == null) {
                    lottieNetworkFetcher = new DefaultLottieNetworkFetcher();
                }
                L.networkFetcher = networkFetcher2 = new NetworkFetcher(networkCache, lottieNetworkFetcher);
            }
            // ** MonitorExit[var6_2] (shouldn't be in output)
            return networkFetcher2;
        }
    }

    public static void setCacheProvider(LottieNetworkCacheProvider lottieNetworkCacheProvider) {
        cacheProvider = lottieNetworkCacheProvider;
    }

    public static void setFetcher(LottieNetworkFetcher lottieNetworkFetcher) {
        fetcher = lottieNetworkFetcher;
    }

    public static void setTraceEnabled(boolean bl) {
        if (traceEnabled == bl) {
            return;
        }
        traceEnabled = bl;
        if (bl) {
            sections = new String[20];
            startTimeNs = new long[20];
        }
    }
}

