/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.Callable
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieCompositionFactory;
import com.airbnb.lottie.parser.moshi.JsonReader;
import java.util.concurrent.Callable;

public final class LottieCompositionFactory$$ExternalSyntheticLambda6
implements Callable {
    public final /* synthetic */ JsonReader f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ LottieCompositionFactory$$ExternalSyntheticLambda6(JsonReader jsonReader, String string2) {
        this.f$0 = jsonReader;
        this.f$1 = string2;
    }

    public final Object call() {
        return LottieCompositionFactory.lambda$fromJsonReader$6(this.f$0, this.f$1);
    }
}

