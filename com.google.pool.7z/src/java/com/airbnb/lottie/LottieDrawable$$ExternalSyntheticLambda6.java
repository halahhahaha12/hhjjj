/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;

public final class LottieDrawable$$ExternalSyntheticLambda6
implements LottieDrawable.LazyCompositionTask {
    public final /* synthetic */ LottieDrawable f$0;

    public /* synthetic */ LottieDrawable$$ExternalSyntheticLambda6(LottieDrawable lottieDrawable) {
        this.f$0 = lottieDrawable;
    }

    @Override
    public final void run(LottieComposition lottieComposition) {
        this.f$0.lambda$resumeAnimation$1$com-airbnb-lottie-LottieDrawable(lottieComposition);
    }
}

