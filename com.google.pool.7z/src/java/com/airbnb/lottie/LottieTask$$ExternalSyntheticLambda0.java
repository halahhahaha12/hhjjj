/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieTask;

public final class LottieTask$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ LottieTask f$0;

    public /* synthetic */ LottieTask$$ExternalSyntheticLambda0(LottieTask lottieTask) {
        this.f$0 = lottieTask;
    }

    public final void run() {
        this.f$0.lambda$notifyListeners$0$com-airbnb-lottie-LottieTask();
    }
}

