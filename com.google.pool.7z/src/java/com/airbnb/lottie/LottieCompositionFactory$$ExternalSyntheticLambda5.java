/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieCompositionFactory;
import java.util.concurrent.Callable;

public final class LottieCompositionFactory$$ExternalSyntheticLambda5
implements Callable {
    public final /* synthetic */ LottieComposition f$0;

    public /* synthetic */ LottieCompositionFactory$$ExternalSyntheticLambda5(LottieComposition lottieComposition) {
        this.f$0 = lottieComposition;
    }

    public final Object call() {
        return LottieCompositionFactory.lambda$cache$8(this.f$0);
    }
}

