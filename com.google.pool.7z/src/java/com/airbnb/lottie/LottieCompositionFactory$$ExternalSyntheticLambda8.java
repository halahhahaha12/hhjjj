/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.Callable
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieCompositionFactory;
import java.util.concurrent.Callable;

public final class LottieCompositionFactory$$ExternalSyntheticLambda8
implements Callable {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ LottieCompositionFactory$$ExternalSyntheticLambda8(String string2, String string3) {
        this.f$0 = string2;
        this.f$1 = string3;
    }

    public final Object call() {
        return LottieCompositionFactory.lambda$fromJsonString$5(this.f$0, this.f$1);
    }
}

