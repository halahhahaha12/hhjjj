/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie.model;

public class DocumentData {
    public float baselineShift;
    public int color;
    public String fontName;
    public Justification justification;
    public float lineHeight;
    public float size;
    public int strokeColor;
    public boolean strokeOverFill;
    public float strokeWidth;
    public String text;
    public int tracking;

    public DocumentData() {
    }

    public DocumentData(String string2, String string3, float f, Justification justification, int n, float f2, float f3, int n2, int n3, float f4, boolean bl) {
        this.set(string2, string3, f, justification, n, f2, f3, n2, n3, f4, bl);
    }

    public int hashCode() {
        int n = 31 * (31 * (int)((float)(31 * (31 * this.text.hashCode() + this.fontName.hashCode())) + this.size) + this.justification.ordinal()) + this.tracking;
        long l = Float.floatToRawIntBits((float)this.lineHeight);
        return 31 * (n * 31 + (int)(l ^ l >>> 32)) + this.color;
    }

    public void set(String string2, String string3, float f, Justification justification, int n, float f2, float f3, int n2, int n3, float f4, boolean bl) {
        this.text = string2;
        this.fontName = string3;
        this.size = f;
        this.justification = justification;
        this.tracking = n;
        this.lineHeight = f2;
        this.baselineShift = f3;
        this.color = n2;
        this.strokeColor = n3;
        this.strokeWidth = f4;
        this.strokeOverFill = bl;
    }

    public static final class Justification
    extends Enum<Justification> {
        private static final /* synthetic */ Justification[] $VALUES;
        public static final /* enum */ Justification CENTER;
        public static final /* enum */ Justification LEFT_ALIGN;
        public static final /* enum */ Justification RIGHT_ALIGN;

        static {
            Justification justification;
            Justification justification2;
            Justification justification3;
            LEFT_ALIGN = justification3 = new Justification();
            RIGHT_ALIGN = justification = new Justification();
            CENTER = justification2 = new Justification();
            $VALUES = new Justification[]{justification3, justification, justification2};
        }

        public static Justification valueOf(String string2) {
            return (Justification)Enum.valueOf(Justification.class, (String)string2);
        }

        public static Justification[] values() {
            return (Justification[])$VALUES.clone();
        }
    }

}

