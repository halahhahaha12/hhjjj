/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.model.animatable.AnimatableFloatValue
 *  java.lang.Object
 */
package com.airbnb.lottie.model.content;

import com.airbnb.lottie.model.animatable.AnimatableFloatValue;

public class BlurEffect {
    final AnimatableFloatValue blurriness;

    public BlurEffect(AnimatableFloatValue animatableFloatValue) {
        this.blurriness = animatableFloatValue;
    }

    public AnimatableFloatValue getBlurriness() {
        return this.blurriness;
    }
}

