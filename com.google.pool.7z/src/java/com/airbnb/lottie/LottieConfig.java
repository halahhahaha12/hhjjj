/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.LottieConfig$Builder$1
 *  com.airbnb.lottie.LottieConfig$Builder$2
 *  java.io.File
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieConfig;
import com.airbnb.lottie.network.LottieNetworkCacheProvider;
import com.airbnb.lottie.network.LottieNetworkFetcher;
import java.io.File;

public class LottieConfig {
    final LottieNetworkCacheProvider cacheProvider;
    final boolean enableSystraceMarkers;
    final LottieNetworkFetcher networkFetcher;

    private LottieConfig(LottieNetworkFetcher lottieNetworkFetcher, LottieNetworkCacheProvider lottieNetworkCacheProvider, boolean bl) {
        this.networkFetcher = lottieNetworkFetcher;
        this.cacheProvider = lottieNetworkCacheProvider;
        this.enableSystraceMarkers = bl;
    }

    public static final class Builder {
        private LottieNetworkCacheProvider cacheProvider;
        private boolean enableSystraceMarkers = false;
        private LottieNetworkFetcher networkFetcher;

        public LottieConfig build() {
            return new LottieConfig(this.networkFetcher, this.cacheProvider, this.enableSystraceMarkers);
        }

        public Builder setEnableSystraceMarkers(boolean bl) {
            this.enableSystraceMarkers = bl;
            return this;
        }

        public Builder setNetworkCacheDir(File file) {
            if (this.cacheProvider == null) {
                this.cacheProvider = new 1(this, file);
                return this;
            }
            throw new IllegalStateException("There is already a cache provider!");
        }

        public Builder setNetworkCacheProvider(LottieNetworkCacheProvider lottieNetworkCacheProvider) {
            if (this.cacheProvider == null) {
                this.cacheProvider = new 2(this, lottieNetworkCacheProvider);
                return this;
            }
            throw new IllegalStateException("There is already a cache provider!");
        }

        public Builder setNetworkFetcher(LottieNetworkFetcher lottieNetworkFetcher) {
            this.networkFetcher = lottieNetworkFetcher;
            return this;
        }
    }

}

