/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.Callable
 *  org.json.JSONObject
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieCompositionFactory;
import java.util.concurrent.Callable;
import org.json.JSONObject;

public final class LottieCompositionFactory$$ExternalSyntheticLambda1
implements Callable {
    public final /* synthetic */ JSONObject f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ LottieCompositionFactory$$ExternalSyntheticLambda1(JSONObject jSONObject, String string2) {
        this.f$0 = jSONObject;
        this.f$1 = string2;
    }

    public final Object call() {
        return LottieCompositionFactory.lambda$fromJson$4(this.f$0, this.f$1);
    }
}

