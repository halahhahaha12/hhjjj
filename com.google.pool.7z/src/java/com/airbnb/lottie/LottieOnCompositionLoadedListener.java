/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieComposition;

public interface LottieOnCompositionLoadedListener {
    public void onCompositionLoaded(LottieComposition var1);
}

