/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;

public final class LottieDrawable$$ExternalSyntheticLambda8
implements LottieDrawable.LazyCompositionTask {
    public final /* synthetic */ LottieDrawable f$0;
    public final /* synthetic */ float f$1;

    public /* synthetic */ LottieDrawable$$ExternalSyntheticLambda8(LottieDrawable lottieDrawable, float f) {
        this.f$0 = lottieDrawable;
        this.f$1 = f;
    }

    @Override
    public final void run(LottieComposition lottieComposition) {
        this.f$0.lambda$setMinProgress$3$com-airbnb-lottie-LottieDrawable(this.f$1, lottieComposition);
    }
}

