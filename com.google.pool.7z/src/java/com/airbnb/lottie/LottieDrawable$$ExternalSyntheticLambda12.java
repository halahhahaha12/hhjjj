/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;

public final class LottieDrawable$$ExternalSyntheticLambda12
implements LottieDrawable.LazyCompositionTask {
    public final /* synthetic */ LottieDrawable f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ LottieDrawable$$ExternalSyntheticLambda12(LottieDrawable lottieDrawable, int n) {
        this.f$0 = lottieDrawable;
        this.f$1 = n;
    }

    @Override
    public final void run(LottieComposition lottieComposition) {
        this.f$0.lambda$setMaxFrame$4$com-airbnb-lottie-LottieDrawable(this.f$1, lottieComposition);
    }
}

