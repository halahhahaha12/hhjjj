/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.lottie.LottieAnimationView
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieResult;
import java.util.concurrent.Callable;

public final class LottieAnimationView$$ExternalSyntheticLambda2
implements Callable {
    public final /* synthetic */ LottieAnimationView f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ LottieAnimationView$$ExternalSyntheticLambda2(LottieAnimationView lottieAnimationView, int n) {
        this.f$0 = lottieAnimationView;
        this.f$1 = n;
    }

    public final Object call() {
        return this.f$0.lambda$fromRawRes$1$com-airbnb-lottie-LottieAnimationView(this.f$1);
    }
}

