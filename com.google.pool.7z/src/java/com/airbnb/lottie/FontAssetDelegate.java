/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Typeface
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie;

import android.graphics.Typeface;

public class FontAssetDelegate {
    public Typeface fetchFont(String string2) {
        return null;
    }

    public String getFontPath(String string2) {
        return null;
    }
}

