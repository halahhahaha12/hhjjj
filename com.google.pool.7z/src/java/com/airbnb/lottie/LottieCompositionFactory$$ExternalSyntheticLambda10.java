/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.Callable
 *  java.util.zip.ZipInputStream
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieCompositionFactory;
import java.util.concurrent.Callable;
import java.util.zip.ZipInputStream;

public final class LottieCompositionFactory$$ExternalSyntheticLambda10
implements Callable {
    public final /* synthetic */ ZipInputStream f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ LottieCompositionFactory$$ExternalSyntheticLambda10(ZipInputStream zipInputStream, String string2) {
        this.f$0 = zipInputStream;
        this.f$1 = string2;
    }

    public final Object call() {
        return LottieCompositionFactory.lambda$fromZipStream$7(this.f$0, this.f$1);
    }
}

