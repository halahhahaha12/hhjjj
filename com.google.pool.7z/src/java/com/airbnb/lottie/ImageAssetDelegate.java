/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 */
package com.airbnb.lottie;

import android.graphics.Bitmap;
import com.airbnb.lottie.LottieImageAsset;

public interface ImageAssetDelegate {
    public Bitmap fetchBitmap(LottieImageAsset var1);
}

