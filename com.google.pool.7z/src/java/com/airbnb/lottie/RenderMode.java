/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie;

public final class RenderMode
extends Enum<RenderMode> {
    private static final /* synthetic */ RenderMode[] $VALUES;
    public static final /* enum */ RenderMode AUTOMATIC;
    public static final /* enum */ RenderMode HARDWARE;
    public static final /* enum */ RenderMode SOFTWARE;

    static {
        RenderMode renderMode;
        RenderMode renderMode2;
        RenderMode renderMode3;
        AUTOMATIC = renderMode2 = new RenderMode();
        HARDWARE = renderMode3 = new RenderMode();
        SOFTWARE = renderMode = new RenderMode();
        $VALUES = new RenderMode[]{renderMode2, renderMode3, renderMode};
    }

    public static RenderMode valueOf(String string2) {
        return (RenderMode)Enum.valueOf(RenderMode.class, (String)string2);
    }

    public static RenderMode[] values() {
        return (RenderMode[])$VALUES.clone();
    }

    public boolean useSoftwareRendering(int n, boolean bl, int n2) {
        int n3 = 1.$SwitchMap$com$airbnb$lottie$RenderMode[this.ordinal()];
        if (n3 != 1) {
            if (n3 != 2) {
                if (bl && n < 28) {
                    return true;
                }
                if (n2 > 4) {
                    return true;
                }
                boolean bl2 = false;
                if (n <= 25) {
                    bl2 = true;
                }
                return bl2;
            }
            return true;
        }
        return false;
    }

}

