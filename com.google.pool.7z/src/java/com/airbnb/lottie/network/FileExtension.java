/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.airbnb.lottie.network;

public final class FileExtension
extends Enum<FileExtension> {
    private static final /* synthetic */ FileExtension[] $VALUES;
    public static final /* enum */ FileExtension JSON;
    public static final /* enum */ FileExtension ZIP;
    public final String extension;

    static {
        FileExtension fileExtension;
        FileExtension fileExtension2;
        JSON = fileExtension = new FileExtension(".json");
        ZIP = fileExtension2 = new FileExtension(".zip");
        $VALUES = new FileExtension[]{fileExtension, fileExtension2};
    }

    private FileExtension(String string3) {
        this.extension = string3;
    }

    public static FileExtension valueOf(String string2) {
        return (FileExtension)Enum.valueOf(FileExtension.class, (String)string2);
    }

    public static FileExtension[] values() {
        return (FileExtension[])$VALUES.clone();
    }

    public String tempExtension() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(".temp");
        stringBuilder.append(this.extension);
        return stringBuilder.toString();
    }

    public String toString() {
        return this.extension;
    }
}

