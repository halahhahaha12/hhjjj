/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.zip.ZipInputStream
 */
package com.airbnb.lottie.network;

import android.util.Pair;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieCompositionFactory;
import com.airbnb.lottie.LottieResult;
import com.airbnb.lottie.network.FileExtension;
import com.airbnb.lottie.network.LottieFetchResult;
import com.airbnb.lottie.network.LottieNetworkFetcher;
import com.airbnb.lottie.network.NetworkCache;
import com.airbnb.lottie.utils.Logger;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipInputStream;

public class NetworkFetcher {
    private final LottieNetworkFetcher fetcher;
    private final NetworkCache networkCache;

    public NetworkFetcher(NetworkCache networkCache, LottieNetworkFetcher lottieNetworkFetcher) {
        this.networkCache = networkCache;
        this.fetcher = lottieNetworkFetcher;
    }

    private LottieComposition fetchFromCache(String string2, String string3) {
        if (string3 == null) {
            return null;
        }
        Pair<FileExtension, InputStream> pair = this.networkCache.fetch(string2);
        if (pair == null) {
            return null;
        }
        FileExtension fileExtension = (FileExtension)((Object)pair.first);
        InputStream inputStream = (InputStream)pair.second;
        LottieResult<LottieComposition> lottieResult = fileExtension == FileExtension.ZIP ? LottieCompositionFactory.fromZipStreamSync(new ZipInputStream(inputStream), string2) : LottieCompositionFactory.fromJsonInputStreamSync(inputStream, string2);
        if (lottieResult.getValue() != null) {
            return lottieResult.getValue();
        }
        return null;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private LottieResult<LottieComposition> fetchFromNetwork(String string2, String string3) {
        Throwable throwable2222;
        LottieFetchResult lottieFetchResult;
        block14 : {
            block13 : {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Fetching ");
                stringBuilder.append(string2);
                Logger.debug(stringBuilder.toString());
                lottieFetchResult = null;
                lottieFetchResult = this.fetcher.fetchSync(string2);
                if (!lottieFetchResult.isSuccessful()) break block13;
                LottieResult<LottieComposition> lottieResult = this.fromInputStream(string2, lottieFetchResult.bodyByteStream(), lottieFetchResult.contentType(), string3);
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Completed fetch from network. Success: ");
                boolean bl = lottieResult.getValue() != null;
                stringBuilder2.append(bl);
                Logger.debug(stringBuilder2.toString());
                if (lottieFetchResult == null) return lottieResult;
                try {
                    lottieFetchResult.close();
                    return lottieResult;
                }
                catch (IOException iOException) {
                    Logger.warning("LottieFetchResult close failed ", iOException);
                }
                return lottieResult;
            }
            LottieResult<LottieComposition> lottieResult = new LottieResult<LottieComposition>(new IllegalArgumentException(lottieFetchResult.error()));
            if (lottieFetchResult == null) return lottieResult;
            try {
                lottieFetchResult.close();
                return lottieResult;
            }
            catch (IOException iOException) {
                Logger.warning("LottieFetchResult close failed ", iOException);
            }
            return lottieResult;
            {
                LottieResult<LottieComposition> lottieResult2;
                catch (Throwable throwable2222) {
                    break block14;
                }
                catch (Exception exception) {}
                {
                    lottieResult2 = new LottieResult<LottieComposition>(exception);
                    if (lottieFetchResult == null) return lottieResult2;
                }
                try {
                    lottieFetchResult.close();
                    return lottieResult2;
                }
                catch (IOException iOException) {
                    Logger.warning("LottieFetchResult close failed ", iOException);
                }
                return lottieResult2;
            }
        }
        if (lottieFetchResult == null) throw throwable2222;
        try {
            lottieFetchResult.close();
            throw throwable2222;
        }
        catch (IOException iOException) {
            Logger.warning("LottieFetchResult close failed ", iOException);
        }
        throw throwable2222;
    }

    private LottieResult<LottieComposition> fromInputStream(String string2, InputStream inputStream, String string3, String string4) throws IOException {
        LottieResult<LottieComposition> lottieResult;
        FileExtension fileExtension;
        if (string3 == null) {
            string3 = "application/json";
        }
        if (!(string3.contains((CharSequence)"application/zip") || string3.contains((CharSequence)"application/x-zip") || string3.contains((CharSequence)"application/x-zip-compressed") || string2.split("\\?")[0].endsWith(".lottie"))) {
            Logger.debug("Received json response.");
            fileExtension = FileExtension.JSON;
            lottieResult = this.fromJsonStream(string2, inputStream, string4);
        } else {
            Logger.debug("Handling zip response.");
            fileExtension = FileExtension.ZIP;
            lottieResult = this.fromZipStream(string2, inputStream, string4);
        }
        if (string4 != null && lottieResult.getValue() != null) {
            this.networkCache.renameTempFile(string2, fileExtension);
        }
        return lottieResult;
    }

    private LottieResult<LottieComposition> fromJsonStream(String string2, InputStream inputStream, String string3) throws IOException {
        if (string3 == null) {
            return LottieCompositionFactory.fromJsonInputStreamSync(inputStream, null);
        }
        return LottieCompositionFactory.fromJsonInputStreamSync((InputStream)new FileInputStream(this.networkCache.writeTempCacheFile(string2, inputStream, FileExtension.JSON).getAbsolutePath()), string2);
    }

    private LottieResult<LottieComposition> fromZipStream(String string2, InputStream inputStream, String string3) throws IOException {
        if (string3 == null) {
            return LottieCompositionFactory.fromZipStreamSync(new ZipInputStream(inputStream), null);
        }
        return LottieCompositionFactory.fromZipStreamSync(new ZipInputStream((InputStream)new FileInputStream(this.networkCache.writeTempCacheFile(string2, inputStream, FileExtension.ZIP))), string2);
    }

    public LottieResult<LottieComposition> fetchSync(String string2, String string3) {
        LottieComposition lottieComposition = this.fetchFromCache(string2, string3);
        if (lottieComposition != null) {
            return new LottieResult<LottieComposition>(lottieComposition);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Animation for ");
        stringBuilder.append(string2);
        stringBuilder.append(" not found in cache. Fetching from network.");
        Logger.debug(stringBuilder.toString());
        return this.fetchFromNetwork(string2, string3);
    }
}

