/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Comparator
 *  java.util.Iterator
 *  java.util.List
 */
package com.nostra13.universalimageloader.utils;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.memory.MemoryCache;
import com.nostra13.universalimageloader.core.assist.ImageSize;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public final class MemoryCacheUtils {
    private static final String URI_AND_SIZE_SEPARATOR = "_";
    private static final String WIDTH_AND_HEIGHT_SEPARATOR = "x";

    private MemoryCacheUtils() {
    }

    public static Comparator<String> createFuzzyKeyComparator() {
        return new Comparator<String>(){

            public int compare(String string2, String string3) {
                return string2.substring(0, string2.lastIndexOf(MemoryCacheUtils.URI_AND_SIZE_SEPARATOR)).compareTo(string3.substring(0, string3.lastIndexOf(MemoryCacheUtils.URI_AND_SIZE_SEPARATOR)));
            }
        };
    }

    public static List<String> findCacheKeysForImageUri(String string2, MemoryCache memoryCache) {
        ArrayList arrayList = new ArrayList();
        for (String string3 : memoryCache.keys()) {
            if (!string3.startsWith(string2)) continue;
            arrayList.add((Object)string3);
        }
        return arrayList;
    }

    public static List<Bitmap> findCachedBitmapsForImageUri(String string2, MemoryCache memoryCache) {
        ArrayList arrayList = new ArrayList();
        for (String string3 : memoryCache.keys()) {
            if (!string3.startsWith(string2)) continue;
            arrayList.add((Object)memoryCache.get(string3));
        }
        return arrayList;
    }

    public static String generateKey(String string2, ImageSize imageSize) {
        StringBuilder stringBuilder = new StringBuilder(string2);
        stringBuilder.append(URI_AND_SIZE_SEPARATOR);
        stringBuilder.append(imageSize.getWidth());
        stringBuilder.append(WIDTH_AND_HEIGHT_SEPARATOR);
        stringBuilder.append(imageSize.getHeight());
        return stringBuilder.toString();
    }

    public static void removeFromCache(String string2, MemoryCache memoryCache) {
        ArrayList arrayList = new ArrayList();
        for (String string3 : memoryCache.keys()) {
            if (!string3.startsWith(string2)) continue;
            arrayList.add((Object)string3);
        }
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            memoryCache.remove((String)iterator.next());
        }
    }

}

