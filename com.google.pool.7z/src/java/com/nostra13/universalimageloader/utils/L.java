/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.nostra13.universalimageloader.utils;

import android.util.Log;
import com.nostra13.universalimageloader.core.ImageLoader;

public final class L {
    private static final String LOG_FORMAT = "%1$s\n%2$s";
    private static volatile boolean writeDebugLogs = false;
    private static volatile boolean writeLogs = true;

    private L() {
    }

    public static /* varargs */ void d(String string2, Object ... arrobject) {
        if (writeDebugLogs) {
            L.log(3, null, string2, arrobject);
        }
    }

    @Deprecated
    public static void disableLogging() {
        L.writeLogs(false);
    }

    public static /* varargs */ void e(String string2, Object ... arrobject) {
        L.log(6, null, string2, arrobject);
    }

    public static void e(Throwable throwable) {
        L.log(6, throwable, null, new Object[0]);
    }

    public static /* varargs */ void e(Throwable throwable, String string2, Object ... arrobject) {
        L.log(6, throwable, string2, arrobject);
    }

    @Deprecated
    public static void enableLogging() {
        L.writeLogs(true);
    }

    public static /* varargs */ void i(String string2, Object ... arrobject) {
        L.log(4, null, string2, arrobject);
    }

    private static /* varargs */ void log(int n, Throwable throwable, String string2, Object ... arrobject) {
        if (!writeLogs) {
            return;
        }
        if (arrobject.length > 0) {
            string2 = String.format((String)string2, (Object[])arrobject);
        }
        if (throwable != null) {
            if (string2 == null) {
                string2 = throwable.getMessage();
            }
            string2 = String.format((String)LOG_FORMAT, (Object[])new Object[]{string2, Log.getStackTraceString((Throwable)throwable)});
        }
        Log.println((int)n, (String)ImageLoader.TAG, (String)string2);
    }

    public static /* varargs */ void w(String string2, Object ... arrobject) {
        L.log(5, null, string2, arrobject);
    }

    public static void writeDebugLogs(boolean bl) {
        writeDebugLogs = bl;
    }

    public static void writeLogs(boolean bl) {
        writeLogs = bl;
    }
}

