/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.opengl.GLES10
 *  java.lang.Math
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 */
package com.nostra13.universalimageloader.utils;

import android.opengl.GLES10;
import com.nostra13.universalimageloader.core.assist.ImageSize;
import com.nostra13.universalimageloader.core.assist.ViewScaleType;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;

public final class ImageSizeUtils {
    private static final int DEFAULT_MAX_BITMAP_DIMENSION = 2048;
    private static ImageSize maxBitmapSize;

    static {
        int[] arrn = new int[1];
        GLES10.glGetIntegerv((int)3379, (int[])arrn, (int)0);
        int n = Math.max((int)arrn[0], (int)2048);
        maxBitmapSize = new ImageSize(n, n);
    }

    private ImageSizeUtils() {
    }

    public static int computeImageSampleSize(ImageSize imageSize, ImageSize imageSize2, ViewScaleType viewScaleType, boolean bl) {
        int n;
        int n2;
        int n3 = imageSize.getWidth();
        int n4 = imageSize.getHeight();
        int n5 = imageSize2.getWidth();
        int n6 = imageSize2.getHeight();
        int n7 = 1.$SwitchMap$com$nostra13$universalimageloader$core$assist$ViewScaleType[viewScaleType.ordinal()];
        if (n7 != (n2 = 1)) {
            if (n7 != 2) {
                n = 1;
            } else if (bl) {
                int n8 = n3 / 2;
                int n9 = n4 / 2;
                n = 1;
                while (n8 / n > n5 && n9 / n > n6) {
                    n *= 2;
                }
            } else {
                n = Math.min((int)(n3 / n5), (int)(n4 / n6));
            }
        } else if (bl) {
            int n10 = n3 / 2;
            int n11 = n4 / 2;
            n = 1;
            while (n10 / n > n5 || n11 / n > n6) {
                n *= 2;
            }
        } else {
            n = Math.max((int)(n3 / n5), (int)(n4 / n6));
        }
        if (n >= n2) {
            n2 = n;
        }
        return ImageSizeUtils.considerMaxTextureSize(n3, n4, n2, bl);
    }

    public static float computeImageScale(ImageSize imageSize, ImageSize imageSize2, ViewScaleType viewScaleType, boolean bl) {
        int n = imageSize.getWidth();
        int n2 = imageSize.getHeight();
        int n3 = imageSize2.getWidth();
        int n4 = imageSize2.getHeight();
        float f = n;
        float f2 = f / (float)n3;
        float f3 = n2;
        float f4 = f3 / (float)n4;
        if (viewScaleType == ViewScaleType.FIT_INSIDE && f2 >= f4 || viewScaleType == ViewScaleType.CROP && f2 < f4) {
            n4 = (int)(f3 / f2);
        } else {
            n3 = (int)(f / f4);
        }
        float f5 = 1.0f;
        if (!bl && n3 < n && n4 < n2 || bl && n3 != n && n4 != n2) {
            f5 = (float)n3 / f;
        }
        return f5;
    }

    public static int computeMinImageSampleSize(ImageSize imageSize) {
        int n = imageSize.getWidth();
        int n2 = imageSize.getHeight();
        int n3 = maxBitmapSize.getWidth();
        int n4 = maxBitmapSize.getHeight();
        return Math.max((int)((int)Math.ceil((double)((float)n / (float)n3))), (int)((int)Math.ceil((double)((float)n2 / (float)n4))));
    }

    private static int considerMaxTextureSize(int n, int n2, int n3, boolean bl) {
        int n4 = maxBitmapSize.getWidth();
        int n5 = maxBitmapSize.getHeight();
        while (n / n3 > n4 || n2 / n3 > n5) {
            if (bl) {
                n3 *= 2;
                continue;
            }
            ++n3;
        }
        return n3;
    }

    public static ImageSize defineTargetSizeForView(ImageAware imageAware, ImageSize imageSize) {
        int n;
        int n2 = imageAware.getWidth();
        if (n2 <= 0) {
            n2 = imageSize.getWidth();
        }
        if ((n = imageAware.getHeight()) <= 0) {
            n = imageSize.getHeight();
        }
        return new ImageSize(n2, n);
    }

}

