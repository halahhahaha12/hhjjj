/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.utils;

import com.nostra13.universalimageloader.cache.disc.DiskCache;
import java.io.File;

public final class DiskCacheUtils {
    private DiskCacheUtils() {
    }

    public static File findInCache(String string2, DiskCache diskCache) {
        File file = diskCache.get(string2);
        if (file != null && file.exists()) {
            return file;
        }
        return null;
    }

    public static boolean removeFromCache(String string2, DiskCache diskCache) {
        File file = diskCache.get(string2);
        return file != null && file.exists() && file.delete();
    }
}

