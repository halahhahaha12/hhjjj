/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Map
 */
package com.nostra13.universalimageloader.cache.disc.impl;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.disc.impl.BaseDiskCache;
import com.nostra13.universalimageloader.cache.disc.naming.FileNameGenerator;
import com.nostra13.universalimageloader.core.DefaultConfigurationFactory;
import com.nostra13.universalimageloader.utils.IoUtils;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class LimitedAgeDiskCache
extends BaseDiskCache {
    private final Map<File, Long> loadingDates = Collections.synchronizedMap((Map)new HashMap());
    private final long maxFileAge;

    public LimitedAgeDiskCache(File file, long l) {
        this(file, null, DefaultConfigurationFactory.createFileNameGenerator(), l);
    }

    public LimitedAgeDiskCache(File file, File file2, long l) {
        this(file, file2, DefaultConfigurationFactory.createFileNameGenerator(), l);
    }

    public LimitedAgeDiskCache(File file, File file2, FileNameGenerator fileNameGenerator, long l) {
        super(file, file2, fileNameGenerator);
        this.maxFileAge = l * 1000L;
    }

    private void rememberUsage(String string2) {
        File file = this.getFile(string2);
        long l = System.currentTimeMillis();
        file.setLastModified(l);
        this.loadingDates.put((Object)file, (Object)l);
    }

    @Override
    public void clear() {
        super.clear();
        this.loadingDates.clear();
    }

    @Override
    public File get(String string2) {
        File file = super.get(string2);
        if (file != null && file.exists()) {
            boolean bl;
            Long l = (Long)this.loadingDates.get((Object)file);
            if (l == null) {
                l = file.lastModified();
                bl = false;
            } else {
                bl = true;
            }
            if (System.currentTimeMillis() - l > this.maxFileAge) {
                file.delete();
                this.loadingDates.remove((Object)file);
                return file;
            }
            if (!bl) {
                this.loadingDates.put((Object)file, (Object)l);
            }
        }
        return file;
    }

    @Override
    public boolean remove(String string2) {
        this.loadingDates.remove((Object)this.getFile(string2));
        return super.remove(string2);
    }

    @Override
    public boolean save(String string2, Bitmap bitmap) throws IOException {
        boolean bl = super.save(string2, bitmap);
        this.rememberUsage(string2);
        return bl;
    }

    @Override
    public boolean save(String string2, InputStream inputStream, IoUtils.CopyListener copyListener) throws IOException {
        boolean bl = super.save(string2, inputStream, copyListener);
        this.rememberUsage(string2);
        return bl;
    }
}

