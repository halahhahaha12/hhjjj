/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  java.io.BufferedOutputStream
 *  java.io.Closeable
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.nostra13.universalimageloader.cache.disc.impl.ext;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.disc.DiskCache;
import com.nostra13.universalimageloader.cache.disc.impl.ext.DiskLruCache;
import com.nostra13.universalimageloader.cache.disc.naming.FileNameGenerator;
import com.nostra13.universalimageloader.utils.IoUtils;
import com.nostra13.universalimageloader.utils.L;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class LruDiskCache
implements DiskCache {
    public static final int DEFAULT_BUFFER_SIZE = 32768;
    public static final Bitmap.CompressFormat DEFAULT_COMPRESS_FORMAT = Bitmap.CompressFormat.PNG;
    public static final int DEFAULT_COMPRESS_QUALITY = 100;
    private static final String ERROR_ARG_NEGATIVE = " argument must be positive number";
    private static final String ERROR_ARG_NULL = " argument must be not null";
    protected int bufferSize = 32768;
    protected DiskLruCache cache;
    protected Bitmap.CompressFormat compressFormat = DEFAULT_COMPRESS_FORMAT;
    protected int compressQuality = 100;
    protected final FileNameGenerator fileNameGenerator;
    private File reserveCacheDir;

    public LruDiskCache(File file, FileNameGenerator fileNameGenerator, long l) throws IOException {
        this(file, null, fileNameGenerator, l, 0);
    }

    public LruDiskCache(File file, File file2, FileNameGenerator fileNameGenerator, long l, int n) throws IOException {
        if (file != null) {
            if (l >= 0L) {
                if (n >= 0) {
                    if (fileNameGenerator != null) {
                        if (l == 0L) {
                            l = Long.MAX_VALUE;
                        }
                        long l2 = l;
                        int n2 = n == 0 ? Integer.MAX_VALUE : n;
                        this.reserveCacheDir = file2;
                        this.fileNameGenerator = fileNameGenerator;
                        this.initCache(file, file2, l2, n2);
                        return;
                    }
                    throw new IllegalArgumentException("fileNameGenerator argument must be not null");
                }
                throw new IllegalArgumentException("cacheMaxFileCount argument must be positive number");
            }
            throw new IllegalArgumentException("cacheMaxSize argument must be positive number");
        }
        throw new IllegalArgumentException("cacheDir argument must be not null");
    }

    private String getKey(String string2) {
        return this.fileNameGenerator.generate(string2);
    }

    private void initCache(File file, File file2, long l, int n) throws IOException {
        try {
            this.cache = DiskLruCache.open(file, 1, 1, l, n);
            return;
        }
        catch (IOException iOException) {
            L.e(iOException);
            if (file2 != null) {
                this.initCache(file2, null, l, n);
            }
            if (this.cache != null) {
                return;
            }
            throw iOException;
        }
    }

    @Override
    public void clear() {
        try {
            this.cache.delete();
        }
        catch (IOException iOException) {
            L.e(iOException);
        }
        try {
            this.initCache(this.cache.getDirectory(), this.reserveCacheDir, this.cache.getMaxSize(), this.cache.getMaxFileCount());
            return;
        }
        catch (IOException iOException) {
            L.e(iOException);
            return;
        }
    }

    @Override
    public void close() {
        try {
            this.cache.close();
        }
        catch (IOException iOException) {
            L.e(iOException);
        }
        this.cache = null;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public File get(String string2) {
        Throwable throwable;
        DiskLruCache.Snapshot snapshot;
        block10 : {
            block9 : {
                File file;
                block8 : {
                    block7 : {
                        snapshot = this.cache.get(this.getKey(string2));
                        if (snapshot != null) break block7;
                        file = null;
                        break block8;
                    }
                    try {
                        file = snapshot.getFile(0);
                    }
                    catch (IOException iOException) {
                        break block9;
                    }
                }
                if (snapshot == null) return file;
                snapshot.close();
                return file;
                catch (Throwable throwable2) {
                    throwable = throwable2;
                    snapshot = null;
                    break block10;
                }
                catch (IOException iOException) {
                    snapshot = null;
                }
            }
            try {
                void var2_6;
                L.e((Throwable)var2_6);
                if (snapshot == null) return null;
            }
            catch (Throwable throwable3) {
                // empty catch block
            }
            snapshot.close();
            return null;
        }
        if (snapshot == null) throw throwable;
        snapshot.close();
        throw throwable;
    }

    @Override
    public File getDirectory() {
        return this.cache.getDirectory();
    }

    @Override
    public boolean remove(String string2) {
        try {
            boolean bl = this.cache.remove(this.getKey(string2));
            return bl;
        }
        catch (IOException iOException) {
            L.e(iOException);
            return false;
        }
    }

    @Override
    public boolean save(String string2, Bitmap bitmap) throws IOException {
        BufferedOutputStream bufferedOutputStream;
        DiskLruCache.Editor editor;
        boolean bl;
        block4 : {
            editor = this.cache.edit(this.getKey(string2));
            if (editor == null) {
                return false;
            }
            bufferedOutputStream = new BufferedOutputStream(editor.newOutputStream(0), this.bufferSize);
            bl = bitmap.compress(this.compressFormat, this.compressQuality, (OutputStream)bufferedOutputStream);
            if (!bl) break block4;
            editor.commit();
            return bl;
        }
        editor.abort();
        return bl;
        finally {
            IoUtils.closeSilently((Closeable)bufferedOutputStream);
        }
    }

    @Override
    public boolean save(String string2, InputStream inputStream, IoUtils.CopyListener copyListener) throws IOException {
        boolean bl;
        DiskLruCache.Editor editor = this.cache.edit(this.getKey(string2));
        if (editor == null) {
            return false;
        }
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(editor.newOutputStream(0), this.bufferSize);
        try {
            bl = IoUtils.copyStream(inputStream, (OutputStream)bufferedOutputStream, copyListener, this.bufferSize);
        }
        catch (Throwable throwable) {
            IoUtils.closeSilently((Closeable)bufferedOutputStream);
            editor.abort();
            throw throwable;
        }
        IoUtils.closeSilently((Closeable)bufferedOutputStream);
        if (bl) {
            editor.commit();
            return bl;
        }
        editor.abort();
        return bl;
    }

    public void setBufferSize(int n) {
        this.bufferSize = n;
    }

    public void setCompressFormat(Bitmap.CompressFormat compressFormat) {
        this.compressFormat = compressFormat;
    }

    public void setCompressQuality(int n) {
        this.compressQuality = n;
    }
}

