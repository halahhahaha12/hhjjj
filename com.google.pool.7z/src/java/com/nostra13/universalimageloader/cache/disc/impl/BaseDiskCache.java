/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  java.io.BufferedOutputStream
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.nostra13.universalimageloader.cache.disc.impl;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.disc.DiskCache;
import com.nostra13.universalimageloader.cache.disc.naming.FileNameGenerator;
import com.nostra13.universalimageloader.core.DefaultConfigurationFactory;
import com.nostra13.universalimageloader.utils.IoUtils;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract class BaseDiskCache
implements DiskCache {
    public static final int DEFAULT_BUFFER_SIZE = 32768;
    public static final Bitmap.CompressFormat DEFAULT_COMPRESS_FORMAT = Bitmap.CompressFormat.PNG;
    public static final int DEFAULT_COMPRESS_QUALITY = 100;
    private static final String ERROR_ARG_NULL = " argument must be not null";
    private static final String TEMP_IMAGE_POSTFIX = ".tmp";
    protected int bufferSize = 32768;
    protected final File cacheDir;
    protected Bitmap.CompressFormat compressFormat = DEFAULT_COMPRESS_FORMAT;
    protected int compressQuality = 100;
    protected final FileNameGenerator fileNameGenerator;
    protected final File reserveCacheDir;

    public BaseDiskCache(File file) {
        this(file, null);
    }

    public BaseDiskCache(File file, File file2) {
        this(file, file2, DefaultConfigurationFactory.createFileNameGenerator());
    }

    public BaseDiskCache(File file, File file2, FileNameGenerator fileNameGenerator) {
        if (file != null) {
            if (fileNameGenerator != null) {
                this.cacheDir = file;
                this.reserveCacheDir = file2;
                this.fileNameGenerator = fileNameGenerator;
                return;
            }
            throw new IllegalArgumentException("fileNameGenerator argument must be not null");
        }
        throw new IllegalArgumentException("cacheDir argument must be not null");
    }

    @Override
    public void clear() {
        File[] arrfile = this.cacheDir.listFiles();
        if (arrfile != null) {
            int n = arrfile.length;
            for (int i = 0; i < n; ++i) {
                arrfile[i].delete();
            }
        }
    }

    @Override
    public void close() {
    }

    @Override
    public File get(String string2) {
        return this.getFile(string2);
    }

    @Override
    public File getDirectory() {
        return this.cacheDir;
    }

    protected File getFile(String string2) {
        File file;
        String string3 = this.fileNameGenerator.generate(string2);
        File file2 = this.cacheDir;
        if (!file2.exists() && !this.cacheDir.mkdirs() && (file = this.reserveCacheDir) != null && (file.exists() || this.reserveCacheDir.mkdirs())) {
            file2 = this.reserveCacheDir;
        }
        return new File(file2, string3);
    }

    @Override
    public boolean remove(String string2) {
        return this.getFile(string2).delete();
    }

    @Override
    public boolean save(String string2, Bitmap bitmap) throws IOException {
        boolean bl;
        File file = this.getFile(string2);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(file.getAbsolutePath());
        stringBuilder.append(TEMP_IMAGE_POSTFIX);
        File file2 = new File(stringBuilder.toString());
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream((OutputStream)new FileOutputStream(file2), this.bufferSize);
        try {
            bl = bitmap.compress(this.compressFormat, this.compressQuality, (OutputStream)bufferedOutputStream);
        }
        catch (Throwable throwable) {
            IoUtils.closeSilently((Closeable)bufferedOutputStream);
            file2.delete();
            throw throwable;
        }
        IoUtils.closeSilently((Closeable)bufferedOutputStream);
        if (bl && !file2.renameTo(file)) {
            bl = false;
        }
        if (!bl) {
            file2.delete();
        }
        bitmap.recycle();
        return bl;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public boolean save(String string2, InputStream inputStream, IoUtils.CopyListener copyListener) throws IOException {
        File file;
        File file2;
        boolean bl;
        void var11_12;
        block7 : {
            file2 = this.getFile(string2);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(file2.getAbsolutePath());
            stringBuilder.append(TEMP_IMAGE_POSTFIX);
            file = new File(stringBuilder.toString());
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream((OutputStream)new FileOutputStream(file), this.bufferSize);
            bl = IoUtils.copyStream(inputStream, (OutputStream)bufferedOutputStream, copyListener, this.bufferSize);
            try {
                IoUtils.closeSilently((Closeable)bufferedOutputStream);
            }
            catch (Throwable throwable) {
                break block7;
            }
            boolean bl2 = bl && !file.renameTo(file2) ? false : bl;
            if (bl2) return bl2;
            file.delete();
            return bl2;
            catch (Throwable throwable) {
                try {
                    IoUtils.closeSilently((Closeable)bufferedOutputStream);
                    throw throwable;
                }
                catch (Throwable throwable2) {
                    bl = false;
                }
            }
        }
        boolean bl3 = bl && !file.renameTo(file2) ? false : bl;
        if (bl3) throw var11_12;
        file.delete();
        throw var11_12;
    }

    public void setBufferSize(int n) {
        this.bufferSize = n;
    }

    public void setCompressFormat(Bitmap.CompressFormat compressFormat) {
        this.compressFormat = compressFormat;
    }

    public void setCompressQuality(int n) {
        this.compressQuality = n;
    }
}

