/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.cache.disc.naming;

public interface FileNameGenerator {
    public String generate(String var1);
}

