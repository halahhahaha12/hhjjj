/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.math.BigInteger
 *  java.security.MessageDigest
 *  java.security.NoSuchAlgorithmException
 */
package com.nostra13.universalimageloader.cache.disc.naming;

import com.nostra13.universalimageloader.cache.disc.naming.FileNameGenerator;
import com.nostra13.universalimageloader.utils.L;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Md5FileNameGenerator
implements FileNameGenerator {
    private static final String HASH_ALGORITHM = "MD5";
    private static final int RADIX = 36;

    private byte[] getMD5(byte[] arrby) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance((String)HASH_ALGORITHM);
            messageDigest.update(arrby);
            byte[] arrby2 = messageDigest.digest();
            return arrby2;
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            L.e(noSuchAlgorithmException);
            return null;
        }
    }

    @Override
    public String generate(String string2) {
        return new BigInteger(this.getMD5(string2.getBytes())).abs().toString(36);
    }
}

