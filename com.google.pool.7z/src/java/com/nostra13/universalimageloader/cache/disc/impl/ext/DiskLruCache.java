/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedWriter
 *  java.io.Closeable
 *  java.io.EOFException
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.FilterOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.PrintStream
 *  java.io.Reader
 *  java.io.Writer
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.nio.charset.Charset
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.Callable
 *  java.util.concurrent.Future
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.nostra13.universalimageloader.cache.disc.impl.ext;

import com.nostra13.universalimageloader.cache.disc.impl.ext.StrictLineReader;
import com.nostra13.universalimageloader.cache.disc.impl.ext.Util;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class DiskLruCache
implements Closeable {
    static final long ANY_SEQUENCE_NUMBER = -1L;
    private static final String CLEAN = "CLEAN";
    private static final String DIRTY = "DIRTY";
    static final String JOURNAL_FILE = "journal";
    static final String JOURNAL_FILE_BACKUP = "journal.bkp";
    static final String JOURNAL_FILE_TEMP = "journal.tmp";
    static final Pattern LEGAL_KEY_PATTERN = Pattern.compile((String)"[a-z0-9_-]{1,64}");
    static final String MAGIC = "libcore.io.DiskLruCache";
    private static final OutputStream NULL_OUTPUT_STREAM = new OutputStream(){

        public void write(int n) throws IOException {
        }
    };
    private static final String READ = "READ";
    private static final String REMOVE = "REMOVE";
    static final String VERSION_1 = "1";
    private final int appVersion;
    private final Callable<Void> cleanupCallable;
    private final File directory;
    final ThreadPoolExecutor executorService;
    private int fileCount = 0;
    private final File journalFile;
    private final File journalFileBackup;
    private final File journalFileTmp;
    private Writer journalWriter;
    private final LinkedHashMap<String, Entry> lruEntries = new LinkedHashMap(0, 0.75f, true);
    private int maxFileCount;
    private long maxSize;
    private long nextSequenceNumber = 0L;
    private int redundantOpCount;
    private long size = 0L;
    private final int valueCount;

    private DiskLruCache(File file, int n, int n2, long l, int n3) {
        ThreadPoolExecutor threadPoolExecutor;
        this.executorService = threadPoolExecutor = new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, (BlockingQueue)new LinkedBlockingQueue());
        this.cleanupCallable = new Callable<Void>(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public Void call() throws Exception {
                DiskLruCache diskLruCache;
                DiskLruCache diskLruCache2 = diskLruCache = DiskLruCache.this;
                synchronized (diskLruCache2) {
                    if (DiskLruCache.this.journalWriter == null) {
                        return null;
                    }
                    DiskLruCache.this.trimToSize();
                    DiskLruCache.this.trimToFileCount();
                    if (DiskLruCache.this.journalRebuildRequired()) {
                        DiskLruCache.this.rebuildJournal();
                        DiskLruCache.this.redundantOpCount = 0;
                    }
                    return null;
                }
            }
        };
        this.directory = file;
        this.appVersion = n;
        this.journalFile = new File(file, JOURNAL_FILE);
        this.journalFileTmp = new File(file, JOURNAL_FILE_TEMP);
        this.journalFileBackup = new File(file, JOURNAL_FILE_BACKUP);
        this.valueCount = n2;
        this.maxSize = l;
        this.maxFileCount = n3;
    }

    static /* synthetic */ OutputStream access$2100() {
        return NULL_OUTPUT_STREAM;
    }

    private void checkNotClosed() {
        if (this.journalWriter != null) {
            return;
        }
        throw new IllegalStateException("cache is closed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void completeEdit(Editor var1_1, boolean var2_2) throws IOException {
        var38_3 = this;
        synchronized (var38_3) {
            block17 : {
                var4_4 = Editor.access$1500(var1_1);
                if (Entry.access$800(var4_4) != var1_1) throw new IllegalStateException();
                var5_5 = 0;
                if (var2_2) {
                    var6_6 = Entry.access$700(var4_4);
                    var5_5 = 0;
                    if (!var6_6) {
                        var33_7 = 0;
                        do {
                            var34_8 = this.valueCount;
                            var5_5 = 0;
                            if (var33_7 >= var34_8) break block17;
                            if (!Editor.access$1600(var1_1)[var33_7]) break;
                            if (!var4_4.getDirtyFile(var33_7).exists()) {
                                var1_1.abort();
                                return;
                            }
                            ++var33_7;
                        } while (true);
                        var1_1.abort();
                        var35_9 = new StringBuilder();
                        var35_9.append("Newly created entry didn't create value for index ");
                        var35_9.append(var33_7);
                        throw new IllegalStateException(var35_9.toString());
                    }
                }
            }
lbl28: // 2 sources:
            do {
                if (var5_5 < this.valueCount) {
                    var26_10 = var4_4.getDirtyFile(var5_5);
                    if (var2_2) {
                        if (var26_10.exists()) {
                            var27_11 = var4_4.getCleanFile(var5_5);
                            var26_10.renameTo(var27_11);
                            var29_12 = Entry.access$1100(var4_4)[var5_5];
                            Entry.access$1100((Entry)var4_4)[var5_5] = var31_13 = var27_11.length();
                            this.size = var31_13 + (this.size - var29_12);
                            this.fileCount = 1 + this.fileCount;
                        }
                    } else {
                        DiskLruCache.deleteIfExists(var26_10);
                    }
                    break;
                }
                this.redundantOpCount = 1 + this.redundantOpCount;
                Entry.access$802(var4_4, null);
                if (var2_2 | Entry.access$700(var4_4)) {
                    Entry.access$702(var4_4, true);
                    var16_14 = this.journalWriter;
                    var17_15 = new StringBuilder();
                    var17_15.append("CLEAN ");
                    var17_15.append(Entry.access$1200(var4_4));
                    var17_15.append(var4_4.getLengths());
                    var17_15.append('\n');
                    var16_14.write(var17_15.toString());
                    if (var2_2) {
                        var22_16 = this.nextSequenceNumber;
                        this.nextSequenceNumber = 1L + var22_16;
                        Entry.access$1302(var4_4, var22_16);
                    }
                } else {
                    this.lruEntries.remove((Object)Entry.access$1200(var4_4));
                    var9_17 = this.journalWriter;
                    var10_18 = new StringBuilder();
                    var10_18.append("REMOVE ");
                    var10_18.append(Entry.access$1200(var4_4));
                    var10_18.append('\n');
                    var9_17.write(var10_18.toString());
                }
                this.journalWriter.flush();
                if (this.size <= this.maxSize && this.fileCount <= this.maxFileCount) {
                    if (this.journalRebuildRequired() == false) return;
                }
                this.executorService.submit(this.cleanupCallable);
                return;
                break;
            } while (true);
            ++var5_5;
            ** continue;
        }
    }

    private static void deleteIfExists(File file) throws IOException {
        if (file.exists()) {
            if (file.delete()) {
                return;
            }
            throw new IOException();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Editor edit(String string2, long l) throws IOException {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            long l2;
            this.checkNotClosed();
            this.validateKey(string2);
            Entry entry = (Entry)this.lruEntries.get((Object)string2);
            if (l != -1L && (entry == null || (l2 = entry.sequenceNumber) != l)) {
                return null;
            }
            if (entry == null) {
                entry = new Entry(string2);
                this.lruEntries.put((Object)string2, (Object)entry);
            } else {
                Editor editor = entry.currentEditor;
                if (editor != null) {
                    return null;
                }
            }
            Editor editor = new Editor(entry);
            entry.currentEditor = editor;
            Writer writer = this.journalWriter;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DIRTY ");
            stringBuilder.append(string2);
            stringBuilder.append('\n');
            writer.write(stringBuilder.toString());
            this.journalWriter.flush();
            return editor;
        }
    }

    private static String inputStreamToString(InputStream inputStream) throws IOException {
        return Util.readFully((Reader)new InputStreamReader(inputStream, Util.UTF_8));
    }

    private boolean journalRebuildRequired() {
        int n = this.redundantOpCount;
        return n >= 2000 && n >= this.lruEntries.size();
    }

    public static DiskLruCache open(File file, int n, int n2, long l, int n3) throws IOException {
        if (l > 0L) {
            if (n3 > 0) {
                if (n2 > 0) {
                    File file2 = new File(file, JOURNAL_FILE_BACKUP);
                    if (file2.exists()) {
                        File file3 = new File(file, JOURNAL_FILE);
                        if (file3.exists()) {
                            file2.delete();
                        } else {
                            DiskLruCache.renameTo(file2, file3, false);
                        }
                    }
                    DiskLruCache diskLruCache = new DiskLruCache(file, n, n2, l, n3);
                    if (diskLruCache.journalFile.exists()) {
                        try {
                            diskLruCache.readJournal();
                            diskLruCache.processJournal();
                            diskLruCache.journalWriter = new BufferedWriter((Writer)new OutputStreamWriter((OutputStream)new FileOutputStream(diskLruCache.journalFile, true), Util.US_ASCII));
                            return diskLruCache;
                        }
                        catch (IOException iOException) {
                            PrintStream printStream = System.out;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("DiskLruCache ");
                            stringBuilder.append((Object)file);
                            stringBuilder.append(" is corrupt: ");
                            stringBuilder.append(iOException.getMessage());
                            stringBuilder.append(", removing");
                            printStream.println(stringBuilder.toString());
                            diskLruCache.delete();
                        }
                    }
                    file.mkdirs();
                    DiskLruCache diskLruCache2 = new DiskLruCache(file, n, n2, l, n3);
                    diskLruCache2.rebuildJournal();
                    return diskLruCache2;
                }
                throw new IllegalArgumentException("valueCount <= 0");
            }
            throw new IllegalArgumentException("maxFileCount <= 0");
        }
        throw new IllegalArgumentException("maxSize <= 0");
    }

    private void processJournal() throws IOException {
        DiskLruCache.deleteIfExists(this.journalFileTmp);
        Iterator iterator = this.lruEntries.values().iterator();
        while (iterator.hasNext()) {
            int n;
            Entry entry = (Entry)iterator.next();
            Editor editor = entry.currentEditor;
            if (editor == null) {
                for (n = 0; n < this.valueCount; ++n) {
                    this.size += entry.lengths[n];
                    this.fileCount = 1 + this.fileCount;
                }
                continue;
            }
            entry.currentEditor = null;
            while (n < this.valueCount) {
                DiskLruCache.deleteIfExists(entry.getCleanFile(n));
                DiskLruCache.deleteIfExists(entry.getDirtyFile(n));
                ++n;
            }
            iterator.remove();
        }
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void readJournal() throws IOException {
        String string5;
        String string4;
        StrictLineReader strictLineReader;
        String string3;
        String string2;
        block7 : {
            boolean bl;
            strictLineReader = new StrictLineReader((InputStream)new FileInputStream(this.journalFile), Util.US_ASCII);
            string5 = strictLineReader.readLine();
            string4 = strictLineReader.readLine();
            String string6 = strictLineReader.readLine();
            string2 = strictLineReader.readLine();
            string3 = strictLineReader.readLine();
            if (!MAGIC.equals((Object)string5) || !VERSION_1.equals((Object)string4) || !Integer.toString((int)this.appVersion).equals((Object)string6) || !Integer.toString((int)this.valueCount).equals((Object)string2) || !(bl = "".equals((Object)string3))) break block7;
            int n = 0;
            do {
                this.readJournalLine(strictLineReader.readLine());
                ++n;
            } while (true);
            catch (EOFException eOFException) {
                this.redundantOpCount = n - this.lruEntries.size();
                Util.closeQuietly(strictLineReader);
                return;
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("unexpected journal header: [");
        stringBuilder.append(string5);
        stringBuilder.append(", ");
        stringBuilder.append(string4);
        stringBuilder.append(", ");
        stringBuilder.append(string2);
        stringBuilder.append(", ");
        stringBuilder.append(string3);
        stringBuilder.append("]");
        throw new IOException(stringBuilder.toString());
        {
            catch (Throwable throwable) {
                Util.closeQuietly(strictLineReader);
                throw throwable;
            }
        }
    }

    private void readJournalLine(String string2) throws IOException {
        int n = string2.indexOf(32);
        if (n != -1) {
            Entry entry;
            String string3;
            int n2 = n + 1;
            int n3 = string2.indexOf(32, n2);
            if (n3 == -1) {
                string3 = string2.substring(n2);
                if (n == 6 && string2.startsWith(REMOVE)) {
                    this.lruEntries.remove((Object)string3);
                    return;
                }
            } else {
                string3 = string2.substring(n2, n3);
            }
            if ((entry = (Entry)this.lruEntries.get((Object)string3)) == null) {
                entry = new Entry(string3);
                this.lruEntries.put((Object)string3, (Object)entry);
            }
            if (n3 != -1 && n == 5 && string2.startsWith(CLEAN)) {
                String[] arrstring = string2.substring(n3 + 1).split(" ");
                entry.readable = true;
                entry.currentEditor = null;
                entry.setLengths(arrstring);
                return;
            }
            if (n3 == -1 && n == 5 && string2.startsWith(DIRTY)) {
                entry.currentEditor = new Editor(entry);
                return;
            }
            if (n3 == -1 && n == 4 && string2.startsWith(READ)) {
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("unexpected journal line: ");
            stringBuilder.append(string2);
            throw new IOException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("unexpected journal line: ");
        stringBuilder.append(string2);
        throw new IOException(stringBuilder.toString());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private void rebuildJournal() throws IOException {
        diskLruCache = this;
        // MONITORENTER : diskLruCache
        writer = this.journalWriter;
        if (writer != null) {
            writer.close();
        }
        bufferedWriter = new BufferedWriter((Writer)new OutputStreamWriter((OutputStream)new FileOutputStream(this.journalFileTmp), Util.US_ASCII));
        bufferedWriter.write("libcore.io.DiskLruCache");
        bufferedWriter.write("\n");
        bufferedWriter.write("1");
        bufferedWriter.write("\n");
        bufferedWriter.write(Integer.toString((int)this.appVersion));
        bufferedWriter.write("\n");
        bufferedWriter.write(Integer.toString((int)this.valueCount));
        bufferedWriter.write("\n");
        bufferedWriter.write("\n");
        var5_4 = this.lruEntries.values().iterator();
        {
            catch (Throwable throwable) {
                bufferedWriter.close();
                throw throwable;
            }
            while (var5_4.hasNext()) {
                entry = (Entry)var5_4.next();
                if (Entry.access$800(entry) != null) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("DIRTY ");
                    stringBuilder.append(Entry.access$1200(entry));
                    stringBuilder.append('\n');
                    bufferedWriter.write(stringBuilder.toString());
                    continue;
                }
                stringBuilder = new StringBuilder();
                stringBuilder.append("CLEAN ");
                stringBuilder.append(Entry.access$1200(entry));
                stringBuilder.append(entry.getLengths());
                stringBuilder.append('\n');
                bufferedWriter.write(stringBuilder.toString());
            }
            ** try [egrp 2[TRYBLOCK] [6 : 269->361)] { 
lbl40: // 1 sources:
            bufferedWriter.close();
            if (this.journalFile.exists()) {
                DiskLruCache.renameTo(this.journalFile, this.journalFileBackup, true);
            }
            DiskLruCache.renameTo(this.journalFileTmp, this.journalFile, false);
            this.journalFileBackup.delete();
            this.journalWriter = new BufferedWriter((Writer)new OutputStreamWriter((OutputStream)new FileOutputStream(this.journalFile, true), Util.US_ASCII));
            // MONITOREXIT : diskLruCache
            return;
        }
lbl48: // 2 sources:
        catch (Throwable throwable) {
            // MONITOREXIT : diskLruCache
            throw throwable;
        }
    }

    private static void renameTo(File file, File file2, boolean bl) throws IOException {
        if (bl) {
            DiskLruCache.deleteIfExists(file2);
        }
        if (file.renameTo(file2)) {
            return;
        }
        throw new IOException();
    }

    private void trimToFileCount() throws IOException {
        while (this.fileCount > this.maxFileCount) {
            this.remove((String)((Map.Entry)this.lruEntries.entrySet().iterator().next()).getKey());
        }
    }

    private void trimToSize() throws IOException {
        while (this.size > this.maxSize) {
            this.remove((String)((Map.Entry)this.lruEntries.entrySet().iterator().next()).getKey());
        }
    }

    private void validateKey(String string2) {
        if (LEGAL_KEY_PATTERN.matcher((CharSequence)string2).matches()) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("keys must match regex [a-z0-9_-]{1,64}: \"");
        stringBuilder.append(string2);
        stringBuilder.append("\"");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public void close() throws IOException {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            block5 : {
                Writer writer = this.journalWriter;
                if (writer != null) break block5;
                return;
            }
            try {
                for (Entry entry : new ArrayList(this.lruEntries.values())) {
                    if (entry.currentEditor == null) continue;
                    entry.currentEditor.abort();
                }
                this.trimToSize();
                this.trimToFileCount();
                this.journalWriter.close();
                this.journalWriter = null;
                return;
            }
            catch (Throwable throwable) {
                throw throwable;
            }
        }
    }

    public void delete() throws IOException {
        this.close();
        Util.deleteContents(this.directory);
    }

    public Editor edit(String string2) throws IOException {
        return this.edit(string2, -1L);
    }

    public long fileCount() {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            int n = this.fileCount;
            long l = n;
            return l;
        }
    }

    public void flush() throws IOException {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            this.checkNotClosed();
            this.trimToSize();
            this.trimToFileCount();
            this.journalWriter.flush();
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public Snapshot get(String var1_1) throws IOException {
        block12 : {
            block11 : {
                var20_2 = this;
                // MONITORENTER : var20_2
                this.checkNotClosed();
                this.validateKey(var1_1);
                var3_3 = (Entry)this.lruEntries.get((Object)var1_1);
                if (var3_3 != null) break block11;
                // MONITOREXIT : var20_2
                return null;
            }
            var4_4 = Entry.access$700(var3_3);
            if (var4_4) break block12;
            // MONITOREXIT : var20_2
            return null;
        }
        var5_5 = this.valueCount;
        var6_6 = new File[var5_5];
        var7_7 = new InputStream[var5_5];
        var9_9 = 0;
        do {
            var10_10 = this.valueCount;
            var8_8 = 0;
            if (var9_9 >= var10_10) ** break;
            var6_6[var9_9] = var11_11 = var3_3.getCleanFile(var9_9);
            var7_7[var9_9] = new FileInputStream(var11_11);
            ++var9_9;
        } while (true);
        {
            catch (FileNotFoundException v0) {}
        }
        this.redundantOpCount = 1 + this.redundantOpCount;
        var12_12 = this.journalWriter;
        var13_13 = new StringBuilder();
        var13_13.append("READ ");
        var13_13.append(var1_1);
        var13_13.append('\n');
        var12_12.append((CharSequence)var13_13.toString());
        if (this.journalRebuildRequired()) {
            this.executorService.submit(this.cleanupCallable);
        }
        var18_14 = new Snapshot(var1_1, Entry.access$1300(var3_3), var6_6, var7_7, Entry.access$1100(var3_3));
        // MONITOREXIT : var20_2
        return var18_14;
        {
            for (var8_8 = 0; var8_8 < this.valueCount && var7_7[var8_8] != null; ++var8_8) {
                Util.closeQuietly((Closeable)var7_7[var8_8]);
            }
            // MONITOREXIT : var20_2
            return null;
        }
    }

    public File getDirectory() {
        return this.directory;
    }

    public int getMaxFileCount() {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            int n = this.maxFileCount;
            return n;
        }
    }

    public long getMaxSize() {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            long l = this.maxSize;
            return l;
        }
    }

    public boolean isClosed() {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            Writer writer = this.journalWriter;
            boolean bl = writer == null;
            return bl;
        }
    }

    public boolean remove(String string2) throws IOException {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            block9 : {
                this.checkNotClosed();
                this.validateKey(string2);
                Entry entry = (Entry)this.lruEntries.get((Object)string2);
                if (entry == null) break block9;
                Editor editor = entry.currentEditor;
                int n = 0;
                if (editor != null) break block9;
                do {
                    if (n >= this.valueCount) break;
                    File file = entry.getCleanFile(n);
                    if (file.exists() && !file.delete()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("failed to delete ");
                        stringBuilder.append((Object)file);
                        throw new IOException(stringBuilder.toString());
                    }
                    this.size -= entry.lengths[n];
                    --this.fileCount;
                    Entry.access$1100((Entry)entry)[n] = 0L;
                    ++n;
                } while (true);
                try {
                    this.redundantOpCount = 1 + this.redundantOpCount;
                    Writer writer = this.journalWriter;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("REMOVE ");
                    stringBuilder.append(string2);
                    stringBuilder.append('\n');
                    writer.append((CharSequence)stringBuilder.toString());
                    this.lruEntries.remove((Object)string2);
                    if (this.journalRebuildRequired()) {
                        this.executorService.submit(this.cleanupCallable);
                    }
                    return true;
                }
                catch (Throwable throwable) {}
                {
                    throw throwable;
                }
            }
            return false;
        }
    }

    public void setMaxSize(long l) {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            this.maxSize = l;
            this.executorService.submit(this.cleanupCallable);
            return;
        }
    }

    public long size() {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            long l = this.size;
            return l;
        }
    }

    public final class Editor {
        private boolean committed;
        private final Entry entry;
        private boolean hasErrors;
        private final boolean[] written;

        private Editor(Entry entry) {
            this.entry = entry;
            boolean[] arrbl = entry.readable ? null : new boolean[DiskLruCache.this.valueCount];
            this.written = arrbl;
        }

        static /* synthetic */ Entry access$1500(Editor editor) {
            return editor.entry;
        }

        static /* synthetic */ boolean[] access$1600(Editor editor) {
            return editor.written;
        }

        public void abort() throws IOException {
            DiskLruCache.this.completeEdit(this, false);
        }

        /*
         * Exception decompiling
         */
        public void abortUnlessCommitted() {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
            // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
            // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
            // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:919)
            throw new IllegalStateException("Decompilation failed");
        }

        public void commit() throws IOException {
            if (this.hasErrors) {
                DiskLruCache.this.completeEdit(this, false);
                DiskLruCache.this.remove(this.entry.key);
            } else {
                DiskLruCache.this.completeEdit(this, true);
            }
            this.committed = true;
        }

        public String getString(int n) throws IOException {
            InputStream inputStream = this.newInputStream(n);
            if (inputStream != null) {
                return DiskLruCache.inputStreamToString(inputStream);
            }
            return null;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public InputStream newInputStream(int n) throws IOException {
            DiskLruCache diskLruCache;
            DiskLruCache diskLruCache2 = diskLruCache = DiskLruCache.this;
            synchronized (diskLruCache2) {
                if (this.entry.currentEditor != this) {
                    throw new IllegalStateException();
                }
                if (!this.entry.readable) {
                    return null;
                }
                try {
                    return new FileInputStream(this.entry.getCleanFile(n));
                }
                catch (FileNotFoundException fileNotFoundException) {
                    return null;
                }
            }
        }

        /*
         * Exception decompiling
         */
        public OutputStream newOutputStream(int var1) throws IOException {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl43 : NEW : trying to set 1 previously set to 0
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:919)
            throw new IllegalStateException("Decompilation failed");
        }

        /*
         * Loose catch block
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        public void set(int n, String string2) throws IOException {
            void var5_7;
            OutputStreamWriter outputStreamWriter;
            block4 : {
                outputStreamWriter = null;
                OutputStreamWriter outputStreamWriter2 = new OutputStreamWriter(this.newOutputStream(n), Util.UTF_8);
                try {
                    outputStreamWriter2.write(string2);
                }
                catch (Throwable throwable) {
                    outputStreamWriter = outputStreamWriter2;
                    break block4;
                }
                Util.closeQuietly((Closeable)outputStreamWriter2);
                return;
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            Util.closeQuietly(outputStreamWriter);
            throw var5_7;
        }

        private class FaultHidingOutputStream
        extends FilterOutputStream {
            private FaultHidingOutputStream(OutputStream outputStream) {
                super(outputStream);
            }

            public void close() {
                try {
                    this.out.close();
                    return;
                }
                catch (IOException iOException) {
                    Editor.this.hasErrors = true;
                    return;
                }
            }

            public void flush() {
                try {
                    this.out.flush();
                    return;
                }
                catch (IOException iOException) {
                    Editor.this.hasErrors = true;
                    return;
                }
            }

            public void write(int n) {
                try {
                    this.out.write(n);
                    return;
                }
                catch (IOException iOException) {
                    Editor.this.hasErrors = true;
                    return;
                }
            }

            public void write(byte[] arrby, int n, int n2) {
                try {
                    this.out.write(arrby, n, n2);
                    return;
                }
                catch (IOException iOException) {
                    Editor.this.hasErrors = true;
                    return;
                }
            }
        }

    }

    private final class Entry {
        private Editor currentEditor;
        private final String key;
        private final long[] lengths;
        private boolean readable;
        private long sequenceNumber;

        private Entry(String string2) {
            this.key = string2;
            this.lengths = new long[DiskLruCache.this.valueCount];
        }

        static /* synthetic */ long access$1302(Entry entry, long l) {
            entry.sequenceNumber = l;
            return l;
        }

        private IOException invalidLengths(String[] arrstring) throws IOException {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("unexpected journal line: ");
            stringBuilder.append(Arrays.toString((Object[])arrstring));
            throw new IOException(stringBuilder.toString());
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        private void setLengths(String[] arrstring) throws IOException {
            if (arrstring.length != DiskLruCache.this.valueCount) {
                IOException iOException = this.invalidLengths(arrstring);
                throw iOException;
            }
            int n = 0;
            try {
                while (n < arrstring.length) {
                    this.lengths[n] = Long.parseLong((String)arrstring[n]);
                    ++n;
                }
                return;
            }
            catch (NumberFormatException numberFormatException) {
                throw this.invalidLengths(arrstring);
            }
        }

        public File getCleanFile(int n) {
            File file = DiskLruCache.this.directory;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.key);
            stringBuilder.append("");
            stringBuilder.append(n);
            return new File(file, stringBuilder.toString());
        }

        public File getDirtyFile(int n) {
            File file = DiskLruCache.this.directory;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.key);
            stringBuilder.append("");
            stringBuilder.append(n);
            stringBuilder.append(".tmp");
            return new File(file, stringBuilder.toString());
        }

        public String getLengths() throws IOException {
            StringBuilder stringBuilder = new StringBuilder();
            for (long l : this.lengths) {
                stringBuilder.append(' ');
                stringBuilder.append(l);
            }
            return stringBuilder.toString();
        }
    }

    public final class Snapshot
    implements Closeable {
        private File[] files;
        private final InputStream[] ins;
        private final String key;
        private final long[] lengths;
        private final long sequenceNumber;

        private Snapshot(String string2, long l, File[] arrfile, InputStream[] arrinputStream, long[] arrl) {
            this.key = string2;
            this.sequenceNumber = l;
            this.files = arrfile;
            this.ins = arrinputStream;
            this.lengths = arrl;
        }

        public void close() {
            InputStream[] arrinputStream = this.ins;
            int n = arrinputStream.length;
            for (int i = 0; i < n; ++i) {
                Util.closeQuietly((Closeable)arrinputStream[i]);
            }
        }

        public Editor edit() throws IOException {
            return DiskLruCache.this.edit(this.key, this.sequenceNumber);
        }

        public File getFile(int n) {
            return this.files[n];
        }

        public InputStream getInputStream(int n) {
            return this.ins[n];
        }

        public long getLength(int n) {
            return this.lengths[n];
        }

        public String getString(int n) throws IOException {
            return DiskLruCache.inputStreamToString(this.getInputStream(n));
        }
    }

}

