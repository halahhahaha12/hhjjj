/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.cache.disc;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.utils.IoUtils;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public interface DiskCache {
    public void clear();

    public void close();

    public File get(String var1);

    public File getDirectory();

    public boolean remove(String var1);

    public boolean save(String var1, Bitmap var2) throws IOException;

    public boolean save(String var1, InputStream var2, IoUtils.CopyListener var3) throws IOException;
}

