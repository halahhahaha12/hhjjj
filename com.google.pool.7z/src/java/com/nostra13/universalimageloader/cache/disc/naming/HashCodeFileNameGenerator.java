/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.cache.disc.naming;

import com.nostra13.universalimageloader.cache.disc.naming.FileNameGenerator;

public class HashCodeFileNameGenerator
implements FileNameGenerator {
    @Override
    public String generate(String string2) {
        return String.valueOf((int)string2.hashCode());
    }
}

