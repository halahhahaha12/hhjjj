/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.concurrent.atomic.AtomicInteger
 */
package com.nostra13.universalimageloader.cache.memory;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.memory.BaseMemoryCache;
import com.nostra13.universalimageloader.utils.L;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class LimitedMemoryCache
extends BaseMemoryCache {
    private static final int MAX_NORMAL_CACHE_SIZE = 16777216;
    private static final int MAX_NORMAL_CACHE_SIZE_IN_MB = 16;
    private final AtomicInteger cacheSize;
    private final List<Bitmap> hardCache = Collections.synchronizedList((List)new LinkedList());
    private final int sizeLimit;

    public LimitedMemoryCache(int n) {
        this.sizeLimit = n;
        this.cacheSize = new AtomicInteger();
        if (n > 16777216) {
            Object[] arrobject = new Object[]{16};
            L.w("You set too large memory cache size (more than %1$d Mb)", arrobject);
        }
    }

    @Override
    public void clear() {
        this.hardCache.clear();
        this.cacheSize.set(0);
        super.clear();
    }

    protected abstract int getSize(Bitmap var1);

    protected int getSizeLimit() {
        return this.sizeLimit;
    }

    @Override
    public boolean put(String string2, Bitmap bitmap) {
        boolean bl;
        int n = this.getSize(bitmap);
        int n2 = this.getSizeLimit();
        int n3 = this.cacheSize.get();
        if (n < n2) {
            while (n3 + n > n2) {
                Bitmap bitmap2 = this.removeNext();
                if (!this.hardCache.remove((Object)bitmap2)) continue;
                n3 = this.cacheSize.addAndGet(-this.getSize(bitmap2));
            }
            this.hardCache.add((Object)bitmap);
            this.cacheSize.addAndGet(n);
            bl = true;
        } else {
            bl = false;
        }
        super.put(string2, bitmap);
        return bl;
    }

    @Override
    public Bitmap remove(String string2) {
        Bitmap bitmap = super.get(string2);
        if (bitmap != null && this.hardCache.remove((Object)bitmap)) {
            this.cacheSize.addAndGet(-this.getSize(bitmap));
        }
        return super.remove(string2);
    }

    protected abstract Bitmap removeNext();
}

