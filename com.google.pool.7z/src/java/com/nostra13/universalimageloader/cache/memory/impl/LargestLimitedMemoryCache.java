/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.ref.Reference
 *  java.lang.ref.WeakReference
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.nostra13.universalimageloader.cache.memory.impl;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.memory.LimitedMemoryCache;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class LargestLimitedMemoryCache
extends LimitedMemoryCache {
    private final Map<Bitmap, Integer> valueSizes = Collections.synchronizedMap((Map)new HashMap());

    public LargestLimitedMemoryCache(int n) {
        super(n);
    }

    @Override
    public void clear() {
        this.valueSizes.clear();
        super.clear();
    }

    @Override
    protected Reference<Bitmap> createReference(Bitmap bitmap) {
        return new WeakReference((Object)bitmap);
    }

    @Override
    protected int getSize(Bitmap bitmap) {
        return bitmap.getRowBytes() * bitmap.getHeight();
    }

    @Override
    public boolean put(String string2, Bitmap bitmap) {
        if (super.put(string2, bitmap)) {
            this.valueSizes.put((Object)bitmap, (Object)this.getSize(bitmap));
            return true;
        }
        return false;
    }

    @Override
    public Bitmap remove(String string2) {
        Bitmap bitmap = super.get(string2);
        if (bitmap != null) {
            this.valueSizes.remove((Object)bitmap);
        }
        return super.remove(string2);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    protected Bitmap removeNext() {
        Map<Bitmap, Integer> map;
        Set set = this.valueSizes.entrySet();
        Map<Bitmap, Integer> map2 = map = this.valueSizes;
        // MONITORENTER : map2
        Iterator iterator = set.iterator();
        Bitmap bitmap = null;
        Integer n = null;
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            if (bitmap == null) {
                bitmap = (Bitmap)entry.getKey();
                n = (Integer)entry.getValue();
                continue;
            }
            Integer n2 = (Integer)entry.getValue();
            if (n2 <= n) continue;
            bitmap = (Bitmap)entry.getKey();
            n = n2;
        }
        // MONITOREXIT : map2
        {
            catch (Throwable throwable) {}
            {
                // MONITOREXIT : map2
                throw throwable;
            }
        }
        this.valueSizes.remove(bitmap);
        return bitmap;
    }
}

