/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.IllegalArgumentException
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.HashSet
 *  java.util.LinkedHashMap
 *  java.util.Objects
 *  java.util.Set
 */
package com.nostra13.universalimageloader.cache.memory.impl;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.memory.MemoryCache;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Objects;
import java.util.Set;

public class LruMemoryCache
implements MemoryCache {
    private final LinkedHashMap<String, Bitmap> map;
    private final int maxSize;
    private int size;

    public LruMemoryCache(int n) {
        if (n > 0) {
            this.maxSize = n;
            this.map = new LinkedHashMap(0, 0.75f, true);
            return;
        }
        throw new IllegalArgumentException("maxSize <= 0");
    }

    private int sizeOf(String string2, Bitmap bitmap) {
        return bitmap.getRowBytes() * bitmap.getHeight();
    }

    /*
     * Exception decompiling
     */
    private void trimToSize(int var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [3[UNCONDITIONALDOLOOP]], but top level block is 0[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public void clear() {
        this.trimToSize(-1);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Bitmap get(String string2) {
        Objects.requireNonNull((Object)string2, (String)"key == null");
        LruMemoryCache lruMemoryCache = this;
        synchronized (lruMemoryCache) {
            return (Bitmap)this.map.get((Object)string2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Collection<String> keys() {
        LruMemoryCache lruMemoryCache = this;
        synchronized (lruMemoryCache) {
            return new HashSet((Collection)this.map.keySet());
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final boolean put(String string2, Bitmap bitmap) {
        if (string2 != null && bitmap != null) {
            LruMemoryCache lruMemoryCache = this;
            synchronized (lruMemoryCache) {
                this.size += this.sizeOf(string2, bitmap);
                Bitmap bitmap2 = (Bitmap)this.map.put((Object)string2, (Object)bitmap);
                if (bitmap2 != null) {
                    this.size -= this.sizeOf(string2, bitmap2);
                }
            }
            this.trimToSize(this.maxSize);
            return true;
        }
        throw new NullPointerException("key == null || value == null");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Bitmap remove(String string2) {
        Objects.requireNonNull((Object)string2, (String)"key == null");
        LruMemoryCache lruMemoryCache = this;
        synchronized (lruMemoryCache) {
            Bitmap bitmap = (Bitmap)this.map.remove((Object)string2);
            if (bitmap != null) {
                this.size -= this.sizeOf(string2, bitmap);
            }
            return bitmap;
        }
    }

    public final String toString() {
        LruMemoryCache lruMemoryCache = this;
        synchronized (lruMemoryCache) {
            Object[] arrobject = new Object[]{this.maxSize};
            String string2 = String.format((String)"LruCache[maxSize=%d]", (Object[])arrobject);
            return string2;
        }
    }
}

