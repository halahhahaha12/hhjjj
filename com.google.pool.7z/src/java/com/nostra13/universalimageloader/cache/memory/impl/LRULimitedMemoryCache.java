/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.Reference
 *  java.lang.ref.WeakReference
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.nostra13.universalimageloader.cache.memory.impl;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.memory.LimitedMemoryCache;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class LRULimitedMemoryCache
extends LimitedMemoryCache {
    private static final int INITIAL_CAPACITY = 10;
    private static final float LOAD_FACTOR = 1.1f;
    private final Map<String, Bitmap> lruCache = Collections.synchronizedMap((Map)new LinkedHashMap(10, 1.1f, true));

    public LRULimitedMemoryCache(int n) {
        super(n);
    }

    @Override
    public void clear() {
        this.lruCache.clear();
        super.clear();
    }

    @Override
    protected Reference<Bitmap> createReference(Bitmap bitmap) {
        return new WeakReference((Object)bitmap);
    }

    @Override
    public Bitmap get(String string2) {
        this.lruCache.get((Object)string2);
        return super.get(string2);
    }

    @Override
    protected int getSize(Bitmap bitmap) {
        return bitmap.getRowBytes() * bitmap.getHeight();
    }

    @Override
    public boolean put(String string2, Bitmap bitmap) {
        if (super.put(string2, bitmap)) {
            this.lruCache.put((Object)string2, (Object)bitmap);
            return true;
        }
        return false;
    }

    @Override
    public Bitmap remove(String string2) {
        this.lruCache.remove((Object)string2);
        return super.remove(string2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected Bitmap removeNext() {
        Map<String, Bitmap> map;
        Map<String, Bitmap> map2 = map = this.lruCache;
        synchronized (map2) {
            Iterator iterator = this.lruCache.entrySet().iterator();
            if (!iterator.hasNext()) return null;
            Bitmap bitmap = (Bitmap)((Map.Entry)iterator.next()).getValue();
            iterator.remove();
            return bitmap;
        }
    }
}

