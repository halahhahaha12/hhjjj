/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Collection
 *  java.util.Comparator
 *  java.util.Iterator
 */
package com.nostra13.universalimageloader.cache.memory.impl;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.memory.MemoryCache;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;

public class FuzzyKeyMemoryCache
implements MemoryCache {
    private final MemoryCache cache;
    private final Comparator<String> keyComparator;

    public FuzzyKeyMemoryCache(MemoryCache memoryCache, Comparator<String> comparator) {
        this.cache = memoryCache;
        this.keyComparator = comparator;
    }

    @Override
    public void clear() {
        this.cache.clear();
    }

    @Override
    public Bitmap get(String string2) {
        return this.cache.get(string2);
    }

    @Override
    public Collection<String> keys() {
        return this.cache.keys();
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public boolean put(String string2, Bitmap bitmap) {
        String string3;
        block6 : {
            MemoryCache memoryCache;
            String string4;
            MemoryCache memoryCache2 = memoryCache = this.cache;
            // MONITORENTER : memoryCache2
            Iterator iterator = this.cache.keys().iterator();
            do {
                boolean bl = iterator.hasNext();
                string3 = null;
                if (!bl) break block6;
            } while (this.keyComparator.compare((Object)string2, (Object)(string4 = (String)iterator.next())) != 0);
            string3 = string4;
        }
        if (string3 != null) {
            this.cache.remove(string3);
        }
        // MONITOREXIT : memoryCache2
        {
            catch (Throwable throwable) {}
            {
                // MONITOREXIT : memoryCache2
                throw throwable;
            }
        }
        return this.cache.put(string2, bitmap);
    }

    @Override
    public Bitmap remove(String string2) {
        return this.cache.remove(string2);
    }
}

