/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Map
 */
package com.nostra13.universalimageloader.cache.memory.impl;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.memory.MemoryCache;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class LimitedAgeMemoryCache
implements MemoryCache {
    private final MemoryCache cache;
    private final Map<String, Long> loadingDates = Collections.synchronizedMap((Map)new HashMap());
    private final long maxAge;

    public LimitedAgeMemoryCache(MemoryCache memoryCache, long l) {
        this.cache = memoryCache;
        this.maxAge = l * 1000L;
    }

    @Override
    public void clear() {
        this.cache.clear();
        this.loadingDates.clear();
    }

    @Override
    public Bitmap get(String string2) {
        Long l = (Long)this.loadingDates.get((Object)string2);
        if (l != null && System.currentTimeMillis() - l > this.maxAge) {
            this.cache.remove(string2);
            this.loadingDates.remove((Object)string2);
        }
        return this.cache.get(string2);
    }

    @Override
    public Collection<String> keys() {
        return this.cache.keys();
    }

    @Override
    public boolean put(String string2, Bitmap bitmap) {
        boolean bl = this.cache.put(string2, bitmap);
        if (bl) {
            this.loadingDates.put((Object)string2, (Object)System.currentTimeMillis());
        }
        return bl;
    }

    @Override
    public Bitmap remove(String string2) {
        this.loadingDates.remove((Object)string2);
        return this.cache.remove(string2);
    }
}

