/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.Reference
 *  java.lang.ref.WeakReference
 *  java.util.Collections
 *  java.util.LinkedList
 *  java.util.List
 */
package com.nostra13.universalimageloader.cache.memory.impl;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.memory.LimitedMemoryCache;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class FIFOLimitedMemoryCache
extends LimitedMemoryCache {
    private final List<Bitmap> queue = Collections.synchronizedList((List)new LinkedList());

    public FIFOLimitedMemoryCache(int n) {
        super(n);
    }

    @Override
    public void clear() {
        this.queue.clear();
        super.clear();
    }

    @Override
    protected Reference<Bitmap> createReference(Bitmap bitmap) {
        return new WeakReference((Object)bitmap);
    }

    @Override
    protected int getSize(Bitmap bitmap) {
        return bitmap.getRowBytes() * bitmap.getHeight();
    }

    @Override
    public boolean put(String string2, Bitmap bitmap) {
        if (super.put(string2, bitmap)) {
            this.queue.add((Object)bitmap);
            return true;
        }
        return false;
    }

    @Override
    public Bitmap remove(String string2) {
        Bitmap bitmap = super.get(string2);
        if (bitmap != null) {
            this.queue.remove((Object)bitmap);
        }
        return super.remove(string2);
    }

    @Override
    protected Bitmap removeNext() {
        return (Bitmap)this.queue.remove(0);
    }
}

