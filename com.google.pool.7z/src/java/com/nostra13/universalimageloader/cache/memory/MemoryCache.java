/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 */
package com.nostra13.universalimageloader.cache.memory;

import android.graphics.Bitmap;
import java.util.Collection;

public interface MemoryCache {
    public void clear();

    public Bitmap get(String var1);

    public Collection<String> keys();

    public boolean put(String var1, Bitmap var2);

    public Bitmap remove(String var1);
}

