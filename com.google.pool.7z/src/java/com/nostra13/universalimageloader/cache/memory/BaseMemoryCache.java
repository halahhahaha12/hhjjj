/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.Reference
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Map
 *  java.util.Set
 */
package com.nostra13.universalimageloader.cache.memory;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.cache.memory.MemoryCache;
import java.lang.ref.Reference;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public abstract class BaseMemoryCache
implements MemoryCache {
    private final Map<String, Reference<Bitmap>> softMap = Collections.synchronizedMap((Map)new HashMap());

    @Override
    public void clear() {
        this.softMap.clear();
    }

    protected abstract Reference<Bitmap> createReference(Bitmap var1);

    @Override
    public Bitmap get(String string2) {
        Reference reference = (Reference)this.softMap.get((Object)string2);
        if (reference != null) {
            return (Bitmap)reference.get();
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Collection<String> keys() {
        Map<String, Reference<Bitmap>> map;
        Map<String, Reference<Bitmap>> map2 = map = this.softMap;
        synchronized (map2) {
            return new HashSet((Collection)this.softMap.keySet());
        }
    }

    @Override
    public boolean put(String string2, Bitmap bitmap) {
        this.softMap.put((Object)string2, this.createReference(bitmap));
        return true;
    }

    @Override
    public Bitmap remove(String string2) {
        Reference reference = (Reference)this.softMap.remove((Object)string2);
        if (reference == null) {
            return null;
        }
        return (Bitmap)reference.get();
    }
}

