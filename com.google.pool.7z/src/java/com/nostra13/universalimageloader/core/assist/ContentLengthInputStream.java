/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 */
package com.nostra13.universalimageloader.core.assist;

import java.io.IOException;
import java.io.InputStream;

public class ContentLengthInputStream
extends InputStream {
    private final int length;
    private final InputStream stream;

    public ContentLengthInputStream(InputStream inputStream, int n) {
        this.stream = inputStream;
        this.length = n;
    }

    public int available() {
        return this.length;
    }

    public void close() throws IOException {
        this.stream.close();
    }

    public void mark(int n) {
        this.stream.mark(n);
    }

    public boolean markSupported() {
        return this.stream.markSupported();
    }

    public int read() throws IOException {
        return this.stream.read();
    }

    public int read(byte[] arrby) throws IOException {
        return this.stream.read(arrby);
    }

    public int read(byte[] arrby, int n, int n2) throws IOException {
        return this.stream.read(arrby, n, n2);
    }

    public void reset() throws IOException {
        this.stream.reset();
    }

    public long skip(long l) throws IOException {
        return this.stream.skip(l);
    }
}

