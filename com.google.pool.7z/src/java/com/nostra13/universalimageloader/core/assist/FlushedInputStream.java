/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.FilterInputStream
 *  java.io.IOException
 *  java.io.InputStream
 */
package com.nostra13.universalimageloader.core.assist;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class FlushedInputStream
extends FilterInputStream {
    public FlushedInputStream(InputStream inputStream) {
        super(inputStream);
    }

    public long skip(long l) throws IOException {
        long l2;
        long l3;
        for (l2 = 0L; l2 < l; l2 += l3) {
            l3 = this.in.skip(l - l2);
            if (l3 != 0L) continue;
            if (this.read() < 0) {
                return l2;
            }
            l3 = 1L;
        }
        return l2;
    }
}

