/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.core.assist;

public final class LoadedFrom
extends Enum<LoadedFrom> {
    private static final /* synthetic */ LoadedFrom[] $VALUES;
    public static final /* enum */ LoadedFrom DISC_CACHE;
    public static final /* enum */ LoadedFrom MEMORY_CACHE;
    public static final /* enum */ LoadedFrom NETWORK;

    static {
        LoadedFrom loadedFrom;
        LoadedFrom loadedFrom2;
        LoadedFrom loadedFrom3;
        NETWORK = loadedFrom3 = new LoadedFrom();
        DISC_CACHE = loadedFrom = new LoadedFrom();
        MEMORY_CACHE = loadedFrom2 = new LoadedFrom();
        $VALUES = new LoadedFrom[]{loadedFrom3, loadedFrom, loadedFrom2};
    }

    public static LoadedFrom valueOf(String string2) {
        return (LoadedFrom)Enum.valueOf(LoadedFrom.class, (String)string2);
    }

    public static LoadedFrom[] values() {
        return (LoadedFrom[])$VALUES.clone();
    }
}

