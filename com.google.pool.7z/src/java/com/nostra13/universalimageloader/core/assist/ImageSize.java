/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.nostra13.universalimageloader.core.assist;

public class ImageSize {
    private static final String SEPARATOR = "x";
    private static final int TO_STRING_MAX_LENGHT = 9;
    private final int height;
    private final int width;

    public ImageSize(int n, int n2) {
        this.width = n;
        this.height = n2;
    }

    public ImageSize(int n, int n2, int n3) {
        if (n3 % 180 == 0) {
            this.width = n;
            this.height = n2;
            return;
        }
        this.width = n2;
        this.height = n;
    }

    public int getHeight() {
        return this.height;
    }

    public int getWidth() {
        return this.width;
    }

    public ImageSize scale(float f) {
        return new ImageSize((int)(f * (float)this.width), (int)(f * (float)this.height));
    }

    public ImageSize scaleDown(int n) {
        return new ImageSize(this.width / n, this.height / n);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(9);
        stringBuilder.append(this.width);
        stringBuilder.append(SEPARATOR);
        stringBuilder.append(this.height);
        return stringBuilder.toString();
    }
}

