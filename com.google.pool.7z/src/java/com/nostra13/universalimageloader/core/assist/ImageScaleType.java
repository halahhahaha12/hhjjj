/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.core.assist;

public final class ImageScaleType
extends Enum<ImageScaleType> {
    private static final /* synthetic */ ImageScaleType[] $VALUES;
    public static final /* enum */ ImageScaleType EXACTLY;
    public static final /* enum */ ImageScaleType EXACTLY_STRETCHED;
    public static final /* enum */ ImageScaleType IN_SAMPLE_INT;
    public static final /* enum */ ImageScaleType IN_SAMPLE_POWER_OF_2;
    public static final /* enum */ ImageScaleType NONE;
    public static final /* enum */ ImageScaleType NONE_SAFE;

    static {
        ImageScaleType imageScaleType;
        ImageScaleType imageScaleType2;
        ImageScaleType imageScaleType3;
        ImageScaleType imageScaleType4;
        ImageScaleType imageScaleType5;
        ImageScaleType imageScaleType6;
        NONE = imageScaleType6 = new ImageScaleType();
        NONE_SAFE = imageScaleType5 = new ImageScaleType();
        IN_SAMPLE_POWER_OF_2 = imageScaleType2 = new ImageScaleType();
        IN_SAMPLE_INT = imageScaleType4 = new ImageScaleType();
        EXACTLY = imageScaleType = new ImageScaleType();
        EXACTLY_STRETCHED = imageScaleType3 = new ImageScaleType();
        $VALUES = new ImageScaleType[]{imageScaleType6, imageScaleType5, imageScaleType2, imageScaleType4, imageScaleType, imageScaleType3};
    }

    public static ImageScaleType valueOf(String string2) {
        return (ImageScaleType)Enum.valueOf(ImageScaleType.class, (String)string2);
    }

    public static ImageScaleType[] values() {
        return (ImageScaleType[])$VALUES.clone();
    }
}

