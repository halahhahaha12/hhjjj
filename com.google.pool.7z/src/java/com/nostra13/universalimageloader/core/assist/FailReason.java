/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.nostra13.universalimageloader.core.assist;

public class FailReason {
    private final Throwable cause;
    private final FailType type;

    public FailReason(FailType failType, Throwable throwable) {
        this.type = failType;
        this.cause = throwable;
    }

    public Throwable getCause() {
        return this.cause;
    }

    public FailType getType() {
        return this.type;
    }

    public static final class FailType
    extends Enum<FailType> {
        private static final /* synthetic */ FailType[] $VALUES;
        public static final /* enum */ FailType DECODING_ERROR;
        public static final /* enum */ FailType IO_ERROR;
        public static final /* enum */ FailType NETWORK_DENIED;
        public static final /* enum */ FailType OUT_OF_MEMORY;
        public static final /* enum */ FailType UNKNOWN;

        static {
            FailType failType;
            FailType failType2;
            FailType failType3;
            FailType failType4;
            FailType failType5;
            IO_ERROR = failType3 = new FailType();
            DECODING_ERROR = failType4 = new FailType();
            NETWORK_DENIED = failType2 = new FailType();
            OUT_OF_MEMORY = failType = new FailType();
            UNKNOWN = failType5 = new FailType();
            $VALUES = new FailType[]{failType3, failType4, failType2, failType, failType5};
        }

        public static FailType valueOf(String string2) {
            return (FailType)Enum.valueOf(FailType.class, (String)string2);
        }

        public static FailType[] values() {
            return (FailType[])$VALUES.clone();
        }
    }

}

