/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  java.lang.Enum
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.core.assist;

import android.widget.ImageView;

public final class ViewScaleType
extends Enum<ViewScaleType> {
    private static final /* synthetic */ ViewScaleType[] $VALUES;
    public static final /* enum */ ViewScaleType CROP;
    public static final /* enum */ ViewScaleType FIT_INSIDE;

    static {
        ViewScaleType viewScaleType;
        ViewScaleType viewScaleType2;
        FIT_INSIDE = viewScaleType2 = new ViewScaleType();
        CROP = viewScaleType = new ViewScaleType();
        $VALUES = new ViewScaleType[]{viewScaleType2, viewScaleType};
    }

    public static ViewScaleType fromImageView(ImageView imageView) {
        int n = 1.$SwitchMap$android$widget$ImageView$ScaleType[imageView.getScaleType().ordinal()];
        if (n != 1 && n != 2 && n != 3 && n != 4 && n != 5) {
            return CROP;
        }
        return FIT_INSIDE;
    }

    public static ViewScaleType valueOf(String string2) {
        return (ViewScaleType)Enum.valueOf(ViewScaleType.class, (String)string2);
    }

    public static ViewScaleType[] values() {
        return (ViewScaleType[])$VALUES.clone();
    }

}

