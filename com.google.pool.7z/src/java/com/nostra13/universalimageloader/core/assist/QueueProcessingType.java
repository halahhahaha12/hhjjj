/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.core.assist;

public final class QueueProcessingType
extends Enum<QueueProcessingType> {
    private static final /* synthetic */ QueueProcessingType[] $VALUES;
    public static final /* enum */ QueueProcessingType FIFO;
    public static final /* enum */ QueueProcessingType LIFO;

    static {
        QueueProcessingType queueProcessingType;
        QueueProcessingType queueProcessingType2;
        FIFO = queueProcessingType2 = new QueueProcessingType();
        LIFO = queueProcessingType = new QueueProcessingType();
        $VALUES = new QueueProcessingType[]{queueProcessingType2, queueProcessingType};
    }

    public static QueueProcessingType valueOf(String string2) {
        return (QueueProcessingType)Enum.valueOf(QueueProcessingType.class, (String)string2);
    }

    public static QueueProcessingType[] values() {
        return (QueueProcessingType[])$VALUES.clone();
    }
}

