/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.widget.AbsListView
 *  android.widget.AbsListView$OnScrollListener
 *  java.lang.Object
 */
package com.nostra13.universalimageloader.core.listener;

import android.widget.AbsListView;
import com.nostra13.universalimageloader.core.ImageLoader;

public class PauseOnScrollListener
implements AbsListView.OnScrollListener {
    private final AbsListView.OnScrollListener externalListener;
    private ImageLoader imageLoader;
    private final boolean pauseOnFling;
    private final boolean pauseOnScroll;

    public PauseOnScrollListener(ImageLoader imageLoader, boolean bl, boolean bl2) {
        this(imageLoader, bl, bl2, null);
    }

    public PauseOnScrollListener(ImageLoader imageLoader, boolean bl, boolean bl2, AbsListView.OnScrollListener onScrollListener) {
        this.imageLoader = imageLoader;
        this.pauseOnScroll = bl;
        this.pauseOnFling = bl2;
        this.externalListener = onScrollListener;
    }

    public void onScroll(AbsListView absListView, int n, int n2, int n3) {
        AbsListView.OnScrollListener onScrollListener = this.externalListener;
        if (onScrollListener != null) {
            onScrollListener.onScroll(absListView, n, n2, n3);
        }
    }

    public void onScrollStateChanged(AbsListView absListView, int n) {
        AbsListView.OnScrollListener onScrollListener;
        if (n != 0) {
            if (n != 1) {
                if (n == 2 && this.pauseOnFling) {
                    this.imageLoader.pause();
                }
            } else if (this.pauseOnScroll) {
                this.imageLoader.pause();
            }
        } else {
            this.imageLoader.resume();
        }
        if ((onScrollListener = this.externalListener) != null) {
            onScrollListener.onScrollStateChanged(absListView, n);
        }
    }
}

