/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.view.View
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.core.listener;

import android.graphics.Bitmap;
import android.view.View;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

public class SimpleImageLoadingListener
implements ImageLoadingListener {
    @Override
    public void onLoadingCancelled(String string2, View view) {
    }

    @Override
    public void onLoadingComplete(String string2, View view, Bitmap bitmap) {
    }

    @Override
    public void onLoadingFailed(String string2, View view, FailReason failReason) {
    }

    @Override
    public void onLoadingStarted(String string2, View view) {
    }
}

