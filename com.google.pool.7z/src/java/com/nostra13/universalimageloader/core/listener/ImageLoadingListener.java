/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.view.View
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.core.listener;

import android.graphics.Bitmap;
import android.view.View;
import com.nostra13.universalimageloader.core.assist.FailReason;

public interface ImageLoadingListener {
    public void onLoadingCancelled(String var1, View var2);

    public void onLoadingComplete(String var1, View var2, Bitmap var3);

    public void onLoadingFailed(String var1, View var2, FailReason var3);

    public void onLoadingStarted(String var1, View var2);
}

