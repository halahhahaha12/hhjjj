/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.core.listener;

import android.view.View;

public interface ImageLoadingProgressListener {
    public void onProgressUpdate(String var1, View var2, int var3, int var4);
}

