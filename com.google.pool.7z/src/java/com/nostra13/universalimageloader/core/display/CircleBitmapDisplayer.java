/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.BitmapShader
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.Matrix
 *  android.graphics.Matrix$ScaleToFit
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.drawable.Drawable
 *  com.nostra13.universalimageloader.core.imageaware.ImageViewAware
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.core.display;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import com.nostra13.universalimageloader.core.assist.LoadedFrom;
import com.nostra13.universalimageloader.core.display.BitmapDisplayer;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;

public class CircleBitmapDisplayer
implements BitmapDisplayer {
    protected final Integer strokeColor;
    protected final float strokeWidth;

    public CircleBitmapDisplayer() {
        this(null);
    }

    public CircleBitmapDisplayer(Integer n) {
        this(n, 0.0f);
    }

    public CircleBitmapDisplayer(Integer n, float f) {
        this.strokeColor = n;
        this.strokeWidth = f;
    }

    @Override
    public void display(Bitmap bitmap, ImageAware imageAware, LoadedFrom loadedFrom) {
        if (imageAware instanceof ImageViewAware) {
            imageAware.setImageDrawable(new Drawable(bitmap, this.strokeColor, this.strokeWidth){
                protected final BitmapShader bitmapShader;
                protected final RectF mBitmapRect;
                protected final RectF mRect = new RectF();
                protected final Paint paint;
                protected float radius;
                protected final Paint strokePaint;
                protected float strokeRadius;
                protected final float strokeWidth;
                {
                    Paint paint;
                    BitmapShader bitmapShader;
                    this.radius = Math.min((int)bitmap.getWidth(), (int)bitmap.getHeight()) / 2;
                    this.bitmapShader = bitmapShader = new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                    this.mBitmapRect = new RectF(0.0f, 0.0f, (float)bitmap.getWidth(), (float)bitmap.getHeight());
                    this.paint = paint = new Paint();
                    paint.setAntiAlias(true);
                    paint.setShader((Shader)bitmapShader);
                    paint.setFilterBitmap(true);
                    paint.setDither(true);
                    if (n == null) {
                        this.strokePaint = null;
                    } else {
                        Paint paint2;
                        this.strokePaint = paint2 = new Paint();
                        paint2.setStyle(Paint.Style.STROKE);
                        paint2.setColor(n.intValue());
                        paint2.setStrokeWidth(f);
                        paint2.setAntiAlias(true);
                    }
                    this.strokeWidth = f;
                    this.strokeRadius = this.radius - f / 2.0f;
                }

                public void draw(Canvas canvas) {
                    float f = this.radius;
                    canvas.drawCircle(f, f, f, this.paint);
                    Paint paint = this.strokePaint;
                    if (paint != null) {
                        float f2 = this.radius;
                        canvas.drawCircle(f2, f2, this.strokeRadius, paint);
                    }
                }

                public int getOpacity() {
                    return -3;
                }

                protected void onBoundsChange(Rect rect) {
                    float f;
                    super.onBoundsChange(rect);
                    this.mRect.set(0.0f, 0.0f, (float)rect.width(), (float)rect.height());
                    this.radius = f = (float)(Math.min((int)rect.width(), (int)rect.height()) / 2);
                    this.strokeRadius = f - this.strokeWidth / 2.0f;
                    Matrix matrix = new Matrix();
                    matrix.setRectToRect(this.mBitmapRect, this.mRect, Matrix.ScaleToFit.FILL);
                    this.bitmapShader.setLocalMatrix(matrix);
                }

                public void setAlpha(int n) {
                    this.paint.setAlpha(n);
                }

                public void setColorFilter(ColorFilter colorFilter) {
                    this.paint.setColorFilter(colorFilter);
                }
            });
            return;
        }
        throw new IllegalArgumentException("ImageAware should wrap ImageView. ImageViewAware is expected.");
    }

}

