/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.io.IOException
 *  java.lang.Object
 */
package com.nostra13.universalimageloader.core.decode;

import android.graphics.Bitmap;
import com.nostra13.universalimageloader.core.decode.ImageDecodingInfo;
import java.io.IOException;

public interface ImageDecoder {
    public Bitmap decode(ImageDecodingInfo var1) throws IOException;
}

