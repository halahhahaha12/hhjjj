/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.Matrix
 *  java.io.Closeable
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 */
package com.nostra13.universalimageloader.core.decode;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.ImageSize;
import com.nostra13.universalimageloader.core.assist.ViewScaleType;
import com.nostra13.universalimageloader.core.decode.ImageDecoder;
import com.nostra13.universalimageloader.core.decode.ImageDecodingInfo;
import com.nostra13.universalimageloader.core.download.ImageDownloader;
import com.nostra13.universalimageloader.utils.ImageSizeUtils;
import com.nostra13.universalimageloader.utils.IoUtils;
import com.nostra13.universalimageloader.utils.L;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;

public class BaseImageDecoder
implements ImageDecoder {
    protected static final String ERROR_CANT_DECODE_IMAGE = "Image can't be decoded [%s]";
    protected static final String ERROR_NO_IMAGE_STREAM = "No stream for image [%s]";
    protected static final String LOG_FLIP_IMAGE = "Flip image horizontally [%s]";
    protected static final String LOG_ROTATE_IMAGE = "Rotate image on %1$d\u00b0 [%2$s]";
    protected static final String LOG_SCALE_IMAGE = "Scale subsampled image (%1$s) to %2$s (scale = %3$.5f) [%4$s]";
    protected static final String LOG_SUBSAMPLE_IMAGE = "Subsample original image (%1$s) to %2$s (scale = %3$d) [%4$s]";
    protected final boolean loggingEnabled;

    public BaseImageDecoder(boolean bl) {
        this.loggingEnabled = bl;
    }

    private boolean canDefineExifParams(String string2, String string3) {
        return "image/jpeg".equalsIgnoreCase(string3) && ImageDownloader.Scheme.ofUri(string2) == ImageDownloader.Scheme.FILE;
    }

    protected Bitmap considerExactScaleAndOrientatiton(Bitmap bitmap, ImageDecodingInfo imageDecodingInfo, int n, boolean bl) {
        boolean bl2;
        ViewScaleType viewScaleType;
        ImageSize imageSize;
        Bitmap bitmap2;
        ImageSize imageSize2;
        float f;
        Matrix matrix = new Matrix();
        ImageScaleType imageScaleType = imageDecodingInfo.getImageScaleType();
        if ((imageScaleType == ImageScaleType.EXACTLY || imageScaleType == ImageScaleType.EXACTLY_STRETCHED) && Float.compare((float)(f = ImageSizeUtils.computeImageScale(imageSize2 = new ImageSize(bitmap.getWidth(), bitmap.getHeight(), n), imageSize = imageDecodingInfo.getTargetSize(), viewScaleType = imageDecodingInfo.getViewScaleType(), bl2 = imageScaleType == ImageScaleType.EXACTLY_STRETCHED)), (float)1.0f) != 0) {
            matrix.setScale(f, f);
            if (this.loggingEnabled) {
                Object[] arrobject = new Object[]{imageSize2, imageSize2.scale(f), Float.valueOf((float)f), imageDecodingInfo.getImageKey()};
                L.d(LOG_SCALE_IMAGE, arrobject);
            }
        }
        if (bl) {
            matrix.postScale(-1.0f, 1.0f);
            if (this.loggingEnabled) {
                Object[] arrobject = new Object[]{imageDecodingInfo.getImageKey()};
                L.d(LOG_FLIP_IMAGE, arrobject);
            }
        }
        if (n != 0) {
            matrix.postRotate((float)n);
            if (this.loggingEnabled) {
                Object[] arrobject = new Object[]{n, imageDecodingInfo.getImageKey()};
                L.d(LOG_ROTATE_IMAGE, arrobject);
            }
        }
        if ((bitmap2 = Bitmap.createBitmap((Bitmap)bitmap, (int)0, (int)0, (int)bitmap.getWidth(), (int)bitmap.getHeight(), (Matrix)matrix, (boolean)true)) != bitmap) {
            bitmap.recycle();
        }
        return bitmap2;
    }

    @Override
    public Bitmap decode(ImageDecodingInfo imageDecodingInfo) throws IOException {
        Bitmap bitmap;
        InputStream inputStream;
        ImageFileInfo imageFileInfo;
        block4 : {
            inputStream = this.getImageStream(imageDecodingInfo);
            if (inputStream == null) {
                Object[] arrobject = new Object[]{imageDecodingInfo.getImageKey()};
                L.e(ERROR_NO_IMAGE_STREAM, arrobject);
                return null;
            }
            imageFileInfo = this.defineImageSizeAndRotation(inputStream, imageDecodingInfo);
            inputStream = this.resetStream(inputStream, imageDecodingInfo);
            bitmap = BitmapFactory.decodeStream((InputStream)inputStream, null, (BitmapFactory.Options)this.prepareDecodingOptions(imageFileInfo.imageSize, imageDecodingInfo));
            if (bitmap != null) break block4;
            Object[] arrobject = new Object[]{imageDecodingInfo.getImageKey()};
            L.e(ERROR_CANT_DECODE_IMAGE, arrobject);
            return bitmap;
        }
        return this.considerExactScaleAndOrientatiton(bitmap, imageDecodingInfo, imageFileInfo.exif.rotation, imageFileInfo.exif.flipHorizontal);
        finally {
            IoUtils.closeSilently((Closeable)inputStream);
        }
    }

    /*
     * Exception decompiling
     */
    protected ExifInfo defineExifOrientation(String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl51 : ICONST_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    protected ImageFileInfo defineImageSizeAndRotation(InputStream inputStream, ImageDecodingInfo imageDecodingInfo) throws IOException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream((InputStream)inputStream, null, (BitmapFactory.Options)options);
        String string2 = imageDecodingInfo.getImageUri();
        Object object = imageDecodingInfo.shouldConsiderExifParams() && this.canDefineExifParams(string2, options.outMimeType) ? this.defineExifOrientation(string2) : new Object(){
            public final boolean flipHorizontal;
            public final int rotation;
            {
                this.rotation = 0;
                this.flipHorizontal = false;
            }
            {
                this.rotation = n;
                this.flipHorizontal = bl;
            }
        };
        return new Object(new ImageSize(options.outWidth, options.outHeight, object.rotation), object){
            public final ExifInfo exif;
            public final ImageSize imageSize;
            {
                this.imageSize = imageSize;
                this.exif = exifInfo;
            }
        };
    }

    protected InputStream getImageStream(ImageDecodingInfo imageDecodingInfo) throws IOException {
        return imageDecodingInfo.getDownloader().getStream(imageDecodingInfo.getImageUri(), imageDecodingInfo.getExtraForDownloader());
    }

    protected BitmapFactory.Options prepareDecodingOptions(ImageSize imageSize, ImageDecodingInfo imageDecodingInfo) {
        int n;
        ImageScaleType imageScaleType = imageDecodingInfo.getImageScaleType();
        if (imageScaleType == ImageScaleType.NONE) {
            n = 1;
        } else if (imageScaleType == ImageScaleType.NONE_SAFE) {
            n = ImageSizeUtils.computeMinImageSampleSize(imageSize);
        } else {
            ImageSize imageSize2 = imageDecodingInfo.getTargetSize();
            boolean bl = imageScaleType == ImageScaleType.IN_SAMPLE_POWER_OF_2;
            n = ImageSizeUtils.computeImageSampleSize(imageSize, imageSize2, imageDecodingInfo.getViewScaleType(), bl);
        }
        if (n > 1 && this.loggingEnabled) {
            Object[] arrobject = new Object[]{imageSize, imageSize.scaleDown(n), n, imageDecodingInfo.getImageKey()};
            L.d(LOG_SUBSAMPLE_IMAGE, arrobject);
        }
        BitmapFactory.Options options = imageDecodingInfo.getDecodingOptions();
        options.inSampleSize = n;
        return options;
    }

    /*
     * Exception decompiling
     */
    protected InputStream resetStream(InputStream var1, ImageDecodingInfo var2) throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl8.1 : ALOAD_1 : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

}

