/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.view.View
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.nostra13.universalimageloader.core;

import android.graphics.Bitmap;
import android.view.View;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoaderEngine;
import com.nostra13.universalimageloader.core.ImageLoadingInfo;
import com.nostra13.universalimageloader.core.assist.LoadedFrom;
import com.nostra13.universalimageloader.core.display.BitmapDisplayer;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.utils.L;

final class DisplayBitmapTask
implements Runnable {
    private static final String LOG_DISPLAY_IMAGE_IN_IMAGEAWARE = "Display image in ImageAware (loaded from %1$s) [%2$s]";
    private static final String LOG_TASK_CANCELLED_IMAGEAWARE_COLLECTED = "ImageAware was collected by GC. Task is cancelled. [%s]";
    private static final String LOG_TASK_CANCELLED_IMAGEAWARE_REUSED = "ImageAware is reused for another image. Task is cancelled. [%s]";
    private final Bitmap bitmap;
    private final BitmapDisplayer displayer;
    private final ImageLoaderEngine engine;
    private final ImageAware imageAware;
    private final String imageUri;
    private final ImageLoadingListener listener;
    private final LoadedFrom loadedFrom;
    private final String memoryCacheKey;

    public DisplayBitmapTask(Bitmap bitmap, ImageLoadingInfo imageLoadingInfo, ImageLoaderEngine imageLoaderEngine, LoadedFrom loadedFrom) {
        this.bitmap = bitmap;
        this.imageUri = imageLoadingInfo.uri;
        this.imageAware = imageLoadingInfo.imageAware;
        this.memoryCacheKey = imageLoadingInfo.memoryCacheKey;
        this.displayer = imageLoadingInfo.options.getDisplayer();
        this.listener = imageLoadingInfo.listener;
        this.engine = imageLoaderEngine;
        this.loadedFrom = loadedFrom;
    }

    private boolean isViewWasReused() {
        String string2 = this.engine.getLoadingUriForView(this.imageAware);
        return true ^ this.memoryCacheKey.equals((Object)string2);
    }

    public void run() {
        if (this.imageAware.isCollected()) {
            Object[] arrobject = new Object[]{this.memoryCacheKey};
            L.d(LOG_TASK_CANCELLED_IMAGEAWARE_COLLECTED, arrobject);
            this.listener.onLoadingCancelled(this.imageUri, this.imageAware.getWrappedView());
            return;
        }
        if (this.isViewWasReused()) {
            Object[] arrobject = new Object[]{this.memoryCacheKey};
            L.d(LOG_TASK_CANCELLED_IMAGEAWARE_REUSED, arrobject);
            this.listener.onLoadingCancelled(this.imageUri, this.imageAware.getWrappedView());
            return;
        }
        Object[] arrobject = new Object[]{this.loadedFrom, this.memoryCacheKey};
        L.d(LOG_DISPLAY_IMAGE_IN_IMAGEAWARE, arrobject);
        this.displayer.display(this.bitmap, this.imageAware, this.loadedFrom);
        this.engine.cancelDisplayTaskFor(this.imageAware);
        this.listener.onLoadingComplete(this.imageUri, this.imageAware.getWrappedView(), this.bitmap);
    }
}

