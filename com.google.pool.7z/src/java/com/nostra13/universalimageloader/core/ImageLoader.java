/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.drawable.Drawable
 *  android.os.Handler
 *  android.os.Looper
 *  android.text.TextUtils
 *  android.view.View
 *  android.widget.ImageView
 *  com.nostra13.universalimageloader.core.ImageLoader$SyncImageLoadingListener
 *  com.nostra13.universalimageloader.core.LoadAndDisplayImageTask
 *  com.nostra13.universalimageloader.core.imageaware.ImageViewAware
 *  com.nostra13.universalimageloader.core.imageaware.NonViewAware
 *  com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.locks.ReentrantLock
 */
package com.nostra13.universalimageloader.core;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import com.nostra13.universalimageloader.cache.disc.DiskCache;
import com.nostra13.universalimageloader.cache.memory.MemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.ImageLoaderEngine;
import com.nostra13.universalimageloader.core.ImageLoadingInfo;
import com.nostra13.universalimageloader.core.LoadAndDisplayImageTask;
import com.nostra13.universalimageloader.core.ProcessAndDisplayImageTask;
import com.nostra13.universalimageloader.core.assist.ImageSize;
import com.nostra13.universalimageloader.core.assist.LoadedFrom;
import com.nostra13.universalimageloader.core.assist.ViewScaleType;
import com.nostra13.universalimageloader.core.display.BitmapDisplayer;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.nostra13.universalimageloader.core.imageaware.NonViewAware;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.ImageLoadingProgressListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;
import com.nostra13.universalimageloader.utils.ImageSizeUtils;
import com.nostra13.universalimageloader.utils.L;
import com.nostra13.universalimageloader.utils.MemoryCacheUtils;
import java.util.concurrent.locks.ReentrantLock;

/*
 * Exception performing whole class analysis.
 */
public class ImageLoader {
    private static final String ERROR_INIT_CONFIG_WITH_NULL = "ImageLoader configuration can not be initialized with null";
    private static final String ERROR_NOT_INIT = "ImageLoader must be init with configuration before using";
    private static final String ERROR_WRONG_ARGUMENTS = "Wrong arguments were passed to displayImage() method (ImageView reference must not be null)";
    static final String LOG_DESTROY = "Destroy ImageLoader";
    static final String LOG_INIT_CONFIG = "Initialize ImageLoader with configuration";
    static final String LOG_LOAD_IMAGE_FROM_MEMORY_CACHE = "Load image from memory cache [%s]";
    public static final String TAG = "ImageLoader";
    private static final String WARNING_RE_INIT_CONFIG = "Try to initialize ImageLoader which had already been initialized before. To re-init ImageLoader with new configuration call ImageLoader.destroy() at first.";
    private static volatile ImageLoader instance;
    private ImageLoaderConfiguration configuration;
    private ImageLoadingListener defaultListener;
    private ImageLoaderEngine engine;

    protected ImageLoader() {
        this.defaultListener = new SimpleImageLoadingListener();
    }

    private void checkConfiguration() {
        if (this.configuration != null) {
            return;
        }
        throw new IllegalStateException(ERROR_NOT_INIT);
    }

    private static Handler defineHandler(DisplayImageOptions displayImageOptions) {
        Handler handler = displayImageOptions.getHandler();
        if (displayImageOptions.isSyncLoading()) {
            return null;
        }
        if (handler == null && Looper.myLooper() == Looper.getMainLooper()) {
            handler = new Handler();
        }
        return handler;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static ImageLoader getInstance() {
        if (instance != null) return instance;
        Class<ImageLoader> class_ = ImageLoader.class;
        synchronized (ImageLoader.class) {
            if (instance != null) return instance;
            instance = new ImageLoader();
            // ** MonitorExit[var1] (shouldn't be in output)
            return instance;
        }
    }

    public void cancelDisplayTask(ImageView imageView) {
        this.engine.cancelDisplayTaskFor((ImageAware)new ImageViewAware(imageView));
    }

    public void cancelDisplayTask(ImageAware imageAware) {
        this.engine.cancelDisplayTaskFor(imageAware);
    }

    @Deprecated
    public void clearDiscCache() {
        this.clearDiskCache();
    }

    public void clearDiskCache() {
        this.checkConfiguration();
        this.configuration.diskCache.clear();
    }

    public void clearMemoryCache() {
        this.checkConfiguration();
        this.configuration.memoryCache.clear();
    }

    public void denyNetworkDownloads(boolean bl) {
        this.engine.denyNetworkDownloads(bl);
    }

    public void destroy() {
        if (this.configuration != null) {
            L.d(LOG_DESTROY, new Object[0]);
        }
        this.stop();
        this.configuration.diskCache.close();
        this.engine = null;
        this.configuration = null;
    }

    public void displayImage(String string2, ImageView imageView) {
        this.displayImage(string2, (ImageAware)new ImageViewAware(imageView), null, null, null);
    }

    public void displayImage(String string2, ImageView imageView, DisplayImageOptions displayImageOptions) {
        this.displayImage(string2, (ImageAware)new ImageViewAware(imageView), displayImageOptions, null, null);
    }

    public void displayImage(String string2, ImageView imageView, DisplayImageOptions displayImageOptions, ImageLoadingListener imageLoadingListener) {
        this.displayImage(string2, imageView, displayImageOptions, imageLoadingListener, null);
    }

    public void displayImage(String string2, ImageView imageView, DisplayImageOptions displayImageOptions, ImageLoadingListener imageLoadingListener, ImageLoadingProgressListener imageLoadingProgressListener) {
        this.displayImage(string2, (ImageAware)new ImageViewAware(imageView), displayImageOptions, imageLoadingListener, imageLoadingProgressListener);
    }

    public void displayImage(String string2, ImageView imageView, ImageSize imageSize) {
        this.displayImage(string2, (ImageAware)new ImageViewAware(imageView), null, imageSize, null, null);
    }

    public void displayImage(String string2, ImageView imageView, ImageLoadingListener imageLoadingListener) {
        this.displayImage(string2, (ImageAware)new ImageViewAware(imageView), null, imageLoadingListener, null);
    }

    public void displayImage(String string2, ImageAware imageAware) {
        this.displayImage(string2, imageAware, null, null, null);
    }

    public void displayImage(String string2, ImageAware imageAware, DisplayImageOptions displayImageOptions) {
        this.displayImage(string2, imageAware, displayImageOptions, null, null);
    }

    public void displayImage(String string2, ImageAware imageAware, DisplayImageOptions displayImageOptions, ImageSize imageSize, ImageLoadingListener imageLoadingListener, ImageLoadingProgressListener imageLoadingProgressListener) {
        this.checkConfiguration();
        if (imageAware != null) {
            if (imageLoadingListener == null) {
                imageLoadingListener = this.defaultListener;
            }
            ImageLoadingListener imageLoadingListener2 = imageLoadingListener;
            if (displayImageOptions == null) {
                displayImageOptions = this.configuration.defaultDisplayImageOptions;
            }
            if (TextUtils.isEmpty((CharSequence)string2)) {
                this.engine.cancelDisplayTaskFor(imageAware);
                imageLoadingListener2.onLoadingStarted(string2, imageAware.getWrappedView());
                if (displayImageOptions.shouldShowImageForEmptyUri()) {
                    imageAware.setImageDrawable(displayImageOptions.getImageForEmptyUri(this.configuration.resources));
                } else {
                    imageAware.setImageDrawable(null);
                }
                imageLoadingListener2.onLoadingComplete(string2, imageAware.getWrappedView(), null);
                return;
            }
            if (imageSize == null) {
                imageSize = ImageSizeUtils.defineTargetSizeForView(imageAware, this.configuration.getMaxImageSize());
            }
            ImageSize imageSize2 = imageSize;
            String string3 = MemoryCacheUtils.generateKey(string2, imageSize2);
            this.engine.prepareDisplayTaskFor(imageAware, string3);
            imageLoadingListener2.onLoadingStarted(string2, imageAware.getWrappedView());
            Bitmap bitmap = this.configuration.memoryCache.get(string3);
            if (bitmap != null && !bitmap.isRecycled()) {
                L.d(LOG_LOAD_IMAGE_FROM_MEMORY_CACHE, string3);
                if (displayImageOptions.shouldPostProcess()) {
                    ReentrantLock reentrantLock = this.engine.getLockForUri(string2);
                    ImageLoadingInfo imageLoadingInfo = new ImageLoadingInfo(string2, imageAware, imageSize2, string3, displayImageOptions, imageLoadingListener2, imageLoadingProgressListener, reentrantLock);
                    ProcessAndDisplayImageTask processAndDisplayImageTask = new ProcessAndDisplayImageTask(this.engine, bitmap, imageLoadingInfo, ImageLoader.defineHandler(displayImageOptions));
                    if (displayImageOptions.isSyncLoading()) {
                        processAndDisplayImageTask.run();
                        return;
                    }
                    this.engine.submit(processAndDisplayImageTask);
                    return;
                }
                displayImageOptions.getDisplayer().display(bitmap, imageAware, LoadedFrom.MEMORY_CACHE);
                imageLoadingListener2.onLoadingComplete(string2, imageAware.getWrappedView(), bitmap);
                return;
            }
            if (displayImageOptions.shouldShowImageOnLoading()) {
                imageAware.setImageDrawable(displayImageOptions.getImageOnLoading(this.configuration.resources));
            } else if (displayImageOptions.isResetViewBeforeLoading()) {
                imageAware.setImageDrawable(null);
            }
            ReentrantLock reentrantLock = this.engine.getLockForUri(string2);
            ImageLoadingInfo imageLoadingInfo = new ImageLoadingInfo(string2, imageAware, imageSize2, string3, displayImageOptions, imageLoadingListener2, imageLoadingProgressListener, reentrantLock);
            LoadAndDisplayImageTask loadAndDisplayImageTask = new LoadAndDisplayImageTask(this.engine, imageLoadingInfo, ImageLoader.defineHandler(displayImageOptions));
            if (displayImageOptions.isSyncLoading()) {
                loadAndDisplayImageTask.run();
                return;
            }
            this.engine.submit(loadAndDisplayImageTask);
            return;
        }
        throw new IllegalArgumentException(ERROR_WRONG_ARGUMENTS);
    }

    public void displayImage(String string2, ImageAware imageAware, DisplayImageOptions displayImageOptions, ImageLoadingListener imageLoadingListener) {
        this.displayImage(string2, imageAware, displayImageOptions, imageLoadingListener, null);
    }

    public void displayImage(String string2, ImageAware imageAware, DisplayImageOptions displayImageOptions, ImageLoadingListener imageLoadingListener, ImageLoadingProgressListener imageLoadingProgressListener) {
        this.displayImage(string2, imageAware, displayImageOptions, null, imageLoadingListener, imageLoadingProgressListener);
    }

    public void displayImage(String string2, ImageAware imageAware, ImageLoadingListener imageLoadingListener) {
        this.displayImage(string2, imageAware, null, imageLoadingListener, null);
    }

    @Deprecated
    public DiskCache getDiscCache() {
        return this.getDiskCache();
    }

    public DiskCache getDiskCache() {
        this.checkConfiguration();
        return this.configuration.diskCache;
    }

    public String getLoadingUriForView(ImageView imageView) {
        return this.engine.getLoadingUriForView((ImageAware)new ImageViewAware(imageView));
    }

    public String getLoadingUriForView(ImageAware imageAware) {
        return this.engine.getLoadingUriForView(imageAware);
    }

    public MemoryCache getMemoryCache() {
        this.checkConfiguration();
        return this.configuration.memoryCache;
    }

    public void handleSlowNetwork(boolean bl) {
        this.engine.handleSlowNetwork(bl);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void init(ImageLoaderConfiguration imageLoaderConfiguration) {
        ImageLoader imageLoader = this;
        synchronized (imageLoader) {
            Throwable throwable2;
            if (imageLoaderConfiguration != null) {
                try {
                    if (this.configuration == null) {
                        L.d(LOG_INIT_CONFIG, new Object[0]);
                        this.engine = new ImageLoaderEngine(imageLoaderConfiguration);
                        this.configuration = imageLoaderConfiguration;
                    } else {
                        L.w(WARNING_RE_INIT_CONFIG, new Object[0]);
                    }
                    return;
                }
                catch (Throwable throwable2) {}
            } else {
                throw new IllegalArgumentException(ERROR_INIT_CONFIG_WITH_NULL);
            }
            throw throwable2;
        }
    }

    public boolean isInited() {
        return this.configuration != null;
    }

    public void loadImage(String string2, DisplayImageOptions displayImageOptions, ImageLoadingListener imageLoadingListener) {
        this.loadImage(string2, null, displayImageOptions, imageLoadingListener, null);
    }

    public void loadImage(String string2, ImageSize imageSize, DisplayImageOptions displayImageOptions, ImageLoadingListener imageLoadingListener) {
        this.loadImage(string2, imageSize, displayImageOptions, imageLoadingListener, null);
    }

    public void loadImage(String string2, ImageSize imageSize, DisplayImageOptions displayImageOptions, ImageLoadingListener imageLoadingListener, ImageLoadingProgressListener imageLoadingProgressListener) {
        this.checkConfiguration();
        if (imageSize == null) {
            imageSize = this.configuration.getMaxImageSize();
        }
        if (displayImageOptions == null) {
            displayImageOptions = this.configuration.defaultDisplayImageOptions;
        }
        DisplayImageOptions displayImageOptions2 = displayImageOptions;
        this.displayImage(string2, (ImageAware)new NonViewAware(string2, imageSize, ViewScaleType.CROP), displayImageOptions2, imageLoadingListener, imageLoadingProgressListener);
    }

    public void loadImage(String string2, ImageSize imageSize, ImageLoadingListener imageLoadingListener) {
        this.loadImage(string2, imageSize, null, imageLoadingListener, null);
    }

    public void loadImage(String string2, ImageLoadingListener imageLoadingListener) {
        this.loadImage(string2, null, null, imageLoadingListener, null);
    }

    public Bitmap loadImageSync(String string2) {
        return this.loadImageSync(string2, null, null);
    }

    public Bitmap loadImageSync(String string2, DisplayImageOptions displayImageOptions) {
        return this.loadImageSync(string2, null, displayImageOptions);
    }

    public Bitmap loadImageSync(String string2, ImageSize imageSize) {
        return this.loadImageSync(string2, imageSize, null);
    }

    public Bitmap loadImageSync(String string2, ImageSize imageSize, DisplayImageOptions displayImageOptions) {
        if (displayImageOptions == null) {
            displayImageOptions = this.configuration.defaultDisplayImageOptions;
        }
        DisplayImageOptions displayImageOptions2 = new DisplayImageOptions.Builder().cloneFrom(displayImageOptions).syncLoading(true).build();
        SyncImageLoadingListener syncImageLoadingListener = new /* Unavailable Anonymous Inner Class!! */;
        this.loadImage(string2, imageSize, displayImageOptions2, (ImageLoadingListener)syncImageLoadingListener);
        return syncImageLoadingListener.getLoadedBitmap();
    }

    public void pause() {
        this.engine.pause();
    }

    public void resume() {
        this.engine.resume();
    }

    public void setDefaultLoadingListener(ImageLoadingListener imageLoadingListener) {
        if (imageLoadingListener == null) {
            imageLoadingListener = new SimpleImageLoadingListener();
        }
        this.defaultListener = imageLoadingListener;
    }

    public void stop() {
        this.engine.stop();
    }

}

