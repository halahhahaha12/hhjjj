/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.nostra13.universalimageloader.core.LoadAndDisplayImageTask
 *  java.io.File
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.WeakHashMap
 *  java.util.concurrent.Executor
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.atomic.AtomicBoolean
 *  java.util.concurrent.locks.ReentrantLock
 */
package com.nostra13.universalimageloader.core;

import com.nostra13.universalimageloader.cache.disc.DiskCache;
import com.nostra13.universalimageloader.core.DefaultConfigurationFactory;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.LoadAndDisplayImageTask;
import com.nostra13.universalimageloader.core.ProcessAndDisplayImageTask;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

class ImageLoaderEngine {
    private final Map<Integer, String> cacheKeysForImageAwares = Collections.synchronizedMap((Map)new HashMap());
    final ImageLoaderConfiguration configuration;
    private final AtomicBoolean networkDenied = new AtomicBoolean(false);
    private final Object pauseLock = new Object();
    private final AtomicBoolean paused = new AtomicBoolean(false);
    private final AtomicBoolean slowNetwork = new AtomicBoolean(false);
    private Executor taskDistributor;
    private Executor taskExecutor;
    private Executor taskExecutorForCachedImages;
    private final Map<String, ReentrantLock> uriLocks = new WeakHashMap();

    ImageLoaderEngine(ImageLoaderConfiguration imageLoaderConfiguration) {
        this.configuration = imageLoaderConfiguration;
        this.taskExecutor = imageLoaderConfiguration.taskExecutor;
        this.taskExecutorForCachedImages = imageLoaderConfiguration.taskExecutorForCachedImages;
        this.taskDistributor = DefaultConfigurationFactory.createTaskDistributor();
    }

    private Executor createTaskExecutor() {
        return DefaultConfigurationFactory.createExecutor(this.configuration.threadPoolSize, this.configuration.threadPriority, this.configuration.tasksProcessingType);
    }

    private void initExecutorsIfNeed() {
        if (!this.configuration.customExecutor && ((ExecutorService)this.taskExecutor).isShutdown()) {
            this.taskExecutor = this.createTaskExecutor();
        }
        if (!this.configuration.customExecutorForCachedImages && ((ExecutorService)this.taskExecutorForCachedImages).isShutdown()) {
            this.taskExecutorForCachedImages = this.createTaskExecutor();
        }
    }

    void cancelDisplayTaskFor(ImageAware imageAware) {
        this.cacheKeysForImageAwares.remove((Object)imageAware.getId());
    }

    void denyNetworkDownloads(boolean bl) {
        this.networkDenied.set(bl);
    }

    void fireCallback(Runnable runnable) {
        this.taskDistributor.execute(runnable);
    }

    String getLoadingUriForView(ImageAware imageAware) {
        return (String)this.cacheKeysForImageAwares.get((Object)imageAware.getId());
    }

    ReentrantLock getLockForUri(String string2) {
        ReentrantLock reentrantLock = (ReentrantLock)this.uriLocks.get((Object)string2);
        if (reentrantLock == null) {
            reentrantLock = new ReentrantLock();
            this.uriLocks.put((Object)string2, (Object)reentrantLock);
        }
        return reentrantLock;
    }

    AtomicBoolean getPause() {
        return this.paused;
    }

    Object getPauseLock() {
        return this.pauseLock;
    }

    void handleSlowNetwork(boolean bl) {
        this.slowNetwork.set(bl);
    }

    boolean isNetworkDenied() {
        return this.networkDenied.get();
    }

    boolean isSlowNetwork() {
        return this.slowNetwork.get();
    }

    void pause() {
        this.paused.set(true);
    }

    void prepareDisplayTaskFor(ImageAware imageAware, String string2) {
        this.cacheKeysForImageAwares.put((Object)imageAware.getId(), (Object)string2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void resume() {
        Object object;
        this.paused.set(false);
        Object object2 = object = this.pauseLock;
        synchronized (object2) {
            this.pauseLock.notifyAll();
            return;
        }
    }

    void stop() {
        if (!this.configuration.customExecutor) {
            ((ExecutorService)this.taskExecutor).shutdownNow();
        }
        if (!this.configuration.customExecutorForCachedImages) {
            ((ExecutorService)this.taskExecutorForCachedImages).shutdownNow();
        }
        this.cacheKeysForImageAwares.clear();
        this.uriLocks.clear();
    }

    void submit(final LoadAndDisplayImageTask loadAndDisplayImageTask) {
        this.taskDistributor.execute(new Runnable(){

            public void run() {
                File file = ImageLoaderEngine.this.configuration.diskCache.get(loadAndDisplayImageTask.getLoadingUri());
                boolean bl = file != null && file.exists();
                ImageLoaderEngine.this.initExecutorsIfNeed();
                if (bl) {
                    ImageLoaderEngine.this.taskExecutorForCachedImages.execute((Runnable)loadAndDisplayImageTask);
                    return;
                }
                ImageLoaderEngine.this.taskExecutor.execute((Runnable)loadAndDisplayImageTask);
            }
        });
    }

    void submit(ProcessAndDisplayImageTask processAndDisplayImageTask) {
        this.initExecutorsIfNeed();
        this.taskExecutorForCachedImages.execute((Runnable)processAndDisplayImageTask);
    }

}

