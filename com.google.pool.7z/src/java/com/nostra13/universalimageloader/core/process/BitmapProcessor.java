/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 */
package com.nostra13.universalimageloader.core.process;

import android.graphics.Bitmap;

public interface BitmapProcessor {
    public Bitmap process(Bitmap var1);
}

