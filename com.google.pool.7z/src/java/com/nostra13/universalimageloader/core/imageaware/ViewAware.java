/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.drawable.Drawable
 *  android.os.Looper
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.Reference
 *  java.lang.ref.WeakReference
 */
package com.nostra13.universalimageloader.core.imageaware;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import com.nostra13.universalimageloader.core.assist.ViewScaleType;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.utils.L;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

public abstract class ViewAware
implements ImageAware {
    public static final String WARN_CANT_SET_BITMAP = "Can't set a bitmap into view. You should call ImageLoader on UI thread for it.";
    public static final String WARN_CANT_SET_DRAWABLE = "Can't set a drawable into view. You should call ImageLoader on UI thread for it.";
    protected boolean checkActualViewSize;
    protected Reference<View> viewRef;

    public ViewAware(View view) {
        this(view, true);
    }

    public ViewAware(View view, boolean bl) {
        if (view != null) {
            this.viewRef = new WeakReference((Object)view);
            this.checkActualViewSize = bl;
            return;
        }
        throw new IllegalArgumentException("view must not be null");
    }

    @Override
    public int getHeight() {
        View view = (View)this.viewRef.get();
        int n = 0;
        if (view != null) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            boolean bl = this.checkActualViewSize;
            n = 0;
            if (bl) {
                n = 0;
                if (layoutParams != null) {
                    int n2 = layoutParams.height;
                    n = 0;
                    if (n2 != -2) {
                        n = view.getHeight();
                    }
                }
            }
            if (n <= 0 && layoutParams != null) {
                n = layoutParams.height;
            }
        }
        return n;
    }

    @Override
    public int getId() {
        View view = (View)this.viewRef.get();
        if (view == null) {
            return super.hashCode();
        }
        return view.hashCode();
    }

    @Override
    public ViewScaleType getScaleType() {
        return ViewScaleType.CROP;
    }

    @Override
    public int getWidth() {
        View view = (View)this.viewRef.get();
        int n = 0;
        if (view != null) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            boolean bl = this.checkActualViewSize;
            n = 0;
            if (bl) {
                n = 0;
                if (layoutParams != null) {
                    int n2 = layoutParams.width;
                    n = 0;
                    if (n2 != -2) {
                        n = view.getWidth();
                    }
                }
            }
            if (n <= 0 && layoutParams != null) {
                n = layoutParams.width;
            }
        }
        return n;
    }

    @Override
    public View getWrappedView() {
        return (View)this.viewRef.get();
    }

    @Override
    public boolean isCollected() {
        return this.viewRef.get() == null;
    }

    @Override
    public boolean setImageBitmap(Bitmap bitmap) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            View view = (View)this.viewRef.get();
            if (view != null) {
                this.setImageBitmapInto(bitmap, view);
                return true;
            }
        } else {
            L.w(WARN_CANT_SET_BITMAP, new Object[0]);
        }
        return false;
    }

    protected abstract void setImageBitmapInto(Bitmap var1, View var2);

    @Override
    public boolean setImageDrawable(Drawable drawable2) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            View view = (View)this.viewRef.get();
            if (view != null) {
                this.setImageDrawableInto(drawable2, view);
                return true;
            }
        } else {
            L.w("Can't set a drawable into view. You should call ImageLoader on UI thread for it.", new Object[0]);
        }
        return false;
    }

    protected abstract void setImageDrawableInto(Drawable var1, View var2);
}

