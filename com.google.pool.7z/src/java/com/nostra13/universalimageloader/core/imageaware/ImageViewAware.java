/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.drawable.AnimationDrawable
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.widget.ImageView
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.Reference
 *  java.lang.reflect.Field
 */
package com.nostra13.universalimageloader.core.imageaware;

import android.graphics.Bitmap;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import com.nostra13.universalimageloader.core.assist.ViewScaleType;
import com.nostra13.universalimageloader.core.imageaware.ViewAware;
import com.nostra13.universalimageloader.utils.L;
import java.lang.ref.Reference;
import java.lang.reflect.Field;

public class ImageViewAware
extends ViewAware {
    public ImageViewAware(ImageView imageView) {
        super((View)imageView);
    }

    public ImageViewAware(ImageView imageView, boolean bl) {
        super((View)imageView, bl);
    }

    private static int getImageViewFieldValue(Object object, String string2) {
        try {
            Field field = ImageView.class.getDeclaredField(string2);
            field.setAccessible(true);
            int n = (Integer)field.get(object);
            if (n > 0 && n < Integer.MAX_VALUE) {
                return n;
            }
        }
        catch (Exception exception) {
            L.e(exception);
        }
        return 0;
    }

    @Override
    public int getHeight() {
        ImageView imageView;
        int n = super.getHeight();
        if (n <= 0 && (imageView = (ImageView)this.viewRef.get()) != null) {
            n = ImageViewAware.getImageViewFieldValue((Object)imageView, "mMaxHeight");
        }
        return n;
    }

    @Override
    public ViewScaleType getScaleType() {
        ImageView imageView = (ImageView)this.viewRef.get();
        if (imageView != null) {
            return ViewScaleType.fromImageView(imageView);
        }
        return super.getScaleType();
    }

    @Override
    public int getWidth() {
        ImageView imageView;
        int n = super.getWidth();
        if (n <= 0 && (imageView = (ImageView)this.viewRef.get()) != null) {
            n = ImageViewAware.getImageViewFieldValue((Object)imageView, "mMaxWidth");
        }
        return n;
    }

    public ImageView getWrappedView() {
        return (ImageView)super.getWrappedView();
    }

    @Override
    protected void setImageBitmapInto(Bitmap bitmap, View view) {
        ((ImageView)view).setImageBitmap(bitmap);
    }

    @Override
    protected void setImageDrawableInto(Drawable drawable2, View view) {
        ((ImageView)view).setImageDrawable(drawable2);
        if (drawable2 instanceof AnimationDrawable) {
            ((AnimationDrawable)drawable2).start();
        }
    }
}

