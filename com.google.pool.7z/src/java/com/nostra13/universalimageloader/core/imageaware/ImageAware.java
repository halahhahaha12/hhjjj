/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  java.lang.Object
 */
package com.nostra13.universalimageloader.core.imageaware;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.View;
import com.nostra13.universalimageloader.core.assist.ViewScaleType;

public interface ImageAware {
    public int getHeight();

    public int getId();

    public ViewScaleType getScaleType();

    public int getWidth();

    public View getWrappedView();

    public boolean isCollected();

    public boolean setImageBitmap(Bitmap var1);

    public boolean setImageDrawable(Drawable var1);
}

