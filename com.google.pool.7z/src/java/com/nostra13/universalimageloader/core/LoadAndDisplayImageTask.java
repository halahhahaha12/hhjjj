/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.os.Handler
 *  java.io.Closeable
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Exception
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.concurrent.atomic.AtomicBoolean
 *  java.util.concurrent.locks.ReentrantLock
 */
package com.nostra13.universalimageloader.core;

import android.graphics.Bitmap;
import android.os.Handler;
import com.nostra13.universalimageloader.cache.disc.DiskCache;
import com.nostra13.universalimageloader.cache.memory.MemoryCache;
import com.nostra13.universalimageloader.core.DisplayBitmapTask;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.ImageLoaderEngine;
import com.nostra13.universalimageloader.core.ImageLoadingInfo;
import com.nostra13.universalimageloader.core.LoadAndDisplayImageTask;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.ImageSize;
import com.nostra13.universalimageloader.core.assist.LoadedFrom;
import com.nostra13.universalimageloader.core.assist.ViewScaleType;
import com.nostra13.universalimageloader.core.decode.ImageDecoder;
import com.nostra13.universalimageloader.core.decode.ImageDecodingInfo;
import com.nostra13.universalimageloader.core.download.ImageDownloader;
import com.nostra13.universalimageloader.core.imageaware.ImageAware;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.ImageLoadingProgressListener;
import com.nostra13.universalimageloader.core.process.BitmapProcessor;
import com.nostra13.universalimageloader.utils.IoUtils;
import com.nostra13.universalimageloader.utils.L;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

final class LoadAndDisplayImageTask
implements Runnable,
IoUtils.CopyListener {
    private static final String ERROR_NO_IMAGE_STREAM = "No stream for image [%s]";
    private static final String ERROR_POST_PROCESSOR_NULL = "Post-processor returned null [%s]";
    private static final String ERROR_PRE_PROCESSOR_NULL = "Pre-processor returned null [%s]";
    private static final String ERROR_PROCESSOR_FOR_DISK_CACHE_NULL = "Bitmap processor for disk cache returned null [%s]";
    private static final String LOG_CACHE_IMAGE_IN_MEMORY = "Cache image in memory [%s]";
    private static final String LOG_CACHE_IMAGE_ON_DISK = "Cache image on disk [%s]";
    private static final String LOG_DELAY_BEFORE_LOADING = "Delay %d ms before loading...  [%s]";
    private static final String LOG_GET_IMAGE_FROM_MEMORY_CACHE_AFTER_WAITING = "...Get cached bitmap from memory after waiting. [%s]";
    private static final String LOG_LOAD_IMAGE_FROM_DISK_CACHE = "Load image from disk cache [%s]";
    private static final String LOG_LOAD_IMAGE_FROM_NETWORK = "Load image from network [%s]";
    private static final String LOG_POSTPROCESS_IMAGE = "PostProcess image before displaying [%s]";
    private static final String LOG_PREPROCESS_IMAGE = "PreProcess image before caching in memory [%s]";
    private static final String LOG_PROCESS_IMAGE_BEFORE_CACHE_ON_DISK = "Process image before cache on disk [%s]";
    private static final String LOG_RESIZE_CACHED_IMAGE_FILE = "Resize image in disk cache [%s]";
    private static final String LOG_RESUME_AFTER_PAUSE = ".. Resume loading [%s]";
    private static final String LOG_START_DISPLAY_IMAGE_TASK = "Start display image task [%s]";
    private static final String LOG_TASK_CANCELLED_IMAGEAWARE_COLLECTED = "ImageAware was collected by GC. Task is cancelled. [%s]";
    private static final String LOG_TASK_CANCELLED_IMAGEAWARE_REUSED = "ImageAware is reused for another image. Task is cancelled. [%s]";
    private static final String LOG_TASK_INTERRUPTED = "Task was interrupted [%s]";
    private static final String LOG_WAITING_FOR_IMAGE_LOADED = "Image already is loading. Waiting... [%s]";
    private static final String LOG_WAITING_FOR_RESUME = "ImageLoader is paused. Waiting...  [%s]";
    private final ImageLoaderConfiguration configuration;
    private final ImageDecoder decoder;
    private final ImageDownloader downloader;
    private final ImageLoaderEngine engine;
    private final Handler handler;
    final ImageAware imageAware;
    private final ImageLoadingInfo imageLoadingInfo;
    final ImageLoadingListener listener;
    private LoadedFrom loadedFrom = LoadedFrom.NETWORK;
    private final String memoryCacheKey;
    private final ImageDownloader networkDeniedDownloader;
    final DisplayImageOptions options;
    final ImageLoadingProgressListener progressListener;
    private final ImageDownloader slowNetworkDownloader;
    private final boolean syncLoading;
    private final ImageSize targetSize;
    final String uri;

    public LoadAndDisplayImageTask(ImageLoaderEngine imageLoaderEngine, ImageLoadingInfo imageLoadingInfo, Handler handler) {
        ImageLoaderConfiguration imageLoaderConfiguration;
        DisplayImageOptions displayImageOptions;
        this.engine = imageLoaderEngine;
        this.imageLoadingInfo = imageLoadingInfo;
        this.handler = handler;
        this.configuration = imageLoaderConfiguration = imageLoaderEngine.configuration;
        this.downloader = imageLoaderConfiguration.downloader;
        this.networkDeniedDownloader = imageLoaderConfiguration.networkDeniedDownloader;
        this.slowNetworkDownloader = imageLoaderConfiguration.slowNetworkDownloader;
        this.decoder = imageLoaderConfiguration.decoder;
        this.uri = imageLoadingInfo.uri;
        this.memoryCacheKey = imageLoadingInfo.memoryCacheKey;
        this.imageAware = imageLoadingInfo.imageAware;
        this.targetSize = imageLoadingInfo.targetSize;
        this.options = displayImageOptions = imageLoadingInfo.options;
        this.listener = imageLoadingInfo.listener;
        this.progressListener = imageLoadingInfo.progressListener;
        this.syncLoading = displayImageOptions.isSyncLoading();
    }

    static /* synthetic */ ImageLoaderConfiguration access$000(LoadAndDisplayImageTask loadAndDisplayImageTask) {
        return loadAndDisplayImageTask.configuration;
    }

    private void checkTaskInterrupted() throws TaskCancelledException {
        if (!this.isTaskInterrupted()) {
            return;
        }
        throw new Exception(){};
    }

    private void checkTaskNotActual() throws TaskCancelledException {
        this.checkViewCollected();
        this.checkViewReused();
    }

    private void checkViewCollected() throws TaskCancelledException {
        if (!this.isViewCollected()) {
            return;
        }
        throw new /* invalid duplicate definition of identical inner class */;
    }

    private void checkViewReused() throws TaskCancelledException {
        if (!this.isViewReused()) {
            return;
        }
        throw new /* invalid duplicate definition of identical inner class */;
    }

    private Bitmap decodeImage(String string2) throws IOException {
        ViewScaleType viewScaleType = this.imageAware.getScaleType();
        ImageDecodingInfo imageDecodingInfo = new ImageDecodingInfo(this.memoryCacheKey, string2, this.uri, this.targetSize, viewScaleType, this.getDownloader(), this.options);
        return this.decoder.decode(imageDecodingInfo);
    }

    private boolean delayIfNeed() {
        if (this.options.shouldDelayBeforeLoading()) {
            Object[] arrobject = new Object[]{this.options.getDelayBeforeLoading(), this.memoryCacheKey};
            L.d(LOG_DELAY_BEFORE_LOADING, arrobject);
            try {
                Thread.sleep((long)this.options.getDelayBeforeLoading());
            }
            catch (InterruptedException interruptedException) {
                Object[] arrobject2 = new Object[]{this.memoryCacheKey};
                L.e(LOG_TASK_INTERRUPTED, arrobject2);
                return true;
            }
            return this.isTaskNotActual();
        }
        return false;
    }

    private boolean downloadImage() throws IOException {
        InputStream inputStream = this.getDownloader().getStream(this.uri, this.options.getExtraForDownloader());
        if (inputStream == null) {
            Object[] arrobject = new Object[]{this.memoryCacheKey};
            L.e(ERROR_NO_IMAGE_STREAM, arrobject);
            return false;
        }
        try {
            boolean bl = this.configuration.diskCache.save(this.uri, inputStream, this);
            return bl;
        }
        finally {
            IoUtils.closeSilently((Closeable)inputStream);
        }
    }

    private void fireCancelEvent() {
        if (!this.syncLoading) {
            if (this.isTaskInterrupted()) {
                return;
            }
            LoadAndDisplayImageTask.runTask(new Runnable(this){
                final /* synthetic */ LoadAndDisplayImageTask this$0;
                {
                    this.this$0 = loadAndDisplayImageTask;
                }

                public void run() {
                    this.this$0.listener.onLoadingCancelled(this.this$0.uri, this.this$0.imageAware.getWrappedView());
                }
            }, false, this.handler, this.engine);
        }
    }

    private void fireFailEvent(FailReason.FailType failType, Throwable throwable) {
        if (!this.syncLoading && !this.isTaskInterrupted()) {
            if (this.isTaskNotActual()) {
                return;
            }
            LoadAndDisplayImageTask.runTask(new Runnable(this, failType, throwable){
                final /* synthetic */ LoadAndDisplayImageTask this$0;
                final /* synthetic */ Throwable val$failCause;
                final /* synthetic */ FailReason.FailType val$failType;
                {
                    this.this$0 = loadAndDisplayImageTask;
                    this.val$failType = failType;
                    this.val$failCause = throwable;
                }

                public void run() {
                    if (this.this$0.options.shouldShowImageOnFail()) {
                        this.this$0.imageAware.setImageDrawable(this.this$0.options.getImageOnFail(LoadAndDisplayImageTask.access$000((LoadAndDisplayImageTask)this.this$0).resources));
                    }
                    this.this$0.listener.onLoadingFailed(this.this$0.uri, this.this$0.imageAware.getWrappedView(), new FailReason(this.val$failType, this.val$failCause));
                }
            }, false, this.handler, this.engine);
        }
    }

    private boolean fireProgressEvent(int n, int n2) {
        if (!this.isTaskInterrupted()) {
            if (this.isTaskNotActual()) {
                return false;
            }
            if (this.progressListener != null) {
                LoadAndDisplayImageTask.runTask(new Runnable(this, n, n2){
                    final /* synthetic */ LoadAndDisplayImageTask this$0;
                    final /* synthetic */ int val$current;
                    final /* synthetic */ int val$total;
                    {
                        this.this$0 = loadAndDisplayImageTask;
                        this.val$current = n;
                        this.val$total = n2;
                    }

                    public void run() {
                        this.this$0.progressListener.onProgressUpdate(this.this$0.uri, this.this$0.imageAware.getWrappedView(), this.val$current, this.val$total);
                    }
                }, false, this.handler, this.engine);
            }
            return true;
        }
        return false;
    }

    private ImageDownloader getDownloader() {
        if (this.engine.isNetworkDenied()) {
            return this.networkDeniedDownloader;
        }
        if (this.engine.isSlowNetwork()) {
            return this.slowNetworkDownloader;
        }
        return this.downloader;
    }

    private boolean isTaskInterrupted() {
        if (Thread.interrupted()) {
            Object[] arrobject = new Object[]{this.memoryCacheKey};
            L.d(LOG_TASK_INTERRUPTED, arrobject);
            return true;
        }
        return false;
    }

    private boolean isTaskNotActual() {
        return this.isViewCollected() || this.isViewReused();
        {
        }
    }

    private boolean isViewCollected() {
        if (this.imageAware.isCollected()) {
            Object[] arrobject = new Object[]{this.memoryCacheKey};
            L.d(LOG_TASK_CANCELLED_IMAGEAWARE_COLLECTED, arrobject);
            return true;
        }
        return false;
    }

    private boolean isViewReused() {
        String string2 = this.engine.getLoadingUriForView(this.imageAware);
        if (true ^ this.memoryCacheKey.equals((Object)string2)) {
            Object[] arrobject = new Object[]{this.memoryCacheKey};
            L.d(LOG_TASK_CANCELLED_IMAGEAWARE_REUSED, arrobject);
            return true;
        }
        return false;
    }

    private boolean resizeAndSaveImage(int n, int n2) throws IOException {
        File file = this.configuration.diskCache.get(this.uri);
        boolean bl = false;
        if (file != null) {
            boolean bl2 = file.exists();
            bl = false;
            if (bl2) {
                ImageSize imageSize = new ImageSize(n, n2);
                DisplayImageOptions displayImageOptions = new DisplayImageOptions.Builder().cloneFrom(this.options).imageScaleType(ImageScaleType.IN_SAMPLE_INT).build();
                ImageDecodingInfo imageDecodingInfo = new ImageDecodingInfo(this.memoryCacheKey, ImageDownloader.Scheme.FILE.wrap(file.getAbsolutePath()), this.uri, imageSize, ViewScaleType.FIT_INSIDE, this.getDownloader(), displayImageOptions);
                Bitmap bitmap = this.decoder.decode(imageDecodingInfo);
                if (bitmap != null && this.configuration.processorForDiskCache != null) {
                    Object[] arrobject = new Object[]{this.memoryCacheKey};
                    L.d(LOG_PROCESS_IMAGE_BEFORE_CACHE_ON_DISK, arrobject);
                    bitmap = this.configuration.processorForDiskCache.process(bitmap);
                    if (bitmap == null) {
                        Object[] arrobject2 = new Object[]{this.memoryCacheKey};
                        L.e(ERROR_PROCESSOR_FOR_DISK_CACHE_NULL, arrobject2);
                    }
                }
                bl = false;
                if (bitmap != null) {
                    bl = this.configuration.diskCache.save(this.uri, bitmap);
                    bitmap.recycle();
                }
            }
        }
        return bl;
    }

    static void runTask(Runnable runnable, boolean bl, Handler handler, ImageLoaderEngine imageLoaderEngine) {
        if (bl) {
            runnable.run();
            return;
        }
        if (handler == null) {
            imageLoaderEngine.fireCallback(runnable);
            return;
        }
        handler.post(runnable);
    }

    private boolean tryCacheImageOnDisk() throws TaskCancelledException {
        boolean bl;
        block4 : {
            Object[] arrobject = new Object[]{this.memoryCacheKey};
            L.d(LOG_CACHE_IMAGE_ON_DISK, arrobject);
            try {
                bl = this.downloadImage();
                if (!bl) break block4;
            }
            catch (IOException iOException) {
                L.e(iOException);
                return false;
            }
            int n = this.configuration.maxImageWidthForDiskCache;
            int n2 = this.configuration.maxImageHeightForDiskCache;
            if (n <= 0 && n2 <= 0) break block4;
            Object[] arrobject2 = new Object[]{this.memoryCacheKey};
            L.d(LOG_RESIZE_CACHED_IMAGE_FILE, arrobject2);
            this.resizeAndSaveImage(n, n2);
        }
        return bl;
    }

    /*
     * Exception decompiling
     */
    private Bitmap tryLoadBitmap() throws TaskCancelledException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl168 : ALOAD_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean waitIfPaused() {
        Object object;
        AtomicBoolean atomicBoolean = this.engine.getPause();
        if (!atomicBoolean.get()) return this.isTaskNotActual();
        Object object2 = object = this.engine.getPauseLock();
        synchronized (object2) {
            if (!atomicBoolean.get()) return this.isTaskNotActual();
            Object[] arrobject = new Object[]{this.memoryCacheKey};
            L.d(LOG_WAITING_FOR_RESUME, arrobject);
            try {
                this.engine.getPauseLock().wait();
            }
            catch (InterruptedException interruptedException) {
                Object[] arrobject2 = new Object[]{this.memoryCacheKey};
                L.e(LOG_TASK_INTERRUPTED, arrobject2);
                return true;
            }
            Object[] arrobject3 = new Object[]{this.memoryCacheKey};
            L.d(LOG_RESUME_AFTER_PAUSE, arrobject3);
            return this.isTaskNotActual();
        }
    }

    String getLoadingUri() {
        return this.uri;
    }

    @Override
    public boolean onBytesCopied(int n, int n2) {
        return this.syncLoading || this.fireProgressEvent(n, n2);
        {
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void run() {
        block14 : {
            block13 : {
                block15 : {
                    if (this.waitIfPaused()) {
                        return;
                    }
                    if (this.delayIfNeed()) {
                        return;
                    }
                    var1_1 = this.imageLoadingInfo.loadFromUriLock;
                    var2_2 = new Object[]{this.memoryCacheKey};
                    L.d("Start display image task [%s]", var2_2);
                    if (var1_1.isLocked()) {
                        var12_3 = new Object[]{this.memoryCacheKey};
                        L.d("Image already is loading. Waiting... [%s]", var12_3);
                    }
                    var1_1.lock();
                    this.checkTaskNotActual();
                    var4_4 = this.configuration.memoryCache.get(this.memoryCacheKey);
                    if (var4_4 == null || var4_4.isRecycled()) break block15;
                    this.loadedFrom = LoadedFrom.MEMORY_CACHE;
                    var11_5 = new Object[]{this.memoryCacheKey};
                    L.d("...Get cached bitmap from memory after waiting. [%s]", var11_5);
                    ** GOTO lbl40
                }
                var4_4 = this.tryLoadBitmap();
                if (var4_4 != null) break block13;
                var1_1.unlock();
                return;
            }
            this.checkTaskNotActual();
            this.checkTaskInterrupted();
            if (this.options.shouldPreProcess()) {
                var9_6 = new Object[]{this.memoryCacheKey};
                L.d("PreProcess image before caching in memory [%s]", var9_6);
                var4_4 = this.options.getPreProcessor().process(var4_4);
                if (var4_4 == null) {
                    var10_7 = new Object[]{this.memoryCacheKey};
                    L.e("Pre-processor returned null [%s]", var10_7);
                }
            }
            if (var4_4 != null && this.options.isCacheInMemory()) {
                var7_8 = new Object[]{this.memoryCacheKey};
                L.d("Cache image in memory [%s]", var7_8);
                this.configuration.memoryCache.put(this.memoryCacheKey, var4_4);
            }
lbl40: // 4 sources:
            if (var4_4 != null && this.options.shouldPostProcess()) {
                var5_9 = new Object[]{this.memoryCacheKey};
                L.d("PostProcess image before displaying [%s]", var5_9);
                var4_4 = this.options.getPostProcessor().process(var4_4);
                if (var4_4 == null) {
                    var6_10 = new Object[]{this.memoryCacheKey};
                    L.e("Post-processor returned null [%s]", var6_10);
                }
            }
            this.checkTaskNotActual();
            this.checkTaskInterrupted();
            var1_1.unlock();
            LoadAndDisplayImageTask.runTask(new DisplayBitmapTask(var4_4, this.imageLoadingInfo, this.engine, this.loadedFrom), this.syncLoading, this.handler, this.engine);
            return;
            {
                catch (Throwable var3_11) {
                    break block14;
                }
                catch (TaskCancelledException v0) {}
                {
                    this.fireCancelEvent();
                }
                var1_1.unlock();
                return;
            }
        }
        var1_1.unlock();
        throw var3_11;
    }

}

