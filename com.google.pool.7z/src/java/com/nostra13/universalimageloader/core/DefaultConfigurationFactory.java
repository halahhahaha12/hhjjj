/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiskCache
 *  com.nostra13.universalimageloader.cache.disc.impl.ext.LruDiskCache
 *  com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator
 *  com.nostra13.universalimageloader.cache.memory.impl.LruMemoryCache
 *  com.nostra13.universalimageloader.core.assist.deque.LIFOLinkedBlockingDeque
 *  com.nostra13.universalimageloader.core.decode.BaseImageDecoder
 *  com.nostra13.universalimageloader.core.display.SimpleBitmapDisplayer
 *  com.nostra13.universalimageloader.core.download.BaseImageDownloader
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.ThreadGroup
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.Executor
 *  java.util.concurrent.Executors
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.ThreadFactory
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 *  java.util.concurrent.atomic.AtomicInteger
 */
package com.nostra13.universalimageloader.core;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import com.nostra13.universalimageloader.cache.disc.DiskCache;
import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiskCache;
import com.nostra13.universalimageloader.cache.disc.impl.ext.LruDiskCache;
import com.nostra13.universalimageloader.cache.disc.naming.FileNameGenerator;
import com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.MemoryCache;
import com.nostra13.universalimageloader.cache.memory.impl.LruMemoryCache;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.assist.deque.LIFOLinkedBlockingDeque;
import com.nostra13.universalimageloader.core.decode.BaseImageDecoder;
import com.nostra13.universalimageloader.core.decode.ImageDecoder;
import com.nostra13.universalimageloader.core.display.BitmapDisplayer;
import com.nostra13.universalimageloader.core.display.SimpleBitmapDisplayer;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;
import com.nostra13.universalimageloader.core.download.ImageDownloader;
import com.nostra13.universalimageloader.utils.L;
import com.nostra13.universalimageloader.utils.StorageUtils;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class DefaultConfigurationFactory {
    public static BitmapDisplayer createBitmapDisplayer() {
        return new SimpleBitmapDisplayer();
    }

    public static DiskCache createDiskCache(Context context, FileNameGenerator fileNameGenerator, long l, int n) {
        File file = DefaultConfigurationFactory.createReserveDiskCacheDir(context);
        if (l > 0L || n > 0) {
            File file2 = StorageUtils.getIndividualCacheDirectory(context);
            try {
                LruDiskCache lruDiskCache = new LruDiskCache(file2, file, fileNameGenerator, l, n);
                return lruDiskCache;
            }
            catch (IOException iOException) {
                L.e(iOException);
            }
        }
        return new UnlimitedDiskCache(StorageUtils.getCacheDirectory(context), file, fileNameGenerator);
    }

    public static Executor createExecutor(int n, int n2, QueueProcessingType queueProcessingType) {
        boolean bl = queueProcessingType == QueueProcessingType.LIFO;
        Object object = bl ? new LIFOLinkedBlockingDeque() : new LinkedBlockingQueue();
        BlockingQueue blockingQueue = (BlockingQueue)object;
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(n, n, 0L, TimeUnit.MILLISECONDS, blockingQueue, DefaultConfigurationFactory.createThreadFactory(n2, "uil-pool-"));
        return threadPoolExecutor;
    }

    public static FileNameGenerator createFileNameGenerator() {
        return new HashCodeFileNameGenerator();
    }

    public static ImageDecoder createImageDecoder(boolean bl) {
        return new BaseImageDecoder(bl);
    }

    public static ImageDownloader createImageDownloader(Context context) {
        return new BaseImageDownloader(context);
    }

    public static MemoryCache createMemoryCache(Context context, int n) {
        if (n == 0) {
            ActivityManager activityManager = (ActivityManager)context.getSystemService("activity");
            int n2 = activityManager.getMemoryClass();
            if (DefaultConfigurationFactory.hasHoneycomb() && DefaultConfigurationFactory.isLargeHeap(context)) {
                n2 = DefaultConfigurationFactory.getLargeMemoryClass(activityManager);
            }
            n = n2 * 1048576 / 8;
        }
        return new LruMemoryCache(n);
    }

    private static File createReserveDiskCacheDir(Context context) {
        File file = StorageUtils.getCacheDirectory(context, false);
        File file2 = new File(file, "uil-images");
        if (file2.exists() || file2.mkdir()) {
            file = file2;
        }
        return file;
    }

    public static Executor createTaskDistributor() {
        return Executors.newCachedThreadPool((ThreadFactory)DefaultConfigurationFactory.createThreadFactory(5, "uil-pool-d-"));
    }

    private static ThreadFactory createThreadFactory(int n, String string2) {
        return new DefaultThreadFactory(n, string2);
    }

    private static int getLargeMemoryClass(ActivityManager activityManager) {
        return activityManager.getLargeMemoryClass();
    }

    private static boolean hasHoneycomb() {
        return Build.VERSION.SDK_INT >= 11;
    }

    private static boolean isLargeHeap(Context context) {
        return (1048576 & context.getApplicationInfo().flags) != 0;
    }

    private static class DefaultThreadFactory
    implements ThreadFactory {
        private static final AtomicInteger poolNumber = new AtomicInteger(1);
        private final ThreadGroup group;
        private final String namePrefix;
        private final AtomicInteger threadNumber = new AtomicInteger(1);
        private final int threadPriority;

        DefaultThreadFactory(int n, String string2) {
            this.threadPriority = n;
            this.group = Thread.currentThread().getThreadGroup();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(poolNumber.getAndIncrement());
            stringBuilder.append("-thread-");
            this.namePrefix = stringBuilder.toString();
        }

        public Thread newThread(Runnable runnable) {
            ThreadGroup threadGroup = this.group;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.namePrefix);
            stringBuilder.append(this.threadNumber.getAndIncrement());
            Thread thread = new Thread(threadGroup, runnable, stringBuilder.toString(), 0L);
            if (thread.isDaemon()) {
                thread.setDaemon(false);
            }
            thread.setPriority(this.threadPriority);
            return thread;
        }
    }

}

