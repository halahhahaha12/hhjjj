/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.media.ThumbnailUtils
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.provider.ContactsContract
 *  android.provider.ContactsContract$Contacts
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Video
 *  android.provider.MediaStore$Video$Thumbnails
 *  android.webkit.MimeTypeMap
 *  java.io.BufferedInputStream
 *  java.io.ByteArrayInputStream
 *  java.io.ByteArrayOutputStream
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.UnsupportedOperationException
 *  java.net.HttpURLConnection
 *  java.net.URL
 *  java.net.URLConnection
 */
package com.nostra13.universalimageloader.core.download;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import com.nostra13.universalimageloader.core.assist.ContentLengthInputStream;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;
import com.nostra13.universalimageloader.core.download.ImageDownloader;
import com.nostra13.universalimageloader.utils.IoUtils;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class BaseImageDownloader
implements ImageDownloader {
    protected static final String ALLOWED_URI_CHARS = "@#&=*+-_.,:!?()/~'%";
    protected static final int BUFFER_SIZE = 32768;
    protected static final String CONTENT_CONTACTS_URI_PREFIX = "content://com.android.contacts/";
    public static final int DEFAULT_HTTP_CONNECT_TIMEOUT = 5000;
    public static final int DEFAULT_HTTP_READ_TIMEOUT = 20000;
    private static final String ERROR_UNSUPPORTED_SCHEME = "UIL doesn't support scheme(protocol) by default [%s]. You should implement this support yourself (BaseImageDownloader.getStreamFromOtherSource(...))";
    protected static final int MAX_REDIRECT_COUNT = 5;
    protected final int connectTimeout;
    protected final Context context;
    protected final int readTimeout;

    public BaseImageDownloader(Context context) {
        this(context, 5000, 20000);
    }

    public BaseImageDownloader(Context context, int n, int n2) {
        this.context = context.getApplicationContext();
        this.connectTimeout = n;
        this.readTimeout = n2;
    }

    private InputStream getVideoThumbnailStream(String string2) {
        Bitmap bitmap;
        if (Build.VERSION.SDK_INT >= 8 && (bitmap = ThumbnailUtils.createVideoThumbnail((String)string2, (int)2)) != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 0, (OutputStream)byteArrayOutputStream);
            return new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
        }
        return null;
    }

    private boolean isVideoContentUri(Uri uri) {
        String string2 = this.context.getContentResolver().getType(uri);
        return string2 != null && string2.startsWith("video/");
    }

    private boolean isVideoFileUri(String string2) {
        String string3 = MimeTypeMap.getFileExtensionFromUrl((String)string2);
        String string4 = MimeTypeMap.getSingleton().getMimeTypeFromExtension(string3);
        return string4 != null && string4.startsWith("video/");
    }

    protected HttpURLConnection createConnection(String string2, Object object) throws IOException {
        HttpURLConnection httpURLConnection = (HttpURLConnection)new URL(Uri.encode((String)string2, (String)ALLOWED_URI_CHARS)).openConnection();
        httpURLConnection.setConnectTimeout(this.connectTimeout);
        httpURLConnection.setReadTimeout(this.readTimeout);
        return httpURLConnection;
    }

    protected InputStream getContactPhotoStream(Uri uri) {
        ContentResolver contentResolver = this.context.getContentResolver();
        if (Build.VERSION.SDK_INT >= 14) {
            return ContactsContract.Contacts.openContactPhotoInputStream((ContentResolver)contentResolver, (Uri)uri, (boolean)true);
        }
        return ContactsContract.Contacts.openContactPhotoInputStream((ContentResolver)contentResolver, (Uri)uri);
    }

    @Override
    public InputStream getStream(String string2, Object object) throws IOException {
        switch (1.$SwitchMap$com$nostra13$universalimageloader$core$download$ImageDownloader$Scheme[ImageDownloader.Scheme.ofUri(string2).ordinal()]) {
            default: {
                return this.getStreamFromOtherSource(string2, object);
            }
            case 6: {
                return this.getStreamFromDrawable(string2, object);
            }
            case 5: {
                return this.getStreamFromAssets(string2, object);
            }
            case 4: {
                return this.getStreamFromContent(string2, object);
            }
            case 3: {
                return this.getStreamFromFile(string2, object);
            }
            case 1: 
            case 2: 
        }
        return this.getStreamFromNetwork(string2, object);
    }

    protected InputStream getStreamFromAssets(String string2, Object object) throws IOException {
        String string3 = ImageDownloader.Scheme.ASSETS.crop(string2);
        return this.context.getAssets().open(string3);
    }

    protected InputStream getStreamFromContent(String string2, Object object) throws FileNotFoundException {
        ContentResolver contentResolver = this.context.getContentResolver();
        Uri uri = Uri.parse((String)string2);
        if (this.isVideoContentUri(uri)) {
            Bitmap bitmap = MediaStore.Video.Thumbnails.getThumbnail((ContentResolver)contentResolver, (long)Long.valueOf((String)uri.getLastPathSegment()), (int)1, null);
            if (bitmap != null) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 0, (OutputStream)byteArrayOutputStream);
                return new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            }
        } else if (string2.startsWith(CONTENT_CONTACTS_URI_PREFIX)) {
            return this.getContactPhotoStream(uri);
        }
        return contentResolver.openInputStream(uri);
    }

    protected InputStream getStreamFromDrawable(String string2, Object object) {
        int n = Integer.parseInt((String)ImageDownloader.Scheme.DRAWABLE.crop(string2));
        return this.context.getResources().openRawResource(n);
    }

    protected InputStream getStreamFromFile(String string2, Object object) throws IOException {
        String string3 = ImageDownloader.Scheme.FILE.crop(string2);
        if (this.isVideoFileUri(string2)) {
            return this.getVideoThumbnailStream(string3);
        }
        return new ContentLengthInputStream((InputStream)new BufferedInputStream((InputStream)new FileInputStream(string3), 32768), (int)new File(string3).length());
    }

    protected InputStream getStreamFromNetwork(String string2, Object object) throws IOException {
        InputStream inputStream;
        HttpURLConnection httpURLConnection = this.createConnection(string2, object);
        for (int i = 0; httpURLConnection.getResponseCode() / 100 == 3 && i < 5; ++i) {
            httpURLConnection = this.createConnection(httpURLConnection.getHeaderField("Location"), object);
        }
        try {
            inputStream = httpURLConnection.getInputStream();
        }
        catch (IOException iOException) {
            IoUtils.readAndCloseStream(httpURLConnection.getErrorStream());
            throw iOException;
        }
        if (this.shouldBeProcessed(httpURLConnection)) {
            return new ContentLengthInputStream((InputStream)new BufferedInputStream(inputStream, 32768), httpURLConnection.getContentLength());
        }
        IoUtils.closeSilently((Closeable)inputStream);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Image request failed with response code ");
        stringBuilder.append(httpURLConnection.getResponseCode());
        throw new IOException(stringBuilder.toString());
    }

    protected InputStream getStreamFromOtherSource(String string2, Object object) throws IOException {
        throw new UnsupportedOperationException(String.format((String)ERROR_UNSUPPORTED_SCHEME, (Object[])new Object[]{string2}));
    }

    protected boolean shouldBeProcessed(HttpURLConnection httpURLConnection) throws IOException {
        return httpURLConnection.getResponseCode() == 200;
    }
}

