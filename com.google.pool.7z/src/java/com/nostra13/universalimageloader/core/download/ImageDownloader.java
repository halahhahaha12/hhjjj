/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Enum
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Locale
 */
package com.nostra13.universalimageloader.core.download;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

public interface ImageDownloader {
    public InputStream getStream(String var1, Object var2) throws IOException;

    public static final class Scheme
    extends Enum<Scheme> {
        private static final /* synthetic */ Scheme[] $VALUES;
        public static final /* enum */ Scheme ASSETS;
        public static final /* enum */ Scheme CONTENT;
        public static final /* enum */ Scheme DRAWABLE;
        public static final /* enum */ Scheme FILE;
        public static final /* enum */ Scheme HTTP;
        public static final /* enum */ Scheme HTTPS;
        public static final /* enum */ Scheme UNKNOWN;
        private String scheme;
        private String uriPrefix;

        static {
            Scheme scheme;
            Scheme scheme2;
            Scheme scheme3;
            Scheme scheme4;
            Scheme scheme5;
            Scheme scheme6;
            Scheme scheme7;
            HTTP = scheme3 = new Scheme("http");
            HTTPS = scheme4 = new Scheme("https");
            FILE = scheme2 = new Scheme("file");
            CONTENT = scheme7 = new Scheme("content");
            ASSETS = scheme = new Scheme("assets");
            DRAWABLE = scheme5 = new Scheme("drawable");
            UNKNOWN = scheme6 = new Scheme("");
            $VALUES = new Scheme[]{scheme3, scheme4, scheme2, scheme7, scheme, scheme5, scheme6};
        }

        private Scheme(String string3) {
            this.scheme = string3;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string3);
            stringBuilder.append("://");
            this.uriPrefix = stringBuilder.toString();
        }

        private boolean belongsTo(String string2) {
            return string2.toLowerCase(Locale.US).startsWith(this.uriPrefix);
        }

        public static Scheme ofUri(String string2) {
            if (string2 != null) {
                for (Scheme scheme : Scheme.values()) {
                    if (!scheme.belongsTo(string2)) continue;
                    return scheme;
                }
            }
            return UNKNOWN;
        }

        public static Scheme valueOf(String string2) {
            return (Scheme)Enum.valueOf(Scheme.class, (String)string2);
        }

        public static Scheme[] values() {
            return (Scheme[])$VALUES.clone();
        }

        public String crop(String string2) {
            if (this.belongsTo(string2)) {
                return string2.substring(this.uriPrefix.length());
            }
            Object[] arrobject = new Object[]{string2, this.scheme};
            throw new IllegalArgumentException(String.format((String)"URI [%1$s] doesn't have expected scheme [%2$s]", (Object[])arrobject));
        }

        public String wrap(String string2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.uriPrefix);
            stringBuilder.append(string2);
            return stringBuilder.toString();
        }
    }

}

