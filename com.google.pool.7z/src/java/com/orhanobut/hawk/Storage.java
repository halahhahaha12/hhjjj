/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.orhanobut.hawk;

public interface Storage {
    public boolean contains(String var1);

    public long count();

    public boolean delete(String var1);

    public boolean deleteAll();

    public <T> T get(String var1);

    public <T> boolean put(String var1, T var2);
}

