/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.orhanobut.hawk;

final class HawkUtils {
    private HawkUtils() {
    }

    public static void checkNull(String string2, Object object) {
        if (object != null) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append(" should not be null");
        throw new NullPointerException(stringBuilder.toString());
    }

    public static void checkNullOrEmpty(String string2, String string3) {
        if (!HawkUtils.isEmpty(string3)) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append(" should not be null or empty");
        throw new NullPointerException(stringBuilder.toString());
    }

    public static boolean isEmpty(String string2) {
        return string2 == null || string2.trim().length() == 0;
        {
        }
    }
}

