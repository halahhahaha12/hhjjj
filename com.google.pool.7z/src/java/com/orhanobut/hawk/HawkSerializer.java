/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.orhanobut.hawk;

import com.orhanobut.hawk.DataInfo;
import com.orhanobut.hawk.HawkUtils;
import com.orhanobut.hawk.LogInterceptor;
import com.orhanobut.hawk.Serializer;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

class HawkSerializer
implements Serializer {
    private static final char DELIMITER = '@';
    private static final String INFO_DELIMITER = "#";
    private static final char NEW_VERSION = 'V';
    private final LogInterceptor logInterceptor;

    HawkSerializer(LogInterceptor logInterceptor) {
        this.logInterceptor = logInterceptor;
    }

    private String getCipherText(String string2) {
        int n = string2.indexOf(64);
        if (n != -1) {
            return string2.substring(n + 1);
        }
        throw new IllegalArgumentException("Text should contain delimiter");
    }

    @Override
    public DataInfo deserialize(String string2) {
        char c;
        Class class_;
        String[] arrstring;
        block7 : {
            arrstring = string2.split(INFO_DELIMITER);
            c = arrstring[2].charAt(0);
            String string3 = arrstring[0];
            if (string3 != null && string3.length() != 0) {
                try {
                    class_ = Class.forName((String)string3);
                    break block7;
                }
                catch (ClassNotFoundException classNotFoundException) {
                    LogInterceptor logInterceptor = this.logInterceptor;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("HawkSerializer -> ");
                    stringBuilder.append(classNotFoundException.getMessage());
                    logInterceptor.onLog(stringBuilder.toString());
                }
            }
            class_ = null;
        }
        String string4 = arrstring[1];
        Class class_2 = null;
        if (string4 != null) {
            int n = string4.length();
            class_2 = null;
            if (n != 0) {
                try {
                    class_2 = Class.forName((String)string4);
                }
                catch (ClassNotFoundException classNotFoundException) {
                    LogInterceptor logInterceptor = this.logInterceptor;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("HawkSerializer -> ");
                    stringBuilder.append(classNotFoundException.getMessage());
                    logInterceptor.onLog(stringBuilder.toString());
                }
            }
        }
        return new DataInfo(c, this.getCipherText(arrstring[arrstring.length - 1]), class_, class_2);
    }

    @Override
    public <T> String serialize(String string2, T t) {
        String string3;
        char c;
        HawkUtils.checkNullOrEmpty("Cipher text", string2);
        HawkUtils.checkNull("Value", t);
        boolean bl = List.class.isAssignableFrom(t.getClass());
        String string4 = "";
        if (bl) {
            List list = (List)t;
            string3 = !list.isEmpty() ? list.get(0).getClass().getName() : string4;
            c = '1';
        } else if (Map.class.isAssignableFrom(t.getClass())) {
            String string5;
            Iterator iterator;
            c = '2';
            Map map = (Map)t;
            if (!map.isEmpty() && (iterator = map.entrySet().iterator()).hasNext()) {
                Map.Entry entry = (Map.Entry)iterator.next();
                string4 = entry.getKey().getClass().getName();
                string5 = entry.getValue().getClass().getName();
            } else {
                string5 = string4;
            }
            String string6 = string4;
            string4 = string5;
            string3 = string6;
        } else if (Set.class.isAssignableFrom(t.getClass())) {
            Iterator iterator;
            Set set = (Set)t;
            string3 = !set.isEmpty() && (iterator = set.iterator()).hasNext() ? iterator.next().getClass().getName() : string4;
            c = '3';
        } else {
            c = '0';
            string3 = t.getClass().getName();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string3);
        stringBuilder.append(INFO_DELIMITER);
        stringBuilder.append(string4);
        stringBuilder.append(INFO_DELIMITER);
        stringBuilder.append(c);
        stringBuilder.append('V');
        stringBuilder.append('@');
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }
}

