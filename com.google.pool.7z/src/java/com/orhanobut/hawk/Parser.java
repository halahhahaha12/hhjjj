/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Type
 */
package com.orhanobut.hawk;

import java.lang.reflect.Type;

public interface Parser {
    public <T> T fromJson(String var1, Type var2) throws Exception;

    public String toJson(Object var1);
}

