/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Base64
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.orhanobut.hawk;

import android.util.Base64;
import com.orhanobut.hawk.Encryption;

public class NoEncryption
implements Encryption {
    byte[] decodeBase64(String string2) {
        return Base64.decode((String)string2, (int)0);
    }

    @Override
    public String decrypt(String string2, String string3) throws Exception {
        return new String(this.decodeBase64(string3));
    }

    String encodeBase64(byte[] arrby) {
        return Base64.encodeToString((byte[])arrby, (int)0);
    }

    @Override
    public String encrypt(String string2, String string3) throws Exception {
        return this.encodeBase64(string3.getBytes());
    }

    @Override
    public boolean init() {
        return true;
    }
}

