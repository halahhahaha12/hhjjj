/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.reflect.TypeToken
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Type
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Objects
 *  java.util.Set
 */
package com.orhanobut.hawk;

import com.google.gson.reflect.TypeToken;
import com.orhanobut.hawk.Converter;
import com.orhanobut.hawk.DataInfo;
import com.orhanobut.hawk.HawkUtils;
import com.orhanobut.hawk.Parser;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

final class HawkConverter
implements Converter {
    private final Parser parser;

    public HawkConverter(Parser parser) {
        Objects.requireNonNull((Object)parser, (String)"Parser should not be null");
        this.parser = parser;
    }

    private <T> T toList(String string2, Class<?> class_) throws Exception {
        if (class_ == null) {
            return (T)new ArrayList();
        }
        List list = (List)this.parser.fromJson(string2, new TypeToken<List<T>>(){}.getType());
        int n = list.size();
        for (int i = 0; i < n; ++i) {
            Parser parser = this.parser;
            list.set(i, parser.fromJson(parser.toJson(list.get(i)), (Type)class_));
        }
        return (T)list;
    }

    private <K, V, T> T toMap(String string2, Class<?> class_, Class<?> class_2) throws Exception {
        HashMap hashMap = new HashMap();
        if (class_ != null) {
            if (class_2 == null) {
                return (T)hashMap;
            }
            for (Map.Entry entry : ((Map)this.parser.fromJson(string2, new TypeToken<Map<K, V>>(){}.getType())).entrySet()) {
                String string3 = this.parser.toJson(entry.getKey());
                Object t = this.parser.fromJson(string3, (Type)class_);
                String string4 = this.parser.toJson(entry.getValue());
                hashMap.put(t, this.parser.fromJson(string4, (Type)class_2));
            }
        }
        return (T)hashMap;
    }

    private <T> T toObject(String string2, Class<?> class_) throws Exception {
        return this.parser.fromJson(string2, (Type)class_);
    }

    private <T> T toSet(String string2, Class<?> class_) throws Exception {
        HashSet hashSet = new HashSet();
        if (class_ == null) {
            return (T)hashSet;
        }
        for (Object object : (Set)this.parser.fromJson(string2, new TypeToken<Set<T>>(){}.getType())) {
            String string3 = this.parser.toJson(object);
            hashSet.add(this.parser.fromJson(string3, (Type)class_));
        }
        return (T)hashSet;
    }

    @Override
    public <T> T fromString(String string2, DataInfo dataInfo) throws Exception {
        if (string2 == null) {
            return null;
        }
        HawkUtils.checkNull("data info", dataInfo);
        Class class_ = dataInfo.keyClazz;
        Class class_2 = dataInfo.valueClazz;
        switch (dataInfo.dataType) {
            default: {
                return null;
            }
            case '3': {
                return this.toSet(string2, class_);
            }
            case '2': {
                return this.toMap(string2, class_, class_2);
            }
            case '1': {
                return this.toList(string2, class_);
            }
            case '0': 
        }
        return this.toObject(string2, class_);
    }

    @Override
    public <T> String toString(T t) {
        if (t == null) {
            return null;
        }
        return this.parser.toJson(t);
    }

}

