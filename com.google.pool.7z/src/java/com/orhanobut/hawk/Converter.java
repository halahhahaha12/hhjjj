/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.orhanobut.hawk;

import com.orhanobut.hawk.DataInfo;

interface Converter {
    public <T> T fromString(String var1, DataInfo var2) throws Exception;

    public <T> String toString(T var1);
}

