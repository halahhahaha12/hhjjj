/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  com.google.gson.Gson
 *  com.google.gson.JsonSyntaxException
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Type
 */
package com.orhanobut.hawk;

import android.text.TextUtils;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.orhanobut.hawk.Parser;
import java.lang.reflect.Type;

public final class GsonParser
implements Parser {
    private final Gson gson;

    public GsonParser(Gson gson) {
        this.gson = gson;
    }

    @Override
    public <T> T fromJson(String string2, Type type) throws JsonSyntaxException {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return null;
        }
        return (T)this.gson.fromJson(string2, type);
    }

    @Override
    public String toJson(Object object) {
        return this.gson.toJson(object);
    }
}

