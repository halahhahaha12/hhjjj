/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.orhanobut.hawk;

import android.content.Context;
import android.content.SharedPreferences;
import com.orhanobut.hawk.HawkUtils;
import com.orhanobut.hawk.Storage;
import java.util.Map;

final class SharedPreferencesStorage
implements Storage {
    private final SharedPreferences preferences;

    SharedPreferencesStorage(Context context, String string2) {
        this.preferences = context.getSharedPreferences(string2, 0);
    }

    SharedPreferencesStorage(SharedPreferences sharedPreferences) {
        this.preferences = sharedPreferences;
    }

    private SharedPreferences.Editor getEditor() {
        return this.preferences.edit();
    }

    @Override
    public boolean contains(String string2) {
        return this.preferences.contains(string2);
    }

    @Override
    public long count() {
        return this.preferences.getAll().size();
    }

    @Override
    public boolean delete(String string2) {
        return this.getEditor().remove(string2).commit();
    }

    @Override
    public boolean deleteAll() {
        return this.getEditor().clear().commit();
    }

    @Override
    public <T> T get(String string2) {
        return (T)this.preferences.getString(string2, null);
    }

    @Override
    public <T> boolean put(String string2, T t) {
        HawkUtils.checkNull("key", string2);
        return this.getEditor().putString(string2, String.valueOf(t)).commit();
    }
}

