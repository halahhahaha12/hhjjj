/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.orhanobut.hawk;

interface Encryption {
    public String decrypt(String var1, String var2) throws Exception;

    public String encrypt(String var1, String var2) throws Exception;

    public boolean init();
}

