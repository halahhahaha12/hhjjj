/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.orhanobut.hawk;

final class DataInfo {
    static final char TYPE_LIST = '1';
    static final char TYPE_MAP = '2';
    static final char TYPE_OBJECT = '0';
    static final char TYPE_SET = '3';
    final String cipherText;
    final char dataType;
    final Class keyClazz;
    final Class valueClazz;

    DataInfo(char c, String string2, Class class_, Class class_2) {
        this.cipherText = string2;
        this.keyClazz = class_;
        this.valueClazz = class_2;
        this.dataType = c;
    }
}

