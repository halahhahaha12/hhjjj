/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.orhanobut.hawk;

public interface HawkFacade {
    public boolean contains(String var1);

    public long count();

    public boolean delete(String var1);

    public boolean deleteAll();

    public void destroy();

    public <T> T get(String var1);

    public <T> T get(String var1, T var2);

    public boolean isBuilt();

    public <T> boolean put(String var1, T var2);
}

