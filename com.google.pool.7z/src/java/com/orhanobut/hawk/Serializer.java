/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.orhanobut.hawk;

import com.orhanobut.hawk.DataInfo;

public interface Serializer {
    public DataInfo deserialize(String var1);

    public <T> String serialize(String var1, T var2);
}

