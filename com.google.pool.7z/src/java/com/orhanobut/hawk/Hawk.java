/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.orhanobut.hawk.DefaultHawkFacade
 *  com.orhanobut.hawk.HawkFacade$EmptyHawkFacade
 *  java.lang.Object
 *  java.lang.String
 */
package com.orhanobut.hawk;

import android.content.Context;
import com.orhanobut.hawk.DefaultHawkFacade;
import com.orhanobut.hawk.HawkBuilder;
import com.orhanobut.hawk.HawkFacade;
import com.orhanobut.hawk.HawkUtils;

public final class Hawk {
    static HawkFacade hawkFacade = new HawkFacade.EmptyHawkFacade();

    private Hawk() {
    }

    static void build(HawkBuilder hawkBuilder) {
        hawkFacade = new DefaultHawkFacade(hawkBuilder);
    }

    public static boolean contains(String string2) {
        return hawkFacade.contains(string2);
    }

    public static long count() {
        return hawkFacade.count();
    }

    public static boolean delete(String string2) {
        return hawkFacade.delete(string2);
    }

    public static boolean deleteAll() {
        return hawkFacade.deleteAll();
    }

    public static void destroy() {
        hawkFacade.destroy();
    }

    public static <T> T get(String string2) {
        return hawkFacade.get(string2);
    }

    public static <T> T get(String string2, T t) {
        return hawkFacade.get(string2, t);
    }

    public static HawkBuilder init(Context context) {
        HawkUtils.checkNull("Context", (Object)context);
        hawkFacade = null;
        return new HawkBuilder(context);
    }

    public static boolean isBuilt() {
        return hawkFacade.isBuilt();
    }

    public static <T> boolean put(String string2, T t) {
        return hawkFacade.put(string2, t);
    }
}

