/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.google.gson.Gson
 *  com.orhanobut.hawk.ConcealEncryption
 *  com.orhanobut.hawk.GsonParser
 *  com.orhanobut.hawk.HawkBuilder$1
 *  com.orhanobut.hawk.HawkConverter
 *  com.orhanobut.hawk.HawkSerializer
 *  com.orhanobut.hawk.NoEncryption
 *  com.orhanobut.hawk.SharedPreferencesStorage
 *  java.lang.Object
 *  java.lang.String
 */
package com.orhanobut.hawk;

import android.content.Context;
import com.google.gson.Gson;
import com.orhanobut.hawk.ConcealEncryption;
import com.orhanobut.hawk.Converter;
import com.orhanobut.hawk.Encryption;
import com.orhanobut.hawk.GsonParser;
import com.orhanobut.hawk.Hawk;
import com.orhanobut.hawk.HawkBuilder;
import com.orhanobut.hawk.HawkConverter;
import com.orhanobut.hawk.HawkSerializer;
import com.orhanobut.hawk.HawkUtils;
import com.orhanobut.hawk.LogInterceptor;
import com.orhanobut.hawk.NoEncryption;
import com.orhanobut.hawk.Parser;
import com.orhanobut.hawk.Serializer;
import com.orhanobut.hawk.SharedPreferencesStorage;
import com.orhanobut.hawk.Storage;

public class HawkBuilder {
    private static final String STORAGE_TAG_DO_NOT_CHANGE = "Hawk2";
    private Context context;
    private Converter converter;
    private Storage cryptoStorage;
    private Encryption encryption;
    private LogInterceptor logInterceptor;
    private Parser parser;
    private Serializer serializer;

    public HawkBuilder(Context context) {
        HawkUtils.checkNull("Context", (Object)context);
        this.context = context.getApplicationContext();
    }

    public void build() {
        Hawk.build(this);
    }

    Converter getConverter() {
        if (this.converter == null) {
            this.converter = new HawkConverter(this.getParser());
        }
        return this.converter;
    }

    Encryption getEncryption() {
        if (this.encryption == null) {
            ConcealEncryption concealEncryption = new ConcealEncryption(this.context);
            this.encryption = concealEncryption;
            if (!concealEncryption.init()) {
                this.encryption = new NoEncryption();
            }
        }
        return this.encryption;
    }

    LogInterceptor getLogInterceptor() {
        if (this.logInterceptor == null) {
            this.logInterceptor = new 1(this);
        }
        return this.logInterceptor;
    }

    Parser getParser() {
        if (this.parser == null) {
            this.parser = new GsonParser(new Gson());
        }
        return this.parser;
    }

    Serializer getSerializer() {
        if (this.serializer == null) {
            this.serializer = new HawkSerializer(this.getLogInterceptor());
        }
        return this.serializer;
    }

    Storage getStorage() {
        if (this.cryptoStorage == null) {
            this.cryptoStorage = new SharedPreferencesStorage(this.context, STORAGE_TAG_DO_NOT_CHANGE);
        }
        return this.cryptoStorage;
    }

    public HawkBuilder setConverter(Converter converter) {
        this.converter = converter;
        return this;
    }

    public HawkBuilder setEncryption(Encryption encryption) {
        this.encryption = encryption;
        return this;
    }

    public HawkBuilder setLogInterceptor(LogInterceptor logInterceptor) {
        this.logInterceptor = logInterceptor;
        return this;
    }

    public HawkBuilder setParser(Parser parser) {
        this.parser = parser;
        return this;
    }

    public HawkBuilder setSerializer(Serializer serializer) {
        this.serializer = serializer;
        return this;
    }

    public HawkBuilder setStorage(Storage storage) {
        this.cryptoStorage = storage;
        return this;
    }
}

