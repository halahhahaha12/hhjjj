/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Base64
 *  com.facebook.android.crypto.keychain.AndroidConceal
 *  com.facebook.android.crypto.keychain.SharedPrefsBackedKeyChain
 *  com.facebook.crypto.Crypto
 *  com.facebook.crypto.CryptoConfig
 *  com.facebook.crypto.Entity
 *  com.facebook.crypto.keychain.KeyChain
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.orhanobut.hawk;

import android.content.Context;
import android.util.Base64;
import com.facebook.android.crypto.keychain.AndroidConceal;
import com.facebook.android.crypto.keychain.SharedPrefsBackedKeyChain;
import com.facebook.crypto.Crypto;
import com.facebook.crypto.CryptoConfig;
import com.facebook.crypto.Entity;
import com.facebook.crypto.keychain.KeyChain;
import com.orhanobut.hawk.Encryption;

class ConcealEncryption
implements Encryption {
    private final Crypto crypto;

    public ConcealEncryption(Context context) {
        SharedPrefsBackedKeyChain sharedPrefsBackedKeyChain = new SharedPrefsBackedKeyChain(context, CryptoConfig.KEY_256);
        this.crypto = AndroidConceal.get().createDefaultCrypto((KeyChain)sharedPrefsBackedKeyChain);
    }

    @Override
    public String decrypt(String string2, String string3) throws Exception {
        Entity entity = Entity.create((String)string2);
        byte[] arrby = Base64.decode((String)string3, (int)2);
        return new String(this.crypto.decrypt(arrby, entity));
    }

    @Override
    public String encrypt(String string2, String string3) throws Exception {
        Entity entity = Entity.create((String)string2);
        return Base64.encodeToString((byte[])this.crypto.encrypt(string3.getBytes(), entity), (int)2);
    }

    @Override
    public boolean init() {
        return this.crypto.isAvailable();
    }
}

