/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.orhanobut.hawk;

import com.orhanobut.hawk.Converter;
import com.orhanobut.hawk.DataInfo;
import com.orhanobut.hawk.Encryption;
import com.orhanobut.hawk.HawkBuilder;
import com.orhanobut.hawk.HawkFacade;
import com.orhanobut.hawk.HawkUtils;
import com.orhanobut.hawk.LogInterceptor;
import com.orhanobut.hawk.Serializer;
import com.orhanobut.hawk.Storage;

public class DefaultHawkFacade
implements HawkFacade {
    private final Converter converter;
    private final Encryption encryption;
    private final LogInterceptor logInterceptor;
    private final Serializer serializer;
    private final Storage storage;

    public DefaultHawkFacade(HawkBuilder hawkBuilder) {
        LogInterceptor logInterceptor;
        Encryption encryption;
        this.encryption = encryption = hawkBuilder.getEncryption();
        this.storage = hawkBuilder.getStorage();
        this.converter = hawkBuilder.getConverter();
        this.serializer = hawkBuilder.getSerializer();
        this.logInterceptor = logInterceptor = hawkBuilder.getLogInterceptor();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Hawk.init -> Encryption : ");
        stringBuilder.append(encryption.getClass().getSimpleName());
        logInterceptor.onLog(stringBuilder.toString());
    }

    private void log(String string2) {
        this.logInterceptor.onLog(string2);
    }

    @Override
    public boolean contains(String string2) {
        return this.storage.contains(string2);
    }

    @Override
    public long count() {
        return this.storage.count();
    }

    @Override
    public boolean delete(String string2) {
        return this.storage.delete(string2);
    }

    @Override
    public boolean deleteAll() {
        return this.storage.deleteAll();
    }

    @Override
    public void destroy() {
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public <T> T get(String string2) {
        String string3;
        T t;
        DataInfo dataInfo;
        block10 : {
            void var11_11;
            block11 : {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Hawk.get -> key: ");
                stringBuilder.append(string2);
                this.log(stringBuilder.toString());
                t = null;
                if (string2 == null) {
                    this.log("Hawk.get -> null key, returning null value ");
                    return null;
                }
                String string4 = (String)this.storage.get(string2);
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Hawk.get -> Fetched from storage : ");
                stringBuilder2.append(string4);
                this.log(stringBuilder2.toString());
                if (string4 == null) {
                    this.log("Hawk.get -> Fetching from storage failed");
                    return null;
                }
                dataInfo = this.serializer.deserialize(string4);
                this.log("Hawk.get -> Deserialized");
                if (dataInfo == null) {
                    this.log("Hawk.get -> Deserialization failed");
                    return null;
                }
                string3 = this.encryption.decrypt(string2, dataInfo.cipherText);
                try {
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("Hawk.get -> Decrypted to : ");
                    stringBuilder3.append(string3);
                    this.log(stringBuilder3.toString());
                    break block10;
                }
                catch (Exception exception) {
                    break block11;
                }
                catch (Exception exception) {
                    string3 = null;
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Hawk.get -> Decrypt failed: ");
            stringBuilder.append(var11_11.getMessage());
            this.log(stringBuilder.toString());
        }
        if (string3 == null) {
            this.log("Hawk.get -> Decrypt failed");
            return null;
        }
        try {
            t = this.converter.fromString(string3, dataInfo);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Hawk.get -> Converted to : ");
            stringBuilder.append(t);
            this.log(stringBuilder.toString());
        }
        catch (Exception exception) {
            this.log("Hawk.get -> Converter failed");
            return t;
        }
        return t;
    }

    @Override
    public <T> T get(String string2, T t) {
        T t2 = this.get(string2);
        if (t2 == null) {
            return t;
        }
        return t2;
    }

    @Override
    public boolean isBuilt() {
        return true;
    }

    @Override
    public <T> boolean put(String string2, T t) {
        HawkUtils.checkNull("Key", string2);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Hawk.put -> key: ");
        stringBuilder.append(string2);
        stringBuilder.append(", value: ");
        stringBuilder.append(t);
        this.log(stringBuilder.toString());
        if (t == null) {
            this.log("Hawk.put -> Value is null. Any existing value will be deleted with the given key");
            return this.delete(string2);
        }
        String string3 = this.converter.toString(t);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Hawk.put -> Converted to ");
        stringBuilder2.append(string3);
        this.log(stringBuilder2.toString());
        if (string3 == null) {
            this.log("Hawk.put -> Converter failed");
            return false;
        }
        String string4 = null;
        try {
            string4 = this.encryption.encrypt(string2, string3);
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Hawk.put -> Encrypted to  ");
            stringBuilder3.append(string4);
            this.log(stringBuilder3.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        if (string4 == null) {
            this.log("Hawk.put -> Encryption failed");
            return false;
        }
        String string5 = this.serializer.serialize(string4, t);
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append("Hawk.put -> Serialized to");
        stringBuilder4.append(string5);
        this.log(stringBuilder4.toString());
        if (string5 == null) {
            this.log("Hawk.put -> Serialization failed");
            return false;
        }
        if (this.storage.put(string2, string5)) {
            this.log("Hawk.put -> Stored successfully");
            return true;
        }
        this.log("Hawk.put -> Store operation failed");
        return false;
    }
}

