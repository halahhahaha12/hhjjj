/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.AssetManager
 *  android.content.res.ColorStateList
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.content.res.Resources$NotFoundException
 *  android.content.res.Resources$Theme
 *  android.content.res.ResourcesImpl
 *  android.graphics.drawable.Drawable
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.util.TypedValue
 *  dalvik.annotation.MethodParameters
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 */
package com.zero.support.box;

import android.content.res.AssetManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.ResourcesImpl;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import dalvik.annotation.MethodParameters;
import java.lang.reflect.Field;

public class BoxResources
extends Resources {
    private Field field;
    private Field mClassLoader;
    private final String mPackageName;
    private final Resources mResource;

    /*
     * Exception decompiling
     */
    @MethodParameters(accessFlags={0, 0, 0, 0}, names={"loader", "packageName", "manager", "resource"})
    public BoxResources(ClassLoader var1, String var2, AssetManager var3, Resources var4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    @MethodParameters(accessFlags={0}, names={"id"})
    public int getColor(int n) throws Resources.NotFoundException {
        try {
            int n2 = super.getColor(n);
            return n2;
        }
        catch (Exception exception) {
            return this.mResource.getColor(n);
        }
    }

    @MethodParameters(accessFlags={0, 0}, names={"id", "theme"})
    public int getColor(int n, Resources.Theme theme) throws Resources.NotFoundException {
        try {
            int n2 = super.getColor(n, theme);
            return n2;
        }
        catch (Exception exception) {
            return this.mResource.getColor(n, theme);
        }
    }

    @MethodParameters(accessFlags={0}, names={"id"})
    public ColorStateList getColorStateList(int n) throws Resources.NotFoundException {
        try {
            ColorStateList colorStateList = super.getColorStateList(n);
            return colorStateList;
        }
        catch (Exception exception) {
            return this.mResource.getColorStateList(n);
        }
    }

    @MethodParameters(accessFlags={0, 0}, names={"id", "theme"})
    public ColorStateList getColorStateList(int n, Resources.Theme theme) throws Resources.NotFoundException {
        try {
            ColorStateList colorStateList = super.getColorStateList(n, theme);
            return colorStateList;
        }
        catch (Exception exception) {
            return this.mResource.getColorStateList(n, theme);
        }
    }

    @MethodParameters(accessFlags={0}, names={"id"})
    public float getDimension(int n) throws Resources.NotFoundException {
        try {
            float f = super.getDimension(n);
            return f;
        }
        catch (Exception exception) {
            return this.mResource.getDimension(n);
        }
    }

    @MethodParameters(accessFlags={0}, names={"id"})
    public int getDimensionPixelOffset(int n) throws Resources.NotFoundException {
        try {
            int n2 = super.getDimensionPixelOffset(n);
            return n2;
        }
        catch (Exception exception) {
            return this.mResource.getDimensionPixelOffset(n);
        }
    }

    @MethodParameters(accessFlags={0}, names={"id"})
    public int getDimensionPixelSize(int n) throws Resources.NotFoundException {
        try {
            int n2 = super.getDimensionPixelSize(n);
            return n2;
        }
        catch (Exception exception) {
            return this.mResource.getDimensionPixelSize(n);
        }
    }

    @MethodParameters(accessFlags={0}, names={"id"})
    public Drawable getDrawable(int n) throws Resources.NotFoundException {
        try {
            Drawable drawable2 = super.getDrawable(n);
            return drawable2;
        }
        catch (Exception exception) {
            return this.mResource.getDrawable(n);
        }
    }

    @MethodParameters(accessFlags={0, 0}, names={"id", "theme"})
    public Drawable getDrawable(int n, Resources.Theme theme) throws Resources.NotFoundException {
        try {
            Drawable drawable2 = super.getDrawable(n, theme);
            return drawable2;
        }
        catch (Exception exception) {
            return this.mResource.getDrawable(n, theme);
        }
    }

    @MethodParameters(accessFlags={0, 0}, names={"id", "density"})
    public Drawable getDrawableForDensity(int n, int n2) throws Resources.NotFoundException {
        try {
            Drawable drawable2 = super.getDrawableForDensity(n, n2);
            return drawable2;
        }
        catch (Exception exception) {
            return this.mResource.getDrawableForDensity(n, n2);
        }
    }

    @MethodParameters(accessFlags={0, 0, 0}, names={"id", "density", "theme"})
    public Drawable getDrawableForDensity(int n, int n2, Resources.Theme theme) {
        try {
            Drawable drawable2 = super.getDrawableForDensity(n, n2, theme);
            return drawable2;
        }
        catch (Exception exception) {
            return this.mResource.getDrawableForDensity(n, n2, theme);
        }
    }

    @MethodParameters(accessFlags={0, 0, 0}, names={"name", "defType", "defPackage"})
    public int getIdentifier(String string2, String string3, String string4) {
        int n = super.getIdentifier(string2, string3, this.mPackageName);
        if (n > 0) {
            return n;
        }
        return super.getIdentifier(string2, string3, string4);
    }

    @MethodParameters(accessFlags={0, 0}, names={"id", "quantity"})
    public CharSequence getQuantityText(int n, int n2) throws Resources.NotFoundException {
        try {
            CharSequence charSequence = super.getQuantityText(n, n2);
            return charSequence;
        }
        catch (Exception exception) {
            return this.mResource.getQuantityText(n, n2);
        }
    }

    @MethodParameters(accessFlags={0}, names={"id"})
    public String getString(int n) throws Resources.NotFoundException {
        try {
            String string2 = super.getString(n);
            return string2;
        }
        catch (Exception exception) {
            return this.mResource.getString(n);
        }
    }

    @MethodParameters(accessFlags={0, 0}, names={"id", "formatArgs"})
    public /* varargs */ String getString(int n, Object ... arrobject) throws Resources.NotFoundException {
        try {
            String string2 = super.getString(n, arrobject);
            return string2;
        }
        catch (Exception exception) {
            return this.mResource.getString(n, arrobject);
        }
    }

    @MethodParameters(accessFlags={0}, names={"id"})
    public CharSequence getText(int n) throws Resources.NotFoundException {
        try {
            CharSequence charSequence = super.getText(n);
            return charSequence;
        }
        catch (Exception exception) {
            return this.mResource.getText(n);
        }
    }

    @MethodParameters(accessFlags={0, 0}, names={"id", "def"})
    public CharSequence getText(int n, CharSequence charSequence) {
        try {
            CharSequence charSequence2 = super.getText(n, charSequence);
            return charSequence2;
        }
        catch (Exception exception) {
            return this.mResource.getText(n, charSequence);
        }
    }

    @MethodParameters(accessFlags={0}, names={"id"})
    public CharSequence[] getTextArray(int n) throws Resources.NotFoundException {
        try {
            CharSequence[] arrcharSequence = super.getTextArray(n);
            return arrcharSequence;
        }
        catch (Exception exception) {
            return this.mResource.getTextArray(n);
        }
    }

    @MethodParameters(accessFlags={0, 0, 0, 0}, names={"id", "density", "outValue", "resolveRefs"})
    public void getValueForDensity(int n, int n2, TypedValue typedValue, boolean bl) throws Resources.NotFoundException {
        try {
            super.getValueForDensity(n, n2, typedValue, bl);
            return;
        }
        catch (Exception exception) {
            this.mResource.getValueForDensity(n, n2, typedValue, bl);
            return;
        }
    }

    @MethodParameters(accessFlags={0}, names={"impl"})
    public void setImpl(ResourcesImpl resourcesImpl) {
        ResourcesImpl resourcesImpl2;
        block4 : {
            if (this.field == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("setImpl: failed for ");
                stringBuilder.append((Object)resourcesImpl);
                Log.e((String)"box", (String)stringBuilder.toString());
            }
            try {
                resourcesImpl2 = (ResourcesImpl)this.field.get((Object)this);
                if (resourcesImpl2 != resourcesImpl) break block4;
                return;
            }
            catch (Throwable throwable) {}
        }
        this.field.set((Object)this, (Object)resourcesImpl);
        Configuration configuration = this.getConfiguration();
        DisplayMetrics displayMetrics = this.getDisplayMetrics();
        this.field.set((Object)this, (Object)resourcesImpl2);
        this.updateConfiguration(configuration, displayMetrics);
    }
}

