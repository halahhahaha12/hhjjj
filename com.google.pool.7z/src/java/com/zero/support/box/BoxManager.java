/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  dalvik.annotation.MethodParameters
 *  dalvik.system.DexClassLoader
 *  java.io.File
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.util.HashMap
 *  java.util.Map
 */
package com.zero.support.box;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import com.zero.support.box.Box;
import dalvik.annotation.MethodParameters;
import dalvik.system.DexClassLoader;
import java.io.File;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class BoxManager {
    public static final String NAME_RUNTIME = ".BoxRuntime";
    private static final Map<String, Box> boxes = new HashMap();
    private static Field parentField;

    static {
        try {
            Field field;
            parentField = field = ClassLoader.class.getDeclaredField("parent");
            field.setAccessible(true);
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    @MethodParameters(accessFlags={0, 0}, names={"target", "loader"})
    public static void becomToParent(ClassLoader classLoader, ClassLoader classLoader2) {
        if (classLoader != null) {
            if (classLoader2 == null) {
                return;
            }
            try {
                parentField.set((Object)classLoader, (Object)classLoader2);
                return;
            }
            catch (Throwable throwable) {
                throwable.printStackTrace();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @MethodParameters(accessFlags={0}, names={"packageName"})
    public static Box getBox(String string2) {
        Map<String, Box> map;
        Map<String, Box> map2 = map = boxes;
        synchronized (map2) {
            return (Box)map.get((Object)string2);
        }
    }

    @MethodParameters(accessFlags={0, 0, 0, 0, 0}, names={"context", "parent", "path", "lib", "host"})
    public static Box load(Context context, ClassLoader classLoader, File file, File file2, boolean bl) {
        return BoxManager.load(null, context, context.getClassLoader(), file, file2, false);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @MethodParameters(accessFlags={0, 0, 0, 0, 0, 0}, names={"name", "context", "parent", "apk", "lib", "host"})
    public static Box load(String var0, Context var1_1, ClassLoader var2_2, File var3_3, File var4_4, boolean var5_5) {
        if (!var5_5) ** GOTO lbl7
        try {
            block6 : {
                var17_6 = var1_1.getClassLoader();
                var10_7 = var1_1.getPackageManager().getPackageInfo(var1_1.getPackageName(), 128);
                var11_8 = var17_6;
                break block6;
lbl7: // 1 sources:
                var7_9 = var3_3.getCanonicalPath();
                var8_10 = var1_1.getPackageManager().getPackageArchiveInfo(var7_9, 129);
                var8_10.applicationInfo.sourceDir = var7_9;
                var8_10.applicationInfo.publicSourceDir = var7_9;
                var8_10.applicationInfo.nativeLibraryDir = var4_4.getCanonicalPath();
                var9_11 = new DexClassLoader(var7_9, var3_3.getParentFile().getCanonicalPath(), var4_4.getCanonicalPath(), var2_2);
                var10_7 = var8_10;
                var11_8 = var9_11;
            }
            if (var0 == null) {
                var0 = var10_7.packageName;
            }
            var12_12 = var0;
            var13_13 = new Box(var12_12, var1_1, var10_7, var11_8, var5_5);
            var18_15 = var14_14 = BoxManager.boxes;
            // MONITORENTER : var18_15
        }
        catch (Throwable var6_16) {
            var6_16.printStackTrace();
            return null;
        }
        var14_14.put((Object)var10_7.packageName, (Object)var13_13);
        // MONITOREXIT : var18_15
        return var13_13;
    }
}

