/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.text.TextUtils
 *  dalvik.annotation.MethodParameters
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.zero.support.box;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.text.TextUtils;
import com.zero.support.box.Box;
import com.zero.support.box.BoxContext;
import com.zero.support.box.BoxResources;
import com.zero.support.box.plugin.invoke.IInvocation;
import com.zero.support.box.plugin.invoke.LocalInvocation;
import com.zero.support.box.plugin.invoke.MethodInvoke;
import dalvik.annotation.MethodParameters;
import java.util.HashMap;
import java.util.Map;

public class InvocationManager
implements IInvocation {
    private Box box;
    private final Map<String, Object[]> invokes = new HashMap();
    private final Map<Class<?>, Map<String, Object[]>> methods = new HashMap();

    @MethodParameters(accessFlags={0}, names={"box"})
    public InvocationManager(Box box) {
        this.box = box;
    }

    @MethodParameters(accessFlags={0}, names={"context"})
    private Resources newResources(Context context) {
        Resources resources = context.getResources();
        return new BoxResources(this.box.getClassLoader(), this.box.getPackageInfo().packageName, this.box.getAssetManager(), resources);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @MethodParameters(accessFlags={0, 0, 0}, names={"name", "target", "targetCls"})
    @Override
    public void addInvocationTarget(String string2, Object object, Class<?> class_) {
        Map<String, Object[]> map;
        Map<String, Object[]> map2 = map = this.invokes;
        synchronized (map2) {
            Object[] arrobject = new Object[]{object, class_};
            Object[] arrobject2 = (Object[])this.invokes.put((Object)string2, (Object)arrobject);
            if (arrobject2 != null) {
                LocalInvocation.removeInvocation(arrobject2[0]);
            }
            return;
        }
    }

    @MethodParameters(accessFlags={0, 0}, names={"base", "theme"})
    @Override
    public Context createBoxContext(Context context, int n) {
        if (n == 0) {
            n = this.getDefaultTheme();
        }
        int n2 = n;
        BoxContext boxContext = new BoxContext(this.box.getClassLoader(), this.box.getPackageInfo(), context, this.newResources(context), n2);
        return boxContext;
    }

    @MethodParameters(accessFlags={0, 0}, names={"context", "activity"})
    @Override
    public Context createBoxContextForActivity(Context context, Activity activity) {
        return this.createBoxContext(context, this.getTheme(activity));
    }

    public int getDefaultTheme() {
        return this.box.getPackageInfo().applicationInfo.theme;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @MethodParameters(accessFlags={0}, names={"cls"})
    @Override
    public Map<String, Object[]> getInvocationMethods(Class<?> class_) {
        Map<Class<?>, Map<String, Object[]>> map;
        Map<Class<?>, Map<String, Object[]>> map2 = map = this.methods;
        synchronized (map2) {
            Map<String, Object[]> map3 = (Map<String, Object[]>)this.methods.get(class_);
            if (map3 == null) {
                map3 = MethodInvoke.createMethod(class_, false);
                this.methods.put(class_, map3);
            }
            return map3;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @MethodParameters(accessFlags={0}, names={"name"})
    @Override
    public Object[] getInvocationTarget(String string2) {
        Map<String, Object[]> map;
        Map<String, Object[]> map2 = map = this.invokes;
        synchronized (map2) {
            return (Object[])this.invokes.get((Object)string2);
        }
    }

    @MethodParameters(accessFlags={0}, names={"activity"})
    public int getTheme(Activity activity) {
        PackageInfo packageInfo = this.box.getPackageInfo();
        String string2 = activity.getClass().getName();
        ActivityInfo[] arractivityInfo = packageInfo.activities;
        int n = packageInfo.applicationInfo.theme;
        if (arractivityInfo != null) {
            for (ActivityInfo activityInfo : arractivityInfo) {
                if (activityInfo.targetActivity == null) {
                    // empty if block
                }
                if (!TextUtils.equals((CharSequence)activityInfo.name, (CharSequence)string2)) continue;
                if (activityInfo.theme == 0) break;
                return activityInfo.theme;
            }
        }
        return n;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @MethodParameters(accessFlags={0}, names={"name"})
    @Override
    public void removeInvocationTarget(String string2) {
        Map<String, Object[]> map;
        Map<String, Object[]> map2 = map = this.invokes;
        synchronized (map2) {
            Object[] arrobject = (Object[])this.invokes.remove((Object)string2);
            if (arrobject != null) {
                LocalInvocation.removeInvocation(arrobject[0]);
            }
            return;
        }
    }
}

