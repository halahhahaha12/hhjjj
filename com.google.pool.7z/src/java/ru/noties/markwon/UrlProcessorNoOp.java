/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package ru.noties.markwon;

import ru.noties.markwon.UrlProcessor;

public class UrlProcessorNoOp
implements UrlProcessor {
    @Override
    public String process(String string2) {
        return string2;
    }
}

