/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.SpannableStringBuilder
 *  android.text.Spanned
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayDeque
 *  java.util.Deque
 *  java.util.Iterator
 *  ru.noties.markwon.SpannableBuilder$1
 *  ru.noties.markwon.SpannableStringBuilderImpl
 */
package ru.noties.markwon;

import android.text.SpannableStringBuilder;
import android.text.Spanned;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import ru.noties.markwon.SpannableBuilder;
import ru.noties.markwon.SpannableStringBuilderImpl;
import ru.noties.markwon.SpannedReversed;

public class SpannableBuilder {
    private final SpannableStringBuilder builder;
    private final Deque<Span> spans = new ArrayDeque(8);

    public SpannableBuilder() {
        this("");
    }

    public SpannableBuilder(CharSequence charSequence) {
        this.builder = new SpannableStringBuilderImpl((CharSequence)charSequence.toString());
        this.copySpans(0, charSequence);
    }

    private void copySpans(int n, CharSequence charSequence) {
        if (charSequence instanceof Spanned) {
            Spanned spanned = (Spanned)charSequence;
            SpannableBuilder.iterate(spanned instanceof SpannedReversed, spanned.getSpans(0, spanned.length(), Object.class), (Action)new 1(this, n, spanned));
        }
    }

    private static void iterate(boolean bl, Object[] arrobject, Action action) {
        block4 : {
            int n = arrobject != null ? arrobject.length : 0;
            if (n <= 0) break block4;
            if (bl) {
                for (int i = n - 1; i >= 0; --i) {
                    action.apply(arrobject[i]);
                }
            } else {
                for (int i = 0; i < n; ++i) {
                    action.apply(arrobject[i]);
                }
            }
        }
    }

    public SpannableBuilder append(char c) {
        this.builder.append(c);
        return this;
    }

    public SpannableBuilder append(CharSequence charSequence) {
        this.copySpans(this.length(), charSequence);
        this.builder.append((CharSequence)charSequence.toString());
        return this;
    }

    public SpannableBuilder append(CharSequence charSequence, Object object) {
        int n = this.length();
        this.append(charSequence);
        this.setSpan(object, n);
        return this;
    }

    public SpannableBuilder append(CharSequence charSequence, Object object, int n) {
        int n2 = this.length();
        this.append(charSequence);
        this.setSpan(object, n2, this.length(), n);
        return this;
    }

    public SpannableBuilder append(String string2) {
        this.builder.append((CharSequence)string2);
        return this;
    }

    public char charAt(int n) {
        return this.builder.charAt(n);
    }

    public char lastChar() {
        return this.builder.charAt(-1 + this.length());
    }

    public int length() {
        return this.builder.length();
    }

    public CharSequence removeFromEnd(int n) {
        Span span;
        int n2 = this.length();
        SpannableStringBuilderImpl spannableStringBuilderImpl = new SpannableStringBuilderImpl(this.builder.subSequence(n, n2));
        Iterator iterator = this.spans.iterator();
        while (iterator.hasNext() && (span = (Span)iterator.next()) != null) {
            if (span.start < n || span.end > n2) continue;
            spannableStringBuilderImpl.setSpan(span.what, span.start - n, span.end - n, 33);
            iterator.remove();
        }
        this.builder.replace(n, n2, (CharSequence)"");
        return spannableStringBuilderImpl;
    }

    public SpannableBuilder setSpan(Object object, int n) {
        return this.setSpan(object, n, this.length());
    }

    public SpannableBuilder setSpan(Object object, int n, int n2) {
        return this.setSpan(object, n, n2, 33);
    }

    public SpannableBuilder setSpan(Object object, int n, int n2, int n3) {
        this.spans.push((Object)new Span(object, n, n2, n3));
        return this;
    }

    public CharSequence text() {
        SpannableStringBuilderImpl spannableStringBuilderImpl = new SpannableStringBuilderImpl((CharSequence)this.builder);
        for (Span span : this.spans) {
            spannableStringBuilderImpl.setSpan(span.what, span.start, span.end, span.flags);
        }
        int n = spannableStringBuilderImpl.length();
        if (n > 0) {
            int n2 = 0;
            for (int i = n - 1; i >= 0 && Character.isWhitespace((char)spannableStringBuilderImpl.charAt(i)); --i) {
                ++n2;
            }
            if (n2 > 0) {
                spannableStringBuilderImpl.replace(n - n2, n, (CharSequence)"");
            }
        }
        return spannableStringBuilderImpl;
    }

    public String toString() {
        return this.builder.toString();
    }

    private static interface Action {
        public void apply(Object var1);
    }

    static class Span {
        int end;
        final int flags;
        int start;
        final Object what;

        Span(Object object, int n, int n2, int n3) {
            this.what = object;
            this.start = n;
            this.end = n2;
            this.flags = n3;
        }
    }

}

