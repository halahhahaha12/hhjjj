/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$Callback
 *  android.os.Looper
 *  android.os.SystemClock
 *  android.text.Spanned
 *  android.text.style.DynamicDrawableSpan
 *  android.view.View
 *  android.view.View$OnAttachStateChangeListener
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 */
package ru.noties.markwon;

import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Spanned;
import android.text.style.DynamicDrawableSpan;
import android.view.View;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import ru.noties.markwon.renderer.R;
import ru.noties.markwon.spans.AsyncDrawable;
import ru.noties.markwon.spans.AsyncDrawableSpan;

abstract class DrawablesScheduler {
    private DrawablesScheduler() {
    }

    private static List<AsyncDrawable> extract(TextView textView) {
        List list;
        CharSequence charSequence = textView.getText();
        int n = 0;
        int n2 = charSequence != null ? charSequence.length() : 0;
        if (n2 != 0 && charSequence instanceof Spanned) {
            DynamicDrawableSpan[] arrdynamicDrawableSpan;
            list = new ArrayList(2);
            Spanned spanned = (Spanned)charSequence;
            AsyncDrawableSpan[] arrasyncDrawableSpan = (AsyncDrawableSpan[])spanned.getSpans(0, n2, AsyncDrawableSpan.class);
            if (arrasyncDrawableSpan != null && arrasyncDrawableSpan.length > 0) {
                int n3 = arrasyncDrawableSpan.length;
                for (int i = 0; i < n3; ++i) {
                    list.add((Object)arrasyncDrawableSpan[i].getDrawable());
                }
            }
            if ((arrdynamicDrawableSpan = (DynamicDrawableSpan[])spanned.getSpans(0, n2, DynamicDrawableSpan.class)) != null && arrdynamicDrawableSpan.length > 0) {
                int n4 = arrdynamicDrawableSpan.length;
                while (n < n4) {
                    Drawable drawable2 = arrdynamicDrawableSpan[n].getDrawable();
                    if (drawable2 != null && drawable2 instanceof AsyncDrawable) {
                        list.add((Object)((AsyncDrawable)drawable2));
                    }
                    ++n;
                }
            }
            if (list.size() == 0) {
                return Collections.EMPTY_LIST;
            }
        } else {
            list = Collections.EMPTY_LIST;
        }
        return list;
    }

    static void schedule(final TextView textView) {
        List<AsyncDrawable> list = DrawablesScheduler.extract(textView);
        if (list.size() > 0) {
            if (textView.getTag(R.id.markwon_drawables_scheduler) == null) {
                View.OnAttachStateChangeListener onAttachStateChangeListener = new View.OnAttachStateChangeListener(){

                    public void onViewAttachedToWindow(View view) {
                    }

                    public void onViewDetachedFromWindow(View view) {
                        DrawablesScheduler.unschedule(textView);
                        view.removeOnAttachStateChangeListener((View.OnAttachStateChangeListener)this);
                        view.setTag(R.id.markwon_drawables_scheduler, null);
                    }
                };
                textView.addOnAttachStateChangeListener(onAttachStateChangeListener);
                textView.setTag(R.id.markwon_drawables_scheduler, (Object)onAttachStateChangeListener);
            }
            for (AsyncDrawable asyncDrawable : list) {
                asyncDrawable.setCallback2(new DrawableCallbackImpl(textView, asyncDrawable.getBounds()));
            }
        }
    }

    static void unschedule(TextView textView) {
        Iterator iterator = DrawablesScheduler.extract(textView).iterator();
        while (iterator.hasNext()) {
            ((AsyncDrawable)((Object)iterator.next())).setCallback2(null);
        }
    }

    private static class DrawableCallbackImpl
    implements Drawable.Callback {
        private Rect previousBounds;
        private final TextView view;

        DrawableCallbackImpl(TextView textView, Rect rect) {
            this.view = textView;
            this.previousBounds = new Rect(rect);
        }

        public void invalidateDrawable(final Drawable drawable2) {
            if (Looper.myLooper() != Looper.getMainLooper()) {
                this.view.post(new Runnable(){

                    public void run() {
                        DrawableCallbackImpl.this.invalidateDrawable(drawable2);
                    }
                });
                return;
            }
            Rect rect = drawable2.getBounds();
            if (!this.previousBounds.equals((Object)rect)) {
                TextView textView = this.view;
                textView.setText(textView.getText());
                this.previousBounds = new Rect(rect);
                return;
            }
            this.view.postInvalidate();
        }

        public void scheduleDrawable(Drawable drawable2, Runnable runnable, long l) {
            long l2 = l - SystemClock.uptimeMillis();
            this.view.postDelayed(runnable, l2);
        }

        public void unscheduleDrawable(Drawable drawable2, Runnable runnable) {
            this.view.removeCallbacks(runnable);
        }

    }

}

