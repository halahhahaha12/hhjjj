/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.Spanned
 *  android.text.TextUtils
 *  android.view.View
 *  android.view.View$OnAttachStateChangeListener
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  ru.noties.markwon.TableRowsScheduler$2
 */
package ru.noties.markwon;

import android.text.Spanned;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import ru.noties.markwon.TableRowsScheduler;
import ru.noties.markwon.renderer.R;
import ru.noties.markwon.spans.TableRowSpan;

abstract class TableRowsScheduler {
    private TableRowsScheduler() {
    }

    private static Object[] extract(TextView textView) {
        CharSequence charSequence = textView.getText();
        if (!TextUtils.isEmpty((CharSequence)charSequence) && charSequence instanceof Spanned) {
            return ((Spanned)charSequence).getSpans(0, charSequence.length(), TableRowSpan.class);
        }
        return null;
    }

    static void schedule(final TextView textView) {
        Object[] arrobject = TableRowsScheduler.extract(textView);
        if (arrobject != null && arrobject.length > 0) {
            if (textView.getTag(R.id.markwon_tables_scheduler) == null) {
                View.OnAttachStateChangeListener onAttachStateChangeListener = new View.OnAttachStateChangeListener(){

                    public void onViewAttachedToWindow(View view) {
                    }

                    public void onViewDetachedFromWindow(View view) {
                        TableRowsScheduler.unschedule(textView);
                        textView.removeOnAttachStateChangeListener((View.OnAttachStateChangeListener)this);
                        textView.setTag(R.id.markwon_tables_scheduler, null);
                    }
                };
                textView.addOnAttachStateChangeListener(onAttachStateChangeListener);
                textView.setTag(R.id.markwon_tables_scheduler, (Object)onAttachStateChangeListener);
            }
            2 var3_3 = new 2(textView);
            int n = arrobject.length;
            for (int i = 0; i < n; ++i) {
                ((TableRowSpan)((Object)arrobject[i])).invalidator((TableRowSpan.Invalidator)var3_3);
            }
        }
    }

    static void unschedule(TextView textView) {
        Object[] arrobject = TableRowsScheduler.extract(textView);
        if (arrobject != null && arrobject.length > 0) {
            int n = arrobject.length;
            for (int i = 0; i < n; ++i) {
                ((TableRowSpan)((Object)arrobject[i])).invalidator(null);
            }
        }
    }

}

