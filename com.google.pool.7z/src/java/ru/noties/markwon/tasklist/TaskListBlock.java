/*
 * Decompiled with CFR 0.0.
 */
package ru.noties.markwon.tasklist;

import org.commonmark.node.CustomBlock;

public class TaskListBlock
extends CustomBlock {
}

