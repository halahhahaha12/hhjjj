/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ru.noties.markwon.tasklist;

import org.commonmark.parser.Parser;
import org.commonmark.parser.block.BlockParserFactory;
import ru.noties.markwon.tasklist.TaskListBlockParser;

public class TaskListExtension
implements Parser.ParserExtension {
    public static TaskListExtension create() {
        return new TaskListExtension();
    }

    @Override
    public void extend(Parser.Builder builder) {
        builder.customBlockParserFactory(new TaskListBlockParser.Factory());
    }
}

