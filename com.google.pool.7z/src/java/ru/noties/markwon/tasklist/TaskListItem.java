/*
 * Decompiled with CFR 0.0.
 */
package ru.noties.markwon.tasklist;

import org.commonmark.node.CustomNode;

public class TaskListItem
extends CustomNode {
    private boolean done;
    private int indent;

    public TaskListItem done(boolean bl) {
        this.done = bl;
        return this;
    }

    public boolean done() {
        return this.done;
    }

    public int indent() {
        return this.indent;
    }

    public TaskListItem indent(int n) {
        this.indent = n;
        return this;
    }
}

