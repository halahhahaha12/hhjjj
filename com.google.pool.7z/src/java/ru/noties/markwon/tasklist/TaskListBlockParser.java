/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package ru.noties.markwon.tasklist;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.commonmark.node.Block;
import org.commonmark.node.Node;
import org.commonmark.parser.InlineParser;
import org.commonmark.parser.block.AbstractBlockParser;
import org.commonmark.parser.block.AbstractBlockParserFactory;
import org.commonmark.parser.block.BlockContinue;
import org.commonmark.parser.block.BlockParser;
import org.commonmark.parser.block.BlockStart;
import org.commonmark.parser.block.MatchedBlockParser;
import org.commonmark.parser.block.ParserState;
import ru.noties.markwon.tasklist.TaskListBlock;
import ru.noties.markwon.tasklist.TaskListItem;

class TaskListBlockParser
extends AbstractBlockParser {
    private static final Pattern PATTERN = Pattern.compile((String)"\\s*-\\s+\\[(x|X|\\s)\\]\\s+(.*)");
    private final TaskListBlock block = new TaskListBlock();
    private int indent;
    private final List<Item> items;

    TaskListBlockParser(String string2, int n) {
        ArrayList arrayList;
        this.items = arrayList = new ArrayList(3);
        this.indent = 0;
        arrayList.add(new Object(string2, n){
            final int indent;
            final String line;
            {
                this.line = string2;
                this.indent = n;
            }
        });
        this.indent = n;
    }

    private static boolean isDone(String string2) {
        return "X".equals((Object)string2) || "x".equals((Object)string2);
        {
        }
    }

    private static int length(CharSequence charSequence) {
        if (charSequence != null) {
            return charSequence.length();
        }
        return 0;
    }

    private static String line(ParserState parserState) {
        CharSequence charSequence = parserState.getLine();
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    @Override
    public void addLine(CharSequence charSequence) {
        if (TaskListBlockParser.length(charSequence) > 0) {
            this.items.add(new /* invalid duplicate definition of identical inner class */);
        }
    }

    @Override
    public Block getBlock() {
        return this.block;
    }

    @Override
    public void parseInlines(InlineParser inlineParser) {
        for (Item item : this.items) {
            Matcher matcher = PATTERN.matcher((CharSequence)item.line);
            if (!matcher.matches()) continue;
            TaskListItem taskListItem = new TaskListItem().done(TaskListBlockParser.isDone(matcher.group(1))).indent(item.indent / 2);
            inlineParser.parse(matcher.group(2), taskListItem);
            this.block.appendChild(taskListItem);
        }
    }

    @Override
    public BlockContinue tryContinue(ParserState parserState) {
        int n;
        String string2 = TaskListBlockParser.line(parserState);
        int n2 = parserState.getIndent();
        if (n2 > (n = this.indent)) {
            this.indent = n + 2;
        } else if (n2 < n && n > 1) {
            this.indent = n - 2;
        }
        if (string2 != null && string2.length() > 0 && PATTERN.matcher((CharSequence)string2).matches()) {
            return BlockContinue.atIndex(parserState.getIndex());
        }
        return BlockContinue.finished();
    }

    static class Factory
    extends AbstractBlockParserFactory {
        Factory() {
        }

        @Override
        public BlockStart tryStart(ParserState parserState, MatchedBlockParser matchedBlockParser) {
            String string2 = TaskListBlockParser.line(parserState);
            if (string2 != null && string2.length() > 0 && PATTERN.matcher((CharSequence)string2).matches()) {
                int n = string2.length();
                int n2 = parserState.getIndex();
                if (n2 != 0) {
                    n = n2 + (n - n2);
                }
                BlockParser[] arrblockParser = new BlockParser[]{new TaskListBlockParser(string2, parserState.getIndent())};
                return BlockStart.of(arrblockParser).atIndex(n);
            }
            return BlockStart.none();
        }
    }

}

