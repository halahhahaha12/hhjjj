/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package ru.noties.markwon;

import ru.noties.markwon.SyntaxHighlight;

class SyntaxHighlightNoOp
implements SyntaxHighlight {
    SyntaxHighlightNoOp() {
    }

    @Override
    public CharSequence highlight(String string2, String string3) {
        return string3;
    }
}

