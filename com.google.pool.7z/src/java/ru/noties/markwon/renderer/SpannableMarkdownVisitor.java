/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.Spanned
 *  android.text.TextUtils
 *  android.text.style.StrikethroughSpan
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayDeque
 *  java.util.ArrayList
 *  java.util.Deque
 *  java.util.List
 */
package ru.noties.markwon.renderer;

import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.StrikethroughSpan;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import org.commonmark.ext.gfm.strikethrough.Strikethrough;
import org.commonmark.ext.gfm.tables.TableBody;
import org.commonmark.ext.gfm.tables.TableCell;
import org.commonmark.ext.gfm.tables.TableRow;
import org.commonmark.node.AbstractVisitor;
import org.commonmark.node.Block;
import org.commonmark.node.BlockQuote;
import org.commonmark.node.BulletList;
import org.commonmark.node.Code;
import org.commonmark.node.CustomBlock;
import org.commonmark.node.CustomNode;
import org.commonmark.node.Emphasis;
import org.commonmark.node.FencedCodeBlock;
import org.commonmark.node.HardLineBreak;
import org.commonmark.node.Heading;
import org.commonmark.node.HtmlBlock;
import org.commonmark.node.HtmlInline;
import org.commonmark.node.Image;
import org.commonmark.node.IndentedCodeBlock;
import org.commonmark.node.Link;
import org.commonmark.node.ListBlock;
import org.commonmark.node.ListItem;
import org.commonmark.node.Node;
import org.commonmark.node.OrderedList;
import org.commonmark.node.Paragraph;
import org.commonmark.node.SoftLineBreak;
import org.commonmark.node.StrongEmphasis;
import org.commonmark.node.Text;
import org.commonmark.node.ThematicBreak;
import ru.noties.markwon.SpannableBuilder;
import ru.noties.markwon.SpannableConfiguration;
import ru.noties.markwon.SyntaxHighlight;
import ru.noties.markwon.UrlProcessor;
import ru.noties.markwon.renderer.SpannableMarkdownVisitor;
import ru.noties.markwon.renderer.html.SpannableHtmlParser;
import ru.noties.markwon.spans.AsyncDrawable;
import ru.noties.markwon.spans.AsyncDrawableSpan;
import ru.noties.markwon.spans.BlockQuoteSpan;
import ru.noties.markwon.spans.BulletListItemSpan;
import ru.noties.markwon.spans.CodeSpan;
import ru.noties.markwon.spans.EmphasisSpan;
import ru.noties.markwon.spans.HeadingSpan;
import ru.noties.markwon.spans.LinkSpan;
import ru.noties.markwon.spans.OrderedListItemSpan;
import ru.noties.markwon.spans.SpannableTheme;
import ru.noties.markwon.spans.StrongEmphasisSpan;
import ru.noties.markwon.spans.TableRowSpan;
import ru.noties.markwon.spans.TaskListSpan;
import ru.noties.markwon.spans.ThematicBreakSpan;
import ru.noties.markwon.tasklist.TaskListBlock;
import ru.noties.markwon.tasklist.TaskListItem;

public class SpannableMarkdownVisitor
extends AbstractVisitor {
    private int blockQuoteIndent;
    private final SpannableBuilder builder;
    private final SpannableConfiguration configuration;
    private final Deque<HtmlInlineItem> htmlInlineItems;
    private int listLevel;
    private List<TableRowSpan.Cell> pendingTableRow;
    private boolean tableRowIsHeader;
    private int tableRows;

    public SpannableMarkdownVisitor(SpannableConfiguration spannableConfiguration, SpannableBuilder spannableBuilder) {
        this.configuration = spannableConfiguration;
        this.builder = spannableBuilder;
        this.htmlInlineItems = new ArrayDeque(2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean handleTableNodes(CustomNode customNode) {
        if (customNode instanceof TableBody) {
            this.visitChildren(customNode);
            this.tableRows = 0;
            this.newLine();
            this.builder.append('\n');
            do {
                return true;
                break;
            } while (true);
        }
        if (customNode instanceof TableRow) {
            int n = this.builder.length();
            this.visitChildren(customNode);
            if (this.pendingTableRow == null) return true;
            {
                this.builder.append('\u00a0');
                SpannableTheme spannableTheme = this.configuration.theme();
                List<TableRowSpan.Cell> list = this.pendingTableRow;
                boolean bl = this.tableRowIsHeader;
                boolean bl2 = this.tableRows % 2 == 1;
                TableRowSpan tableRowSpan = new TableRowSpan(spannableTheme, list, bl, bl2);
                int n2 = this.tableRowIsHeader ? 0 : 1 + this.tableRows;
                this.tableRows = n2;
                this.setSpan(n, (Object)tableRowSpan);
                this.newLine();
                this.pendingTableRow = null;
            }
            return true;
        }
        if (!(customNode instanceof TableCell)) return false;
        TableCell tableCell = (TableCell)customNode;
        int n = this.builder.length();
        this.visitChildren(tableCell);
        if (this.pendingTableRow == null) {
            this.pendingTableRow = new ArrayList(2);
        }
        this.pendingTableRow.add((Object)new TableRowSpan.Cell(SpannableMarkdownVisitor.tableCellAlignment(tableCell.getAlignment()), this.builder.removeFromEnd(n)));
        this.tableRowIsHeader = tableCell.isHeader();
        return true;
    }

    private boolean isInTightList(Paragraph paragraph) {
        Node node;
        Block block = paragraph.getParent();
        if (block != null && (node = ((Node)block).getParent()) != null && node instanceof ListBlock) {
            return ((ListBlock)node).isTight();
        }
        return false;
    }

    private void newLine() {
        if (this.builder.length() > 0 && '\n' != this.builder.lastChar()) {
            this.builder.append('\n');
        }
    }

    private void setSpan(int n, Object object) {
        SpannableBuilder spannableBuilder = this.builder;
        spannableBuilder.setSpan(object, n, spannableBuilder.length(), 33);
    }

    private static int tableCellAlignment(TableCell.Alignment alignment) {
        int n;
        block2 : {
            block0 : {
                block1 : {
                    n = 2;
                    if (alignment == null) break block0;
                    int n2 = 1.$SwitchMap$org$commonmark$ext$gfm$tables$TableCell$Alignment[alignment.ordinal()];
                    if (n2 == 1) break block1;
                    if (n2 == n) break block2;
                    break block0;
                }
                return 1;
            }
            n = 0;
        }
        return n;
    }

    private void visitCodeBlock(String string2, String string3) {
        this.newLine();
        int n = this.builder.length();
        this.builder.append('\u00a0').append('\n');
        this.builder.append(this.configuration.syntaxHighlight().highlight(string2, string3));
        this.builder.append('\u00a0').append('\n');
        this.setSpan(n, (Object)new CodeSpan(this.configuration.theme(), true));
        this.newLine();
        this.builder.append('\n');
    }

    private void visitList(Node node) {
        this.newLine();
        this.visitChildren(node);
        this.newLine();
        if (this.listLevel == 0 && this.blockQuoteIndent == 0) {
            this.builder.append('\n');
        }
    }

    @Override
    public void visit(BlockQuote blockQuote) {
        this.newLine();
        if (this.blockQuoteIndent != 0) {
            this.builder.append('\n');
        }
        int n = this.builder.length();
        this.blockQuoteIndent = 1 + this.blockQuoteIndent;
        this.visitChildren(blockQuote);
        this.setSpan(n, new BlockQuoteSpan(this.configuration.theme()));
        this.blockQuoteIndent = -1 + this.blockQuoteIndent;
        this.newLine();
        if (this.blockQuoteIndent == 0) {
            this.builder.append('\n');
        }
    }

    @Override
    public void visit(BulletList bulletList) {
        this.visitList(bulletList);
    }

    @Override
    public void visit(Code code) {
        int n = this.builder.length();
        this.builder.append('\u00a0');
        this.builder.append(code.getLiteral());
        this.builder.append('\u00a0');
        this.setSpan(n, (Object)new CodeSpan(this.configuration.theme(), false));
    }

    @Override
    public void visit(CustomBlock customBlock) {
        if (customBlock instanceof TaskListBlock) {
            this.blockQuoteIndent = 1 + this.blockQuoteIndent;
            this.visitChildren(customBlock);
            this.blockQuoteIndent = -1 + this.blockQuoteIndent;
            this.newLine();
            this.builder.append('\n');
            return;
        }
        super.visit(customBlock);
    }

    @Override
    public void visit(CustomNode customNode) {
        if (customNode instanceof Strikethrough) {
            int n = this.builder.length();
            this.visitChildren(customNode);
            this.setSpan(n, (Object)new StrikethroughSpan());
            return;
        }
        if (customNode instanceof TaskListItem) {
            TaskListItem taskListItem = (TaskListItem)customNode;
            int n = this.builder.length();
            this.blockQuoteIndent += taskListItem.indent();
            this.visitChildren(customNode);
            this.setSpan(n, new TaskListSpan(this.configuration.theme(), this.blockQuoteIndent, taskListItem.done()));
            this.newLine();
            this.blockQuoteIndent -= taskListItem.indent();
            return;
        }
        if (!this.handleTableNodes(customNode)) {
            super.visit(customNode);
        }
    }

    @Override
    public void visit(Emphasis emphasis) {
        int n = this.builder.length();
        this.visitChildren(emphasis);
        this.setSpan(n, (Object)new EmphasisSpan());
    }

    @Override
    public void visit(FencedCodeBlock fencedCodeBlock) {
        this.visitCodeBlock(fencedCodeBlock.getInfo(), fencedCodeBlock.getLiteral());
    }

    @Override
    public void visit(HardLineBreak hardLineBreak) {
        this.newLine();
    }

    @Override
    public void visit(Heading heading) {
        this.newLine();
        int n = this.builder.length();
        this.visitChildren(heading);
        this.setSpan(n, (Object)new HeadingSpan(this.configuration.theme(), heading.getLevel()));
        this.newLine();
        this.builder.append('\n');
    }

    @Override
    public void visit(HtmlBlock htmlBlock) {
        Spanned spanned = this.configuration.htmlParser().getSpanned(null, htmlBlock.getLiteral());
        if (!TextUtils.isEmpty((CharSequence)spanned)) {
            this.builder.append((CharSequence)spanned);
        }
    }

    @Override
    public void visit(HtmlInline htmlInline) {
        SpannableHtmlParser spannableHtmlParser = this.configuration.htmlParser();
        SpannableHtmlParser.Tag tag = spannableHtmlParser.parseTag(htmlInline.getLiteral());
        if (tag != null) {
            boolean bl = tag.voidTag();
            if (!bl && tag.opening()) {
                this.htmlInlineItems.push(new Object(tag, this.builder.length()){
                    final int start;
                    final SpannableHtmlParser.Tag tag;
                    {
                        this.tag = tag;
                        this.start = n;
                    }
                });
                this.visitChildren(htmlInline);
                return;
            }
            if (!bl) {
                if (this.htmlInlineItems.size() > 0) {
                    HtmlInlineItem htmlInlineItem = this.htmlInlineItems.pop();
                    Object object = spannableHtmlParser.getSpanForTag(htmlInlineItem.tag);
                    if (object != null) {
                        this.setSpan(htmlInlineItem.start, object);
                        return;
                    }
                }
            } else {
                Spanned spanned = spannableHtmlParser.getSpanned(tag, htmlInline.getLiteral());
                if (!TextUtils.isEmpty((CharSequence)spanned)) {
                    this.builder.append((CharSequence)spanned);
                    return;
                }
            }
        } else {
            this.visitChildren(htmlInline);
        }
    }

    @Override
    public void visit(Image image) {
        Node node;
        int n = this.builder.length();
        this.visitChildren(image);
        if (n == this.builder.length()) {
            this.builder.append('\ufffc');
        }
        boolean bl = (node = image.getParent()) != null && node instanceof Link;
        String string2 = this.configuration.urlProcessor().process(image.getDestination());
        this.setSpan(n, (Object)new AsyncDrawableSpan(this.configuration.theme(), new AsyncDrawable(string2, this.configuration.asyncDrawableLoader()), 0, bl));
    }

    @Override
    public void visit(IndentedCodeBlock indentedCodeBlock) {
        this.visitCodeBlock(null, indentedCodeBlock.getLiteral());
    }

    @Override
    public void visit(Link link) {
        int n = this.builder.length();
        this.visitChildren(link);
        String string2 = this.configuration.urlProcessor().process(link.getDestination());
        this.setSpan(n, (Object)new LinkSpan(this.configuration.theme(), string2, this.configuration.linkResolver()));
    }

    @Override
    public void visit(ListItem listItem) {
        int n = this.builder.length();
        this.blockQuoteIndent = 1 + this.blockQuoteIndent;
        this.listLevel = 1 + this.listLevel;
        Block block = listItem.getParent();
        if (block instanceof OrderedList) {
            OrderedList orderedList = (OrderedList)block;
            int n2 = orderedList.getStartNumber();
            this.visitChildren(listItem);
            SpannableTheme spannableTheme = this.configuration.theme();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(String.valueOf((int)n2));
            stringBuilder.append(".");
            stringBuilder.append('\u00a0');
            this.setSpan(n, new OrderedListItemSpan(spannableTheme, stringBuilder.toString()));
            orderedList.setStartNumber(1 + orderedList.getStartNumber());
        } else {
            this.visitChildren(listItem);
            this.setSpan(n, new BulletListItemSpan(this.configuration.theme(), -1 + this.listLevel));
        }
        this.blockQuoteIndent = -1 + this.blockQuoteIndent;
        this.listLevel = -1 + this.listLevel;
        this.newLine();
    }

    @Override
    public void visit(OrderedList orderedList) {
        this.visitList(orderedList);
    }

    @Override
    public void visit(Paragraph paragraph) {
        boolean bl = this.isInTightList(paragraph);
        if (!bl) {
            this.newLine();
        }
        this.visitChildren(paragraph);
        if (!bl) {
            this.newLine();
            if (this.blockQuoteIndent == 0) {
                this.builder.append('\n');
            }
        }
    }

    @Override
    public void visit(SoftLineBreak softLineBreak) {
        this.builder.append(' ');
    }

    @Override
    public void visit(StrongEmphasis strongEmphasis) {
        int n = this.builder.length();
        this.visitChildren(strongEmphasis);
        this.setSpan(n, (Object)new StrongEmphasisSpan());
    }

    @Override
    public void visit(Text text) {
        this.builder.append(text.getLiteral());
    }

    @Override
    public void visit(ThematicBreak thematicBreak) {
        this.newLine();
        int n = this.builder.length();
        this.builder.append(' ');
        this.setSpan(n, new ThematicBreakSpan(this.configuration.theme()));
        this.newLine();
        this.builder.append('\n');
    }

}

