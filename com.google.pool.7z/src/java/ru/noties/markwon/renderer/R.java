/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ru.noties.markwon.renderer;

public final class R {
    private R() {
    }

    public static final class id {
        public static final int markwon_drawables_scheduler = 2131296561;
        public static final int markwon_tables_scheduler = 2131296562;

        private id() {
        }
    }

}

