/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  ru.noties.markwon.renderer.SpannableMarkdownVisitor
 */
package ru.noties.markwon.renderer;

import org.commonmark.node.Node;
import org.commonmark.node.Visitor;
import ru.noties.markwon.SpannableBuilder;
import ru.noties.markwon.SpannableConfiguration;
import ru.noties.markwon.renderer.SpannableMarkdownVisitor;

public class SpannableRenderer {
    public CharSequence render(SpannableConfiguration spannableConfiguration, Node node) {
        SpannableBuilder spannableBuilder = new SpannableBuilder();
        node.accept((Visitor)new SpannableMarkdownVisitor(spannableConfiguration, spannableBuilder));
        return spannableBuilder.text();
    }
}

