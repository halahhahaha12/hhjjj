/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package ru.noties.markwon.renderer.html;

import android.text.TextUtils;
import java.util.Map;
import ru.noties.markwon.UrlProcessor;
import ru.noties.markwon.renderer.html.SpannableHtmlParser;
import ru.noties.markwon.spans.LinkSpan;
import ru.noties.markwon.spans.SpannableTheme;

class LinkProvider
implements SpannableHtmlParser.SpanProvider {
    private final LinkSpan.Resolver resolver;
    private final SpannableTheme theme;
    private final UrlProcessor urlProcessor;

    LinkProvider(SpannableTheme spannableTheme, UrlProcessor urlProcessor, LinkSpan.Resolver resolver) {
        this.theme = spannableTheme;
        this.urlProcessor = urlProcessor;
        this.resolver = resolver;
    }

    @Override
    public Object provide(SpannableHtmlParser.Tag tag) {
        String string2 = (String)tag.attributes().get((Object)"href");
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            String string3 = this.urlProcessor.process(string2);
            return new LinkSpan(this.theme, string3, this.resolver);
        }
        return null;
    }
}

