/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package ru.noties.markwon.renderer.html;

public class ImageSize {
    public final Dimension height;
    public final Dimension width;

    public ImageSize(Dimension dimension, Dimension dimension2) {
        this.width = dimension;
        this.height = dimension2;
    }

    public static class Dimension {
        public final String unit;
        public final float value;

        public Dimension(float f, String string2) {
            this.value = f;
            this.unit = string2;
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Dimension{value=");
            stringBuilder.append(this.value);
            stringBuilder.append(", unit='");
            stringBuilder.append(this.unit);
            stringBuilder.append('\'');
            stringBuilder.append('}');
            return stringBuilder.toString();
        }
    }

}

