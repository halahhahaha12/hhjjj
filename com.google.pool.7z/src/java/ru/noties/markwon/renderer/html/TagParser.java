/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Character
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Map
 *  java.util.Set
 */
package ru.noties.markwon.renderer.html;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import ru.noties.markwon.renderer.html.SpannableHtmlParser;

class TagParser {
    private static final Set<String> VOID_TAGS;

    static {
        Object[] arrobject = new String[]{"area", "base", "br", "col", "embed", "hr", "img", "input", "keygen", "link", "meta", "param", "source", "track", "wbr"};
        HashSet hashSet = new HashSet(15);
        Collections.addAll((Collection)hashSet, (Object[])arrobject);
        VOID_TAGS = Collections.unmodifiableSet((Set)hashSet);
    }

    TagParser() {
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    SpannableHtmlParser.Tag parse(String var1_1) {
        var2_2 = var1_1 != null ? var1_1.length() : 0;
        if (var2_2 < 3) {
            return null;
        }
        var3_3 = '<' == var1_1.charAt(0) && '/' == var1_1.charAt(1);
        var4_4 = new StringBuilder();
        var5_5 = null;
        var6_6 = null;
        var7_7 = null;
        var9_9 = '\u0000';
        for (var8_8 = 0; var8_8 < var2_2 && '>' != (var16_10 = var1_1.charAt(var8_8)) && '\\' != var16_10; ++var8_8) {
            if (var5_5 == null) {
                if (Character.isSpaceChar((char)var16_10)) {
                    if (var4_4.length() == 0) continue;
                    var5_5 = var4_4.toString();
                    var4_4.setLength(0);
                    continue;
                }
                if (!Character.isLetterOrDigit((char)var16_10)) continue;
                var4_4.append(var16_10);
                continue;
            }
            if (var6_6 == null) {
                if (Character.isLetterOrDigit((char)var16_10)) {
                    var4_4.append(var16_10);
                    continue;
                }
                if (var4_4.length() <= 0) continue;
                var6_6 = var4_4.toString();
                var4_4.setLength(0);
                continue;
            }
            if (var9_9 == '\u0000') {
                var9_9 = var16_10;
                continue;
            }
            if (var16_10 == var9_9) {
                if (var7_7 == null) {
                    var7_7 = new HashMap(3);
                }
                var7_7.put((Object)var6_6, (Object)var4_4.toString());
                var4_4.setLength(0);
                var6_6 = null;
                var9_9 = '\u0000';
                continue;
            }
            var4_4.append(var16_10);
        }
        if (var4_4.length() <= 0) ** GOTO lbl49
        if (var5_5 == null) {
            var10_11 = var4_4.toString();
        } else {
            if (var6_6 != null) {
                if (var7_7 == null) {
                    var7_7 = new HashMap(3);
                }
                var7_7.put(var6_6, (Object)var4_4.toString());
            }
lbl49: // 4 sources:
            var10_11 = var5_5;
        }
        if (var10_11 == null) {
            return null;
        }
        var11_12 = var3_3 == false && TagParser.VOID_TAGS.contains((Object)var10_11) != false;
        var12_13 = var7_7 != null && var7_7.size() != 0 ? Collections.unmodifiableMap((Map)var7_7) : Collections.EMPTY_MAP;
        var13_14 = var12_13;
        return new SpannableHtmlParser.Tag(var1_1, var10_11, (Map<String, String>)var13_14, var3_3 ^ true, var11_12);
    }
}

