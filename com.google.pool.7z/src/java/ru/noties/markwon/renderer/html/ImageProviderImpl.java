/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.SpannableString
 *  android.text.Spanned
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Float
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Map
 */
package ru.noties.markwon.renderer.html;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import ru.noties.markwon.UrlProcessor;
import ru.noties.markwon.renderer.html.ImageSize;
import ru.noties.markwon.renderer.html.ImageSizeResolver;
import ru.noties.markwon.renderer.html.SpannableHtmlParser;
import ru.noties.markwon.spans.AsyncDrawable;
import ru.noties.markwon.spans.AsyncDrawableSpan;
import ru.noties.markwon.spans.SpannableTheme;

class ImageProviderImpl
implements SpannableHtmlParser.ImageProvider {
    private final ImageSizeResolver imageSizeResolver;
    private final AsyncDrawable.Loader loader;
    private final SpannableTheme theme;
    private final UrlProcessor urlProcessor;

    ImageProviderImpl(SpannableTheme spannableTheme, AsyncDrawable.Loader loader, UrlProcessor urlProcessor, ImageSizeResolver imageSizeResolver) {
        this.theme = spannableTheme;
        this.loader = loader;
        this.urlProcessor = urlProcessor;
        this.imageSizeResolver = imageSizeResolver;
    }

    private static String extractDimension(String string2, Map<String, String> map, StyleProvider styleProvider) {
        String string3 = (String)map.get((Object)string2);
        if (!TextUtils.isEmpty((CharSequence)string3)) {
            return string3;
        }
        return ImageProviderImpl.extractDimensionFromStyle(string2, styleProvider);
    }

    private static String extractDimensionFromStyle(String string2, StyleProvider styleProvider) {
        return (String)styleProvider.attributes().get((Object)string2);
    }

    private static ImageSize.Dimension parseDimension(String string2) {
        ImageSize.Dimension dimension;
        int n;
        int n2;
        String string3;
        block8 : {
            int n3 = string2 != null ? string2.length() : 0;
            dimension = null;
            if (n3 == 0) {
                return null;
            }
            for (n = n2 = n3 - 1; n >= 0; --n) {
                if (!Character.isDigit((char)string2.charAt(n))) {
                    continue;
                }
                break block8;
            }
            n = -1;
        }
        if (n == -1) {
            return null;
        }
        if (n == n2) {
            string3 = null;
        } else {
            int n4 = n + 1;
            String string4 = string2.substring(0, n4);
            string3 = string2.substring(n4);
            string2 = string4;
        }
        try {
            ImageSize.Dimension dimension2;
            dimension = dimension2 = new ImageSize.Dimension(Float.parseFloat((String)string2), string3);
        }
        catch (NumberFormatException numberFormatException) {}
        return dimension;
    }

    private static ImageSize parseImageSize(Map<String, String> map) {
        Object object = new Object((String)map.get((Object)"style")){
            private Map<String, String> attributes;
            private final String style;
            {
                this.style = string2;
            }

            Map<String, String> attributes() {
                Map<String, String> map = this.attributes;
                if (map != null) {
                    return map;
                }
                if (TextUtils.isEmpty((CharSequence)this.style)) {
                    Map map2;
                    this.attributes = map2 = Collections.emptyMap();
                    return map2;
                }
                String[] arrstring = this.style.split(";");
                HashMap hashMap = new HashMap(arrstring.length);
                for (String string2 : arrstring) {
                    String[] arrstring2;
                    if (TextUtils.isEmpty((CharSequence)string2) || (arrstring2 = string2.split(":")).length != 2) continue;
                    hashMap.put((Object)arrstring2[0].trim(), (Object)arrstring2[1].trim());
                }
                this.attributes = hashMap;
                return hashMap;
            }
        };
        ImageSize.Dimension dimension = ImageProviderImpl.parseDimension(ImageProviderImpl.extractDimension("width", map, object));
        ImageSize.Dimension dimension2 = ImageProviderImpl.parseDimension(ImageProviderImpl.extractDimension("height", map, object));
        if (dimension == null && dimension2 == null) {
            return null;
        }
        return new ImageSize(dimension, dimension2);
    }

    @Override
    public Spanned provide(SpannableHtmlParser.Tag tag) {
        Map<String, String> map = tag.attributes();
        String string2 = (String)map.get((Object)"src");
        String string3 = (String)map.get((Object)"alt");
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            String string4 = this.urlProcessor.process(string2);
            if (TextUtils.isEmpty((CharSequence)string3)) {
                string3 = "\ufffc";
            }
            AsyncDrawable asyncDrawable = new AsyncDrawable(string4, this.loader, this.imageSizeResolver, ImageProviderImpl.parseImageSize(map));
            AsyncDrawableSpan asyncDrawableSpan = new AsyncDrawableSpan(this.theme, asyncDrawable);
            SpannableString spannableString = new SpannableString((CharSequence)string3);
            spannableString.setSpan((Object)asyncDrawableSpan, 0, spannableString.length(), 33);
            return spannableString;
        }
        return null;
    }

}

