/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.Spanned
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.Map
 *  ru.noties.markwon.LinkResolverDef
 *  ru.noties.markwon.UrlProcessorNoOp
 *  ru.noties.markwon.renderer.html.BoldProvider
 *  ru.noties.markwon.renderer.html.ImageProviderImpl
 *  ru.noties.markwon.renderer.html.ImageSizeResolverDef
 *  ru.noties.markwon.renderer.html.ItalicsProvider
 *  ru.noties.markwon.renderer.html.LinkProvider
 *  ru.noties.markwon.renderer.html.SpannableHtmlParser$DefaultHtmlParser
 *  ru.noties.markwon.renderer.html.StrikeProvider
 *  ru.noties.markwon.renderer.html.SubScriptProvider
 *  ru.noties.markwon.renderer.html.SuperScriptProvider
 *  ru.noties.markwon.renderer.html.UnderlineProvider
 */
package ru.noties.markwon.renderer.html;

import android.text.Spanned;
import java.util.HashMap;
import java.util.Map;
import ru.noties.markwon.LinkResolverDef;
import ru.noties.markwon.UrlProcessor;
import ru.noties.markwon.UrlProcessorNoOp;
import ru.noties.markwon.renderer.html.BoldProvider;
import ru.noties.markwon.renderer.html.ImageProviderImpl;
import ru.noties.markwon.renderer.html.ImageSizeResolver;
import ru.noties.markwon.renderer.html.ImageSizeResolverDef;
import ru.noties.markwon.renderer.html.ItalicsProvider;
import ru.noties.markwon.renderer.html.LinkProvider;
import ru.noties.markwon.renderer.html.SpannableHtmlParser;
import ru.noties.markwon.renderer.html.StrikeProvider;
import ru.noties.markwon.renderer.html.SubScriptProvider;
import ru.noties.markwon.renderer.html.SuperScriptProvider;
import ru.noties.markwon.renderer.html.TagParser;
import ru.noties.markwon.renderer.html.UnderlineProvider;
import ru.noties.markwon.spans.AsyncDrawable;
import ru.noties.markwon.spans.LinkSpan;
import ru.noties.markwon.spans.SpannableTheme;

public class SpannableHtmlParser {
    private final ImageProvider imageProvider;
    private final HtmlParser parser;
    private final Map<String, SpanProvider> simpleTags;
    private final TagParser tagParser;

    private SpannableHtmlParser(Builder builder) {
        this.simpleTags = builder.simpleTags;
        this.imageProvider = builder.imageProvider;
        this.parser = builder.parser;
        this.tagParser = new TagParser();
    }

    public static Builder builder() {
        return new Builder();
    }

    public static Builder builderWithDefaults(SpannableTheme spannableTheme) {
        return SpannableHtmlParser.builderWithDefaults(spannableTheme, null, null, null, null);
    }

    public static Builder builderWithDefaults(SpannableTheme spannableTheme, AsyncDrawable.Loader loader, UrlProcessor urlProcessor, LinkSpan.Resolver resolver, ImageSizeResolver imageSizeResolver) {
        ImageProviderImpl imageProviderImpl;
        if (urlProcessor == null) {
            urlProcessor = new UrlProcessorNoOp();
        }
        if (resolver == null) {
            resolver = new LinkResolverDef();
        }
        BoldProvider boldProvider = new BoldProvider();
        ItalicsProvider italicsProvider = new ItalicsProvider();
        StrikeProvider strikeProvider = new StrikeProvider();
        if (loader != null) {
            if (imageSizeResolver == null) {
                imageSizeResolver = new ImageSizeResolverDef();
            }
            imageProviderImpl = new ImageProviderImpl(spannableTheme, loader, urlProcessor, imageSizeResolver);
        } else {
            imageProviderImpl = null;
        }
        return new Builder().simpleTag("b", (SpanProvider)boldProvider).simpleTag("strong", (SpanProvider)boldProvider).simpleTag("i", (SpanProvider)italicsProvider).simpleTag("em", (SpanProvider)italicsProvider).simpleTag("cite", (SpanProvider)italicsProvider).simpleTag("dfn", (SpanProvider)italicsProvider).simpleTag("sup", (SpanProvider)new SuperScriptProvider(spannableTheme)).simpleTag("sub", (SpanProvider)new SubScriptProvider(spannableTheme)).simpleTag("u", (SpanProvider)new UnderlineProvider()).simpleTag("del", (SpanProvider)strikeProvider).simpleTag("s", (SpanProvider)strikeProvider).simpleTag("strike", (SpanProvider)strikeProvider).simpleTag("a", (SpanProvider)new LinkProvider(spannableTheme, urlProcessor, resolver)).imageProvider((ImageProvider)imageProviderImpl);
    }

    public static SpannableHtmlParser create(SpannableTheme spannableTheme, AsyncDrawable.Loader loader) {
        return SpannableHtmlParser.builderWithDefaults(spannableTheme, loader, null, null, null).build();
    }

    public static SpannableHtmlParser create(SpannableTheme spannableTheme, AsyncDrawable.Loader loader, UrlProcessor urlProcessor, LinkSpan.Resolver resolver) {
        return SpannableHtmlParser.builderWithDefaults(spannableTheme, loader, urlProcessor, resolver, null).build();
    }

    public static SpannableHtmlParser create(SpannableTheme spannableTheme, AsyncDrawable.Loader loader, UrlProcessor urlProcessor, LinkSpan.Resolver resolver, ImageSizeResolver imageSizeResolver) {
        return SpannableHtmlParser.builderWithDefaults(spannableTheme, loader, urlProcessor, resolver, imageSizeResolver).build();
    }

    public static SpannableHtmlParser create(SpannableTheme spannableTheme, AsyncDrawable.Loader loader, ImageSizeResolver imageSizeResolver) {
        return SpannableHtmlParser.builderWithDefaults(spannableTheme, loader, null, null, imageSizeResolver).build();
    }

    public Object getSpanForTag(Tag tag) {
        SpanProvider spanProvider = (SpanProvider)this.simpleTags.get((Object)tag.name);
        if (spanProvider != null) {
            return spanProvider.provide(tag);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(tag.raw);
        stringBuilder.append("abc</");
        stringBuilder.append(tag.name);
        stringBuilder.append(">");
        String string2 = stringBuilder.toString();
        return this.parser.getSpan(string2);
    }

    public Spanned getSpanned(Tag tag, String string2) {
        ImageProvider imageProvider;
        if (tag != null && "img".equals((Object)tag.name) && (imageProvider = this.imageProvider) != null) {
            return imageProvider.provide(tag);
        }
        return this.parser.parse(string2);
    }

    public Tag parseTag(String string2) {
        return this.tagParser.parse(string2);
    }

    /*
     * Exception performing whole class analysis ignored.
     */
    public static class Builder {
        private ImageProvider imageProvider;
        private HtmlParser parser;
        private final Map<String, SpanProvider> simpleTags = new HashMap(3);

        public Builder() {
        }

        public SpannableHtmlParser build() {
            if (this.parser == null) {
                this.parser = DefaultHtmlParser.create();
            }
            return new SpannableHtmlParser(this);
        }

        public Builder imageProvider(ImageProvider imageProvider) {
            this.imageProvider = imageProvider;
            return this;
        }

        public Builder parser(HtmlParser htmlParser) {
            this.parser = htmlParser;
            return this;
        }

        Builder simpleTag(String string2, SpanProvider spanProvider) {
            this.simpleTags.put((Object)string2, (Object)spanProvider);
            return this;
        }
    }

    public static interface HtmlParser {
        public Object getSpan(String var1);

        public Spanned parse(String var1);
    }

    public static interface ImageProvider {
        public Spanned provide(Tag var1);
    }

    public static interface SpanProvider {
        public Object provide(Tag var1);
    }

    public static class Tag {
        private final Map<String, String> attributes;
        private final String name;
        private final boolean opening;
        private final String raw;
        private final boolean voidTag;

        public Tag(String string2, String string3, Map<String, String> map, boolean bl, boolean bl2) {
            this.raw = string2;
            this.name = string3;
            this.attributes = map;
            this.opening = bl;
            this.voidTag = bl2;
        }

        public Map<String, String> attributes() {
            return this.attributes;
        }

        public String name() {
            return this.name;
        }

        public boolean opening() {
            return this.opening;
        }

        public String raw() {
            return this.raw;
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Tag{raw='");
            stringBuilder.append(this.raw);
            stringBuilder.append('\'');
            stringBuilder.append(", name='");
            stringBuilder.append(this.name);
            stringBuilder.append('\'');
            stringBuilder.append(", attributes=");
            stringBuilder.append(this.attributes);
            stringBuilder.append(", opening=");
            stringBuilder.append(this.opening);
            stringBuilder.append(", voidTag=");
            stringBuilder.append(this.voidTag);
            stringBuilder.append('}');
            return stringBuilder.toString();
        }

        public boolean voidTag() {
            return this.voidTag;
        }
    }

}

