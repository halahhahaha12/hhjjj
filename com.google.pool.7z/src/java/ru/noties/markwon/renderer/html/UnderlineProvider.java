/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.style.UnderlineSpan
 *  java.lang.Object
 */
package ru.noties.markwon.renderer.html;

import android.text.style.UnderlineSpan;
import ru.noties.markwon.renderer.html.SpannableHtmlParser;

class UnderlineProvider
implements SpannableHtmlParser.SpanProvider {
    UnderlineProvider() {
    }

    @Override
    public Object provide(SpannableHtmlParser.Tag tag) {
        return new UnderlineSpan();
    }
}

