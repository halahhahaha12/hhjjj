/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ru.noties.markwon.renderer.html;

import ru.noties.markwon.renderer.html.SpannableHtmlParser;
import ru.noties.markwon.spans.StrongEmphasisSpan;

class BoldProvider
implements SpannableHtmlParser.SpanProvider {
    BoldProvider() {
    }

    @Override
    public Object provide(SpannableHtmlParser.Tag tag) {
        return new StrongEmphasisSpan();
    }
}

