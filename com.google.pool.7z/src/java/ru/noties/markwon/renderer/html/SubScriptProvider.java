/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ru.noties.markwon.renderer.html;

import ru.noties.markwon.renderer.html.SpannableHtmlParser;
import ru.noties.markwon.spans.SpannableTheme;
import ru.noties.markwon.spans.SubScriptSpan;

class SubScriptProvider
implements SpannableHtmlParser.SpanProvider {
    private final SpannableTheme theme;

    public SubScriptProvider(SpannableTheme spannableTheme) {
        this.theme = spannableTheme;
    }

    @Override
    public Object provide(SpannableHtmlParser.Tag tag) {
        return new SubScriptSpan(this.theme);
    }
}

