/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Rect
 *  java.lang.Object
 */
package ru.noties.markwon.renderer.html;

import android.graphics.Rect;
import ru.noties.markwon.renderer.html.ImageSize;

public abstract class ImageSizeResolver {
    public abstract Rect resolveImageSize(ImageSize var1, Rect var2, int var3, float var4);
}

