/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Rect
 *  java.lang.Object
 *  java.lang.String
 */
package ru.noties.markwon.renderer.html;

import android.graphics.Rect;
import ru.noties.markwon.renderer.html.ImageSize;
import ru.noties.markwon.renderer.html.ImageSizeResolver;

public class ImageSizeResolverDef
extends ImageSizeResolver {
    protected static final String UNIT_EM = "em";
    protected static final String UNIT_PERCENT = "%";

    protected int resolveAbsolute(ImageSize.Dimension dimension, int n, float f) {
        if (UNIT_EM.equals((Object)dimension.unit)) {
            n = (int)(0.5f + f * dimension.value);
        }
        return n;
    }

    @Override
    public Rect resolveImageSize(ImageSize imageSize, Rect rect, int n, float f) {
        block6 : {
            Rect rect2;
            block5 : {
                int n2;
                float f2;
                ImageSize.Dimension dimension;
                block4 : {
                    if (imageSize == null) {
                        return rect;
                    }
                    ImageSize.Dimension dimension2 = imageSize.width;
                    dimension = imageSize.height;
                    int n3 = rect.width();
                    n2 = rect.height();
                    f2 = (float)n3 / (float)n2;
                    if (dimension2 == null) break block4;
                    int n4 = UNIT_PERCENT.equals((Object)dimension2.unit) ? (int)(0.5f + (float)n * (dimension2.value / 100.0f)) : this.resolveAbsolute(dimension2, n3, f);
                    int n5 = dimension != null && !UNIT_PERCENT.equals((Object)dimension.unit) ? this.resolveAbsolute(dimension, n2, f) : (int)(0.5f + (float)n4 / f2);
                    rect2 = new Rect(0, 0, n4, n5);
                    break block5;
                }
                if (dimension == null || UNIT_PERCENT.equals((Object)dimension.unit)) break block6;
                int n6 = this.resolveAbsolute(dimension, n2, f);
                rect2 = new Rect(0, 0, (int)(0.5f + f2 * (float)n6), n6);
            }
            rect = rect2;
        }
        return rect;
    }
}

