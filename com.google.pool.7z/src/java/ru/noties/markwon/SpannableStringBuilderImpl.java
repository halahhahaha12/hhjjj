/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.SpannableStringBuilder
 *  java.lang.CharSequence
 */
package ru.noties.markwon;

import android.text.SpannableStringBuilder;
import ru.noties.markwon.SpannedReversed;

class SpannableStringBuilderImpl
extends SpannableStringBuilder
implements SpannedReversed {
    SpannableStringBuilderImpl(CharSequence charSequence) {
        super(charSequence);
    }
}

