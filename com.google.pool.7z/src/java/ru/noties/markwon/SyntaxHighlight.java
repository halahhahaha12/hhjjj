/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package ru.noties.markwon;

public interface SyntaxHighlight {
    public CharSequence highlight(String var1, String var2);
}

