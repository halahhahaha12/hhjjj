/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.Spanned
 *  java.lang.Object
 */
package ru.noties.markwon;

import android.text.Spanned;

interface SpannedReversed
extends Spanned {
}

