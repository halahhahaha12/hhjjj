/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.net.MalformedURLException
 *  java.net.URL
 */
package ru.noties.markwon;

import java.net.MalformedURLException;
import java.net.URL;
import ru.noties.markwon.UrlProcessor;

public class UrlProcessorRelativeToAbsolute
implements UrlProcessor {
    private final URL base;

    public UrlProcessorRelativeToAbsolute(String string2) {
        this.base = UrlProcessorRelativeToAbsolute.obtain(string2);
    }

    private static URL obtain(String string2) {
        try {
            URL uRL = new URL(string2);
            return uRL;
        }
        catch (MalformedURLException malformedURLException) {
            malformedURLException.printStackTrace();
            return null;
        }
    }

    @Override
    public String process(String string2) {
        if (this.base != null) {
            try {
                String string3 = new URL(this.base, string2).toString();
                return string3;
            }
            catch (MalformedURLException malformedURLException) {
                malformedURLException.printStackTrace();
            }
        }
        return string2;
    }
}

