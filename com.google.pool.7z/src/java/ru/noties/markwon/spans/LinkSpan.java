/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextPaint
 *  android.text.style.URLSpan
 *  android.view.View
 *  java.lang.Object
 *  java.lang.String
 */
package ru.noties.markwon.spans;

import android.text.TextPaint;
import android.text.style.URLSpan;
import android.view.View;
import ru.noties.markwon.spans.SpannableTheme;

public class LinkSpan
extends URLSpan {
    private final String link;
    private final Resolver resolver;
    private final SpannableTheme theme;

    public LinkSpan(SpannableTheme spannableTheme, String string2, Resolver resolver) {
        super(string2);
        this.theme = spannableTheme;
        this.link = string2;
        this.resolver = resolver;
    }

    public void onClick(View view) {
        this.resolver.resolve(view, this.link);
    }

    public void updateDrawState(TextPaint textPaint) {
        this.theme.applyLinkStyle(textPaint);
    }

    public static interface Resolver {
        public void resolve(View var1, String var2);
    }

}

