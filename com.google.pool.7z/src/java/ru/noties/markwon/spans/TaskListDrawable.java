/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.drawable.Drawable
 *  java.lang.Math
 *  java.lang.Object
 */
package ru.noties.markwon.spans;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

public class TaskListDrawable
extends Drawable {
    private static final Point POINT_0 = new Point(0.15277778f, 0.45833334f);
    private static final Point POINT_1 = new Point(0.3888889f, 0.6944444f);
    private static final Point POINT_2 = new Point(0.8472222f, 0.2638889f);
    private final Paint checkMarkPaint;
    private final Path checkMarkPath;
    private final int checkedFillColor;
    private boolean isChecked;
    private final int normalOutlineColor;
    private final Paint paint = new Paint(1);
    private final RectF rectF = new RectF();

    public TaskListDrawable(int n, int n2, int n3) {
        Paint paint;
        this.checkMarkPaint = paint = new Paint(1);
        this.checkMarkPath = new Path();
        this.checkedFillColor = n;
        this.normalOutlineColor = n2;
        paint.setColor(n3);
        paint.setStyle(Paint.Style.STROKE);
    }

    public void draw(Canvas canvas) {
        int n;
        Paint.Style style2;
        if (this.isChecked) {
            style2 = Paint.Style.FILL_AND_STROKE;
            n = this.checkedFillColor;
        } else {
            style2 = Paint.Style.STROKE;
            n = this.normalOutlineColor;
        }
        this.paint.setStyle(style2);
        this.paint.setColor(n);
        Rect rect = this.getBounds();
        float f = ((float)rect.width() - this.rectF.width()) / 2.0f;
        float f2 = ((float)rect.height() - this.rectF.height()) / 2.0f;
        float f3 = this.rectF.width() / 8.0f;
        int n2 = canvas.save();
        try {
            canvas.translate(f, f2);
            canvas.drawRoundRect(this.rectF, f3, f3, this.paint);
            if (this.isChecked) {
                canvas.drawPath(this.checkMarkPath, this.checkMarkPaint);
            }
            return;
        }
        finally {
            canvas.restoreToCount(n2);
        }
    }

    public int getOpacity() {
        return -1;
    }

    public boolean isStateful() {
        return true;
    }

    protected void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        float f = Math.min((int)rect.width(), (int)rect.height());
        float f2 = f / 8.0f;
        float f3 = f - f2;
        this.rectF.set(0.0f, 0.0f, f3, f3);
        this.paint.setStrokeWidth(f2);
        this.checkMarkPaint.setStrokeWidth(f2);
        this.checkMarkPath.reset();
        POINT_0.moveTo(this.checkMarkPath, f3);
        POINT_1.lineTo(this.checkMarkPath, f3);
        POINT_2.lineTo(this.checkMarkPath, f3);
    }

    protected boolean onStateChange(int[] arrn) {
        boolean bl;
        int n = arrn != null ? arrn.length : 0;
        if (n > 0) {
            for (int i = 0; i < n; ++i) {
                if (16842912 != arrn[i]) continue;
                bl = true;
                break;
            }
        } else {
            bl = false;
        }
        boolean bl2 = this.isChecked;
        boolean bl3 = false;
        if (bl != bl2) {
            bl3 = true;
        }
        if (bl3) {
            this.invalidateSelf();
            this.isChecked = bl;
        }
        return bl3;
    }

    public void setAlpha(int n) {
        this.paint.setAlpha(n);
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.paint.setColorFilter(colorFilter);
    }

    private static class Point {
        final float x;
        final float y;

        Point(float f, float f2) {
            this.x = f;
            this.y = f2;
        }

        void lineTo(Path path, float f) {
            path.lineTo(f * this.x, f * this.y);
        }

        void moveTo(Path path, float f) {
            path.moveTo(f * this.x, f * this.y);
        }
    }

}

