/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.drawable.Drawable
 *  android.text.Layout
 *  android.text.style.LeadingMarginSpan
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.Throwable
 */
package ru.noties.markwon.spans;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.text.style.LeadingMarginSpan;
import ru.noties.markwon.spans.LeadingMarginUtils;
import ru.noties.markwon.spans.SpannableTheme;

public class TaskListSpan
implements LeadingMarginSpan {
    private static final int[] STATE_CHECKED = new int[]{16842912};
    private static final int[] STATE_NONE = new int[0];
    private final int blockIndent;
    private final boolean isDone;
    private final SpannableTheme theme;

    public TaskListSpan(SpannableTheme spannableTheme, int n, boolean bl) {
        this.theme = spannableTheme;
        this.blockIndent = n;
        this.isDone = bl;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void drawLeadingMargin(Canvas canvas, Paint paint, int n, int n2, int n3, int n4, int n5, CharSequence charSequence, int n6, int n7, boolean bl, Layout layout2) {
        int n8;
        int n9;
        int n10;
        if (!bl) {
            return;
        }
        if (!LeadingMarginUtils.selfStart(n6, charSequence, this)) {
            return;
        }
        Drawable drawable2 = this.theme.getTaskListDrawable();
        if (drawable2 == null) {
            return;
        }
        int n11 = canvas.save();
        try {
            n9 = this.theme.getBlockMargin();
        }
        catch (Throwable throwable) {
            canvas.restoreToCount(n11);
            throw throwable;
        }
        int n12 = n5 - n3;
        int n13 = (int)(0.5f + 0.75f * (float)n9);
        int n14 = (int)(0.5f + 0.75f * (float)n12);
        drawable2.setBounds(0, 0, n13, n14);
        if (drawable2.isStateful()) {
            int[] arrn = this.isDone ? STATE_CHECKED : STATE_NONE;
            drawable2.setState(arrn);
        }
        if (n2 > 0) {
            n10 = n + n9 * (-1 + this.blockIndent);
            n8 = (n9 - n13) / 2;
        } else {
            n10 = n - n9 * this.blockIndent;
            n8 = (n9 - n13) / 2;
        }
        int n15 = n10 + n8;
        int n16 = n3 + (n12 - n14) / 2;
        canvas.translate((float)n15, (float)n16);
        drawable2.draw(canvas);
        canvas.restoreToCount(n11);
    }

    public int getLeadingMargin(boolean bl) {
        return this.theme.getBlockMargin() * this.blockIndent;
    }
}

