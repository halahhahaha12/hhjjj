/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Rect
 *  android.text.Layout
 *  android.text.TextPaint
 *  android.text.style.LeadingMarginSpan
 *  android.text.style.MetricAffectingSpan
 *  java.lang.CharSequence
 */
package ru.noties.markwon.spans;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.Layout;
import android.text.TextPaint;
import android.text.style.LeadingMarginSpan;
import android.text.style.MetricAffectingSpan;
import ru.noties.markwon.spans.ObjectsPool;
import ru.noties.markwon.spans.SpannableTheme;

public class CodeSpan
extends MetricAffectingSpan
implements LeadingMarginSpan {
    private final boolean multiline;
    private final Paint paint = ObjectsPool.paint();
    private final Rect rect = ObjectsPool.rect();
    private final SpannableTheme theme;

    public CodeSpan(SpannableTheme spannableTheme, boolean bl) {
        this.theme = spannableTheme;
        this.multiline = bl;
    }

    private void apply(TextPaint textPaint) {
        this.theme.applyCodeTextStyle((Paint)textPaint, this.multiline);
    }

    public void drawLeadingMargin(Canvas canvas, Paint paint, int n, int n2, int n3, int n4, int n5, CharSequence charSequence, int n6, int n7, boolean bl, Layout layout2) {
        if (this.multiline) {
            int n8;
            this.paint.setStyle(Paint.Style.FILL);
            this.paint.setColor(this.theme.getCodeBackgroundColor(paint, true));
            if (n2 > 0) {
                n8 = canvas.getWidth();
            } else {
                int n9 = n - canvas.getWidth();
                int n10 = n;
                n = n9;
                n8 = n10;
            }
            this.rect.set(n, n3, n8, n5);
            canvas.drawRect(this.rect, this.paint);
        }
    }

    public int getLeadingMargin(boolean bl) {
        if (this.multiline) {
            return this.theme.getCodeMultilineMargin();
        }
        return 0;
    }

    public void updateDrawState(TextPaint textPaint) {
        this.apply(textPaint);
        if (!this.multiline) {
            textPaint.bgColor = this.theme.getCodeBackgroundColor((Paint)textPaint, false);
        }
    }

    public void updateMeasureState(TextPaint textPaint) {
        this.apply(textPaint);
    }
}

