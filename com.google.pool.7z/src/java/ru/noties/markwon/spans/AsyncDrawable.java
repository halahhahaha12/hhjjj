/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.Rect
 *  android.graphics.drawable.Animatable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$Callback
 *  java.lang.Object
 *  java.lang.String
 */
package ru.noties.markwon.spans;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import ru.noties.markwon.renderer.html.ImageSize;
import ru.noties.markwon.renderer.html.ImageSizeResolver;

public class AsyncDrawable
extends Drawable {
    private Drawable.Callback callback;
    private int canvasWidth;
    private final String destination;
    private final ImageSize imageSize;
    private final ImageSizeResolver imageSizeResolver;
    private final Loader loader;
    private Drawable result;
    private float textSize;

    public AsyncDrawable(String string2, Loader loader) {
        this(string2, loader, null, null);
    }

    public AsyncDrawable(String string2, Loader loader, ImageSizeResolver imageSizeResolver, ImageSize imageSize) {
        this.destination = string2;
        this.loader = loader;
        this.imageSizeResolver = imageSizeResolver;
        this.imageSize = imageSize;
    }

    private Rect resolveBounds() {
        ImageSize imageSize;
        ImageSizeResolver imageSizeResolver = this.imageSizeResolver;
        if (imageSizeResolver != null && (imageSize = this.imageSize) != null) {
            return imageSizeResolver.resolveImageSize(imageSize, this.result.getBounds(), this.canvasWidth, this.textSize);
        }
        Rect rect = this.result.getBounds();
        if (rect.width() > this.canvasWidth) {
            float f = (float)rect.width() / (float)rect.height();
            int n = (int)(0.5f + (float)this.canvasWidth / f);
            rect = new Rect(0, 0, this.canvasWidth, n);
        }
        return rect;
    }

    public void draw(Canvas canvas) {
        if (this.hasResult()) {
            this.result.draw(canvas);
        }
    }

    public String getDestination() {
        return this.destination;
    }

    public int getIntrinsicHeight() {
        if (this.hasResult()) {
            return this.result.getIntrinsicHeight();
        }
        return 0;
    }

    public int getIntrinsicWidth() {
        if (this.hasResult()) {
            return this.result.getIntrinsicWidth();
        }
        return 0;
    }

    public int getOpacity() {
        if (this.hasResult()) {
            return this.result.getOpacity();
        }
        return -2;
    }

    public Drawable getResult() {
        return this.result;
    }

    public boolean hasResult() {
        return this.result != null;
    }

    public void initWithKnownDimensions(int n, float f) {
        this.canvasWidth = n;
        this.textSize = f;
    }

    public boolean isAttached() {
        return this.getCallback() != null;
    }

    public void setAlpha(int n) {
    }

    public void setCallback2(Drawable.Callback callback) {
        this.callback = callback;
        super.setCallback(callback);
        if (callback != null) {
            this.loader.load(this.destination, this);
            return;
        }
        Drawable drawable2 = this.result;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            Drawable drawable3 = this.result;
            if (drawable3 instanceof Animatable) {
                ((Animatable)drawable3).stop();
            }
        }
        this.loader.cancel(this.destination);
    }

    public void setColorFilter(ColorFilter colorFilter) {
    }

    public void setResult(Drawable drawable2) {
        Drawable drawable3 = this.result;
        if (drawable3 != null) {
            drawable3.setCallback(null);
        }
        this.result = drawable2;
        drawable2.setCallback(this.callback);
        Rect rect = this.resolveBounds();
        drawable2.setBounds(rect);
        this.setBounds(rect);
        this.invalidateSelf();
    }

    public static interface Loader {
        public void cancel(String var1);

        public void load(String var1, AsyncDrawable var2);
    }

}

