/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.text.Layout
 *  android.text.style.LeadingMarginSpan
 *  java.lang.CharSequence
 *  java.lang.Object
 */
package ru.noties.markwon.spans;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.Layout;
import android.text.style.LeadingMarginSpan;
import ru.noties.markwon.spans.ObjectsPool;
import ru.noties.markwon.spans.SpannableTheme;

public class ThematicBreakSpan
implements LeadingMarginSpan {
    private final Paint paint = ObjectsPool.paint();
    private final Rect rect = ObjectsPool.rect();
    private final SpannableTheme theme;

    public ThematicBreakSpan(SpannableTheme spannableTheme) {
        this.theme = spannableTheme;
    }

    public void drawLeadingMargin(Canvas canvas, Paint paint, int n, int n2, int n3, int n4, int n5, CharSequence charSequence, int n6, int n7, boolean bl, Layout layout2) {
        int n8;
        int n9 = n3 + (n5 - n3) / 2;
        this.paint.set(paint);
        this.theme.applyThematicBreakStyle(this.paint);
        int n10 = (int)(0.5f + (float)((int)(0.5f + this.paint.getStrokeWidth())) / 2.0f);
        if (n2 > 0) {
            n8 = canvas.getWidth();
        } else {
            int n11 = n - canvas.getWidth();
            n8 = n;
            n = n11;
        }
        this.rect.set(n, n9 - n10, n8, n9 + n10);
        canvas.drawRect(this.rect, this.paint);
    }

    public int getLeadingMargin(boolean bl) {
        return 0;
    }
}

