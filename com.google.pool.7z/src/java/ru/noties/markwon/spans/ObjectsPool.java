/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  java.lang.Object
 */
package ru.noties.markwon.spans;

import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

abstract class ObjectsPool {
    private static final Paint PAINT;
    private static final Rect RECT;
    private static final RectF RECT_F;

    static {
        RECT = new Rect();
        RECT_F = new RectF();
        PAINT = new Paint(1);
    }

    private ObjectsPool() {
    }

    static Paint paint() {
        return PAINT;
    }

    static Rect rect() {
        return RECT;
    }

    static RectF rectF() {
        return RECT_F;
    }
}

