/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.text.Layout
 *  android.text.style.LeadingMarginSpan
 *  java.lang.CharSequence
 *  java.lang.Math
 *  java.lang.Object
 */
package ru.noties.markwon.spans;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.Layout;
import android.text.style.LeadingMarginSpan;
import ru.noties.markwon.spans.ObjectsPool;
import ru.noties.markwon.spans.SpannableTheme;

public class BlockQuoteSpan
implements LeadingMarginSpan {
    private final Paint paint = ObjectsPool.paint();
    private final Rect rect = ObjectsPool.rect();
    private final SpannableTheme theme;

    public BlockQuoteSpan(SpannableTheme spannableTheme) {
        this.theme = spannableTheme;
    }

    public void drawLeadingMargin(Canvas canvas, Paint paint, int n, int n2, int n3, int n4, int n5, CharSequence charSequence, int n6, int n7, boolean bl, Layout layout2) {
        int n8 = this.theme.getBlockQuoteWidth();
        this.theme.applyBlockQuoteStyle(this.paint);
        int n9 = n2 * n8;
        int n10 = n + n9;
        int n11 = n9 + n10;
        int n12 = Math.min((int)n10, (int)n11);
        int n13 = Math.max((int)n10, (int)n11);
        this.rect.set(n12, n3, n13, n5);
        canvas.drawRect(this.rect, this.paint);
    }

    public int getLeadingMargin(boolean bl) {
        return this.theme.getBlockMargin();
    }
}

