/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ru.noties.markwon.spans;

abstract class ColorUtils {
    private ColorUtils() {
    }

    static int applyAlpha(int n, int n2) {
        return n & 16777215 | n2 << 24;
    }
}

