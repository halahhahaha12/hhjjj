/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextPaint
 *  android.text.style.MetricAffectingSpan
 */
package ru.noties.markwon.spans;

import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;
import ru.noties.markwon.spans.SpannableTheme;

public class SuperScriptSpan
extends MetricAffectingSpan {
    private final SpannableTheme theme;

    public SuperScriptSpan(SpannableTheme spannableTheme) {
        this.theme = spannableTheme;
    }

    private void apply(TextPaint textPaint) {
        this.theme.applySuperScriptStyle(textPaint);
    }

    public void updateDrawState(TextPaint textPaint) {
        this.apply(textPaint);
    }

    public void updateMeasureState(TextPaint textPaint) {
        this.apply(textPaint);
    }
}

