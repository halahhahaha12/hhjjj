/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.text.Layout
 *  android.text.TextPaint
 *  android.text.style.LeadingMarginSpan
 *  android.text.style.MetricAffectingSpan
 *  java.lang.CharSequence
 *  java.lang.Object
 */
package ru.noties.markwon.spans;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.Layout;
import android.text.TextPaint;
import android.text.style.LeadingMarginSpan;
import android.text.style.MetricAffectingSpan;
import ru.noties.markwon.spans.LeadingMarginUtils;
import ru.noties.markwon.spans.ObjectsPool;
import ru.noties.markwon.spans.SpannableTheme;

public class HeadingSpan
extends MetricAffectingSpan
implements LeadingMarginSpan {
    private final int level;
    private final Paint paint = ObjectsPool.paint();
    private final Rect rect = ObjectsPool.rect();
    private final SpannableTheme theme;

    public HeadingSpan(SpannableTheme spannableTheme, int n) {
        this.theme = spannableTheme;
        this.level = n;
    }

    private void apply(TextPaint textPaint) {
        this.theme.applyHeadingTextStyle((Paint)textPaint, this.level);
    }

    public void drawLeadingMargin(Canvas canvas, Paint paint, int n, int n2, int n3, int n4, int n5, CharSequence charSequence, int n6, int n7, boolean bl, Layout layout2) {
        int n8 = this.level;
        if ((n8 == 1 || n8 == 2) && LeadingMarginUtils.selfEnd(n7, charSequence, (Object)this)) {
            this.paint.set(paint);
            this.theme.applyHeadingBreakStyle(this.paint);
            float f = this.paint.getStrokeWidth();
            if (f > 0.0f) {
                int n9;
                int n10 = (int)(0.5f + ((float)n5 - f));
                if (n2 > 0) {
                    n9 = canvas.getWidth();
                } else {
                    int n11 = n - canvas.getWidth();
                    n9 = n;
                    n = n11;
                }
                this.rect.set(n, n10, n9, n5);
                canvas.drawRect(this.rect, this.paint);
            }
        }
    }

    public int getLeadingMargin(boolean bl) {
        return 0;
    }

    public void updateDrawState(TextPaint textPaint) {
        this.apply(textPaint);
    }

    public void updateMeasureState(TextPaint textPaint) {
        this.apply(textPaint);
    }
}

