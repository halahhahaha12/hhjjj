/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.text.Layout
 *  android.text.style.LeadingMarginSpan
 *  java.lang.CharSequence
 *  java.lang.Math
 *  java.lang.Object
 */
package ru.noties.markwon.spans;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.Layout;
import android.text.style.LeadingMarginSpan;
import ru.noties.markwon.spans.LeadingMarginUtils;
import ru.noties.markwon.spans.ObjectsPool;
import ru.noties.markwon.spans.SpannableTheme;

public class BulletListItemSpan
implements LeadingMarginSpan {
    private final RectF circle = ObjectsPool.rectF();
    private final int level;
    private final Paint paint = ObjectsPool.paint();
    private final Rect rectangle = ObjectsPool.rect();
    private SpannableTheme theme;

    public BulletListItemSpan(SpannableTheme spannableTheme, int n) {
        this.theme = spannableTheme;
        this.level = n;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void drawLeadingMargin(Canvas canvas, Paint paint, int n, int n2, int n3, int n4, int n5, CharSequence charSequence, int n6, int n7, boolean bl, Layout layout2) {
        if (!bl) return;
        if (!LeadingMarginUtils.selfStart(n6, charSequence, this)) {
            return;
        }
        this.paint.set(paint);
        this.theme.applyListItemStyle(this.paint);
        int n8 = canvas.save();
        int n9 = this.theme.getBlockMargin();
        int n10 = n5 - n3;
        int n11 = this.theme.getBulletWidth(n10);
        int n12 = (n9 - n11) / 2;
        int n13 = (n10 - n11) / 2;
        int n14 = n + n12 * n2;
        int n15 = n14 + n2 * n11;
        try {
            int n16 = Math.min((int)n14, (int)n15);
            int n17 = Math.max((int)n14, (int)n15);
            int n18 = n3 + n13;
            int n19 = n11 + n18;
            int n20 = this.level;
            if (n20 != 0 && n20 != 1) {
                this.rectangle.set(n16, n18, n17, n19);
                this.paint.setStyle(Paint.Style.FILL);
                canvas.drawRect(this.rectangle, this.paint);
                return;
            }
            this.circle.set((float)n16, (float)n18, (float)n17, (float)n19);
            Paint.Style style2 = this.level == 0 ? Paint.Style.FILL : Paint.Style.STROKE;
            this.paint.setStyle(style2);
            canvas.drawOval(this.circle, this.paint);
            return;
        }
        finally {
            canvas.restoreToCount(n8);
        }
    }

    public int getLeadingMargin(boolean bl) {
        return this.theme.getBlockMargin();
    }
}

