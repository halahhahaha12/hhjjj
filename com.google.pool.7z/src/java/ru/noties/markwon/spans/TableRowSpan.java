/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$FontMetricsInt
 *  android.graphics.Rect
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.StaticLayout
 *  android.text.TextPaint
 *  android.text.style.ReplacementSpan
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.annotation.Annotation
 *  java.lang.annotation.Retention
 *  java.lang.annotation.RetentionPolicy
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package ru.noties.markwon.spans;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.style.ReplacementSpan;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import ru.noties.markwon.spans.ObjectsPool;
import ru.noties.markwon.spans.SpannableTheme;

public class TableRowSpan
extends ReplacementSpan {
    public static final int ALIGN_CENTER = 1;
    public static final int ALIGN_LEFT = 0;
    public static final int ALIGN_RIGHT = 2;
    private final List<Cell> cells;
    private final boolean header;
    private int height;
    private Invalidator invalidator;
    private final List<StaticLayout> layouts;
    private final boolean odd;
    private final Paint paint = ObjectsPool.paint();
    private final Rect rect = ObjectsPool.rect();
    private final TextPaint textPaint;
    private final SpannableTheme theme;
    private int width;

    public TableRowSpan(SpannableTheme spannableTheme, List<Cell> list, boolean bl, boolean bl2) {
        this.theme = spannableTheme;
        this.cells = list;
        this.layouts = new ArrayList(list.size());
        this.textPaint = new TextPaint();
        this.header = bl;
        this.odd = bl2;
    }

    private static Layout.Alignment alignment(int n) {
        if (n != 1) {
            if (n != 2) {
                return Layout.Alignment.ALIGN_NORMAL;
            }
            return Layout.Alignment.ALIGN_OPPOSITE;
        }
        return Layout.Alignment.ALIGN_CENTER;
    }

    private void makeNewLayouts() {
        this.textPaint.setFakeBoldText(this.header);
        int n = this.cells.size();
        int n2 = 2 * this.theme.tableCellPadding();
        int n3 = this.width / n - n2;
        this.layouts.clear();
        int n4 = this.cells.size();
        for (int i = 0; i < n4; ++i) {
            Cell cell = (Cell)this.cells.get(i);
            StaticLayout staticLayout = new StaticLayout(cell.text, this.textPaint, n3, TableRowSpan.alignment(cell.alignment), 1.0f, 0.0f, false);
            this.layouts.add((Object)staticLayout);
        }
    }

    private boolean recreateLayouts(int n) {
        return this.width != n;
    }

    public void draw(Canvas canvas, CharSequence charSequence, int n, int n2, float f, int n3, int n4, int n5, Paint paint) {
        int n6;
        Invalidator invalidator;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        if (this.recreateLayouts(canvas.getWidth())) {
            this.width = canvas.getWidth();
            this.textPaint.set(paint);
            this.makeNewLayouts();
        }
        n9 = this.theme.tableCellPadding();
        n8 = this.layouts.size();
        n6 = this.width / n8;
        n10 = n5 - n3;
        n11 = (n10 - this.height) / 4;
        boolean bl = this.odd;
        n7 = 0;
        if (bl) {
            int n12 = canvas.save();
            try {
                this.rect.set(0, 0, this.width, n10);
                this.theme.applyTableOddRowStyle(this.paint);
                canvas.translate(f, (float)(n3 - n11));
                canvas.drawRect(this.rect, this.paint);
            }
            finally {
                canvas.restoreToCount(n12);
            }
        }
        this.theme.applyTableBorderStyle(this.paint);
        boolean bl = this.theme.tableBorderWidth(paint) > 0;
        if (bl) {
            this.rect.set(0, 0, n6, n10);
        }
        int n13 = 0;
        while (n7 < n8) {
            StaticLayout staticLayout = (StaticLayout)this.layouts.get(n7);
            int n14 = canvas.save();
            float f2 = f + (float)(n7 * n6);
            float f3 = n3 - n11;
            try {
                canvas.translate(f2, f3);
                if (bl) {
                    canvas.drawRect(this.rect, this.paint);
                }
                canvas.translate((float)n9, (float)(n9 + n11));
                staticLayout.draw(canvas);
                if (staticLayout.getHeight() > n13) {
                    n13 = staticLayout.getHeight();
                }
                ++n7;
            }
            finally {
                canvas.restoreToCount(n14);
            }
        }
        if (this.height != n13 && (invalidator = this.invalidator) != null) {
            invalidator.invalidate();
        }
    }

    public int getSize(Paint paint, CharSequence charSequence, int n, int n2, Paint.FontMetricsInt fontMetricsInt) {
        if (this.layouts.size() > 0 && fontMetricsInt != null) {
            Iterator iterator = this.layouts.iterator();
            int n3 = 0;
            while (iterator.hasNext()) {
                int n4 = ((StaticLayout)iterator.next()).getHeight();
                if (n4 <= n3) continue;
                n3 = n4;
            }
            this.height = n3;
            fontMetricsInt.ascent = -(n3 + 2 * this.theme.tableCellPadding());
            fontMetricsInt.descent = 0;
            fontMetricsInt.top = fontMetricsInt.ascent;
            fontMetricsInt.bottom = 0;
        }
        return this.width;
    }

    public TableRowSpan invalidator(Invalidator invalidator) {
        this.invalidator = invalidator;
        return this;
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface Alignment {
    }

    public static class Cell {
        final int alignment;
        final CharSequence text;

        public Cell(int n, CharSequence charSequence) {
            this.alignment = n;
            this.text = charSequence;
        }

        public int alignment() {
            return this.alignment;
        }

        public CharSequence text() {
            return this.text;
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cell{alignment=");
            stringBuilder.append(this.alignment);
            stringBuilder.append(", text=");
            stringBuilder.append((Object)this.text);
            stringBuilder.append('}');
            return stringBuilder.toString();
        }
    }

    public static interface Invalidator {
        public void invalidate();
    }

}

