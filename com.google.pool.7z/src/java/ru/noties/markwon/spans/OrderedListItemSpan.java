/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.text.Layout
 *  android.text.style.LeadingMarginSpan
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package ru.noties.markwon.spans;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.Layout;
import android.text.style.LeadingMarginSpan;
import ru.noties.markwon.spans.CanvasUtils;
import ru.noties.markwon.spans.LeadingMarginUtils;
import ru.noties.markwon.spans.SpannableTheme;

public class OrderedListItemSpan
implements LeadingMarginSpan {
    private int margin;
    private final String number;
    private final SpannableTheme theme;

    public OrderedListItemSpan(SpannableTheme spannableTheme, String string2) {
        this.theme = spannableTheme;
        this.number = string2;
    }

    public void drawLeadingMargin(Canvas canvas, Paint paint, int n, int n2, int n3, int n4, int n5, CharSequence charSequence, int n6, int n7, boolean bl, Layout layout2) {
        if (bl) {
            if (!LeadingMarginUtils.selfStart(n6, charSequence, this)) {
                return;
            }
            this.theme.applyListItemStyle(paint);
            int n8 = (int)(0.5f + paint.measureText(this.number));
            int n9 = this.theme.getBlockMargin();
            if (n8 > n9) {
                this.margin = n8;
                n9 = n8;
            } else {
                this.margin = 0;
            }
            int n10 = n2 > 0 ? n + n9 * n2 - n8 : n + n2 * n9 + (n9 - n8);
            float f = CanvasUtils.textCenterY(n3, n5, paint);
            canvas.drawText(this.number, (float)n10, f, paint);
        }
    }

    public int getLeadingMargin(boolean bl) {
        int n = this.margin;
        if (n > 0) {
            return n;
        }
        return this.theme.getBlockMargin();
    }
}

