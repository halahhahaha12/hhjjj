/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Typeface
 *  android.graphics.drawable.Drawable
 *  android.text.TextPaint
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 */
package ru.noties.markwon.spans;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import ru.noties.markwon.spans.ColorUtils;
import ru.noties.markwon.spans.TaskListDrawable;

public class SpannableTheme {
    protected static final int BLOCK_QUOTE_DEF_COLOR_ALPHA = 25;
    protected static final int CODE_DEF_BACKGROUND_COLOR_ALPHA = 25;
    protected static final float CODE_DEF_TEXT_SIZE_RATIO = 0.87f;
    protected static final int HEADING_DEF_BREAK_COLOR_ALPHA = 75;
    private static final float[] HEADING_SIZES = new float[]{2.0f, 1.5f, 1.17f, 1.0f, 0.83f, 0.67f};
    protected static final float SCRIPT_DEF_TEXT_SIZE_RATIO = 0.75f;
    protected static final int TABLE_BORDER_DEF_ALPHA = 75;
    protected static final int TABLE_ODD_ROW_DEF_ALPHA = 22;
    protected static final int THEMATIC_BREAK_DEF_ALPHA = 25;
    protected final int blockMargin;
    protected final int blockQuoteColor;
    protected final int blockQuoteWidth;
    protected final int bulletListItemStrokeWidth;
    protected final int bulletWidth;
    protected final int codeBackgroundColor;
    protected final int codeBlockBackgroundColor;
    protected final int codeBlockTextColor;
    protected final int codeMultilineMargin;
    protected final int codeTextColor;
    protected final int codeTextSize;
    protected final Typeface codeTypeface;
    protected final int headingBreakColor;
    protected final int headingBreakHeight;
    protected final int linkColor;
    protected final int listItemColor;
    protected final float scriptTextSizeRatio;
    protected final int tableBorderColor;
    protected final int tableBorderWidth;
    protected final int tableCellPadding;
    protected final int tableOddRowBackgroundColor;
    protected final Drawable taskListDrawable;
    protected final int thematicBreakColor;
    protected final int thematicBreakHeight;

    protected SpannableTheme(Builder builder) {
        this.linkColor = builder.linkColor;
        this.blockMargin = builder.blockMargin;
        this.blockQuoteWidth = builder.blockQuoteWidth;
        this.blockQuoteColor = builder.blockQuoteColor;
        this.listItemColor = builder.listItemColor;
        this.bulletListItemStrokeWidth = builder.bulletListItemStrokeWidth;
        this.bulletWidth = builder.bulletWidth;
        this.codeTextColor = builder.codeTextColor;
        this.codeBlockTextColor = builder.codeBlockTextColor;
        this.codeBackgroundColor = builder.codeBackgroundColor;
        this.codeBlockBackgroundColor = builder.codeBlockBackgroundColor;
        this.codeMultilineMargin = builder.codeMultilineMargin;
        this.codeTypeface = builder.codeTypeface;
        this.codeTextSize = builder.codeTextSize;
        this.headingBreakHeight = builder.headingBreakHeight;
        this.headingBreakColor = builder.headingBreakColor;
        this.scriptTextSizeRatio = builder.scriptTextSizeRatio;
        this.thematicBreakColor = builder.thematicBreakColor;
        this.thematicBreakHeight = builder.thematicBreakHeight;
        this.tableCellPadding = builder.tableCellPadding;
        this.tableBorderColor = builder.tableBorderColor;
        this.tableBorderWidth = builder.tableBorderWidth;
        this.tableOddRowBackgroundColor = builder.tableOddRowBackgroundColor;
        this.taskListDrawable = builder.taskListDrawable;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static Builder builder(SpannableTheme spannableTheme) {
        return new Builder(spannableTheme);
    }

    public static Builder builderWithDefaults(Context context) {
        int n = SpannableTheme.resolve(context, 16842907);
        int n2 = SpannableTheme.resolve(context, 16842801);
        Dip dip = new Dip(context);
        return new Builder().codeMultilineMargin(dip.toPx(8)).blockMargin(dip.toPx(24)).blockQuoteWidth(dip.toPx(4)).bulletListItemStrokeWidth(dip.toPx(1)).headingBreakHeight(dip.toPx(1)).thematicBreakHeight(dip.toPx(4)).tableCellPadding(dip.toPx(4)).tableBorderWidth(dip.toPx(1)).taskListDrawable(new TaskListDrawable(n, n, n2));
    }

    public static SpannableTheme create(Context context) {
        return SpannableTheme.builderWithDefaults(context).build();
    }

    private static int resolve(Context context, int n) {
        TypedValue typedValue = new TypedValue();
        int[] arrn = new int[]{n};
        TypedArray typedArray = context.obtainStyledAttributes(typedValue.data, arrn);
        try {
            int n2 = typedArray.getColor(0, 0);
            return n2;
        }
        finally {
            typedArray.recycle();
        }
    }

    public void applyBlockQuoteStyle(Paint paint) {
        int n = this.blockQuoteColor;
        if (n == 0) {
            n = ColorUtils.applyAlpha(paint.getColor(), 25);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(n);
    }

    public void applyCodeTextStyle(Paint paint, boolean bl) {
        int n;
        if (bl && (n = this.codeBlockTextColor) != 0) {
            paint.setColor(n);
        } else {
            int n2 = this.codeTextColor;
            if (n2 != 0) {
                paint.setColor(n2);
            }
        }
        Typeface typeface = this.codeTypeface;
        if (typeface != null) {
            paint.setTypeface(typeface);
            int n3 = this.codeTextSize;
            if (n3 != 0) {
                paint.setTextSize((float)n3);
                return;
            }
        } else {
            paint.setTypeface(Typeface.MONOSPACE);
            int n4 = this.codeTextSize;
            float f = n4 != 0 ? (float)n4 : 0.87f * paint.getTextSize();
            paint.setTextSize(f);
        }
    }

    public void applyHeadingBreakStyle(Paint paint) {
        int n = this.headingBreakColor;
        if (n == 0) {
            n = ColorUtils.applyAlpha(paint.getColor(), 75);
        }
        paint.setColor(n);
        paint.setStyle(Paint.Style.FILL);
        int n2 = this.headingBreakHeight;
        if (n2 >= 0) {
            paint.setStrokeWidth((float)n2);
        }
    }

    public void applyHeadingTextStyle(Paint paint, int n) {
        paint.setFakeBoldText(true);
        paint.setTextSize(paint.getTextSize() * HEADING_SIZES[n - 1]);
    }

    public void applyLinkStyle(Paint paint) {
        paint.setUnderlineText(true);
        int n = this.linkColor;
        if (n != 0) {
            paint.setColor(n);
            return;
        }
        if (paint instanceof TextPaint) {
            paint.setColor(((TextPaint)paint).linkColor);
        }
    }

    public void applyLinkStyle(TextPaint textPaint) {
        textPaint.setUnderlineText(true);
        int n = this.linkColor;
        if (n != 0) {
            textPaint.setColor(n);
            return;
        }
        textPaint.setColor(textPaint.linkColor);
    }

    public void applyListItemStyle(Paint paint) {
        int n = this.listItemColor;
        if (n == 0) {
            n = paint.getColor();
        }
        paint.setColor(n);
        int n2 = this.bulletListItemStrokeWidth;
        if (n2 != 0) {
            paint.setStrokeWidth((float)n2);
        }
    }

    public void applySubScriptStyle(TextPaint textPaint) {
        float f = Float.compare((float)this.scriptTextSizeRatio, (float)0.0f) == 0 ? 0.75f : this.scriptTextSizeRatio;
        textPaint.setTextSize(f * textPaint.getTextSize());
        textPaint.baselineShift -= (int)(textPaint.ascent() / 2.0f);
    }

    public void applySuperScriptStyle(TextPaint textPaint) {
        float f = Float.compare((float)this.scriptTextSizeRatio, (float)0.0f) == 0 ? 0.75f : this.scriptTextSizeRatio;
        textPaint.setTextSize(f * textPaint.getTextSize());
        textPaint.baselineShift += (int)(textPaint.ascent() / 2.0f);
    }

    public void applyTableBorderStyle(Paint paint) {
        int n = this.tableBorderColor;
        if (n == 0) {
            n = ColorUtils.applyAlpha(paint.getColor(), 75);
        }
        paint.setColor(n);
        paint.setStyle(Paint.Style.STROKE);
    }

    public void applyTableOddRowStyle(Paint paint) {
        int n = this.tableOddRowBackgroundColor;
        if (n == 0) {
            n = ColorUtils.applyAlpha(paint.getColor(), 22);
        }
        paint.setColor(n);
        paint.setStyle(Paint.Style.FILL);
    }

    public void applyThematicBreakStyle(Paint paint) {
        int n = this.thematicBreakColor;
        if (n == 0) {
            n = ColorUtils.applyAlpha(paint.getColor(), 25);
        }
        paint.setColor(n);
        paint.setStyle(Paint.Style.FILL);
        int n2 = this.thematicBreakHeight;
        if (n2 >= 0) {
            paint.setStrokeWidth((float)n2);
        }
    }

    public int getBlockMargin() {
        return this.blockMargin;
    }

    public int getBlockQuoteWidth() {
        int n = this.blockQuoteWidth;
        if (n == 0) {
            n = (int)(0.5f + 0.25f * (float)this.blockMargin);
        }
        return n;
    }

    public int getBulletWidth(int n) {
        int n2 = Math.min((int)this.blockMargin, (int)n) / 2;
        int n3 = this.bulletWidth;
        if (n3 != 0) {
            if (n3 > n2) {
                return n2;
            }
            n2 = n3;
        }
        return n2;
    }

    public int getCodeBackgroundColor(Paint paint, boolean bl) {
        int n;
        if (bl && (n = this.codeBlockBackgroundColor) != 0) {
            return n;
        }
        int n2 = this.codeBackgroundColor;
        if (n2 != 0) {
            return n2;
        }
        return ColorUtils.applyAlpha(paint.getColor(), 25);
    }

    public int getCodeMultilineMargin() {
        return this.codeMultilineMargin;
    }

    public Drawable getTaskListDrawable() {
        return this.taskListDrawable;
    }

    public int tableBorderWidth(Paint paint) {
        int n = this.tableBorderWidth;
        if (n == -1) {
            n = (int)(0.5f + paint.getStrokeWidth());
        }
        return n;
    }

    public int tableCellPadding() {
        return this.tableCellPadding;
    }

    public static class Builder {
        private int blockMargin;
        private int blockQuoteColor;
        private int blockQuoteWidth;
        private int bulletListItemStrokeWidth;
        private int bulletWidth;
        private int codeBackgroundColor;
        private int codeBlockBackgroundColor;
        private int codeBlockTextColor;
        private int codeMultilineMargin;
        private int codeTextColor;
        private int codeTextSize;
        private Typeface codeTypeface;
        private int headingBreakColor;
        private int headingBreakHeight = -1;
        private int linkColor;
        private int listItemColor;
        private float scriptTextSizeRatio;
        private int tableBorderColor;
        private int tableBorderWidth = -1;
        private int tableCellPadding;
        private int tableOddRowBackgroundColor;
        private Drawable taskListDrawable;
        private int thematicBreakColor;
        private int thematicBreakHeight = -1;

        Builder() {
        }

        Builder(SpannableTheme spannableTheme) {
            this.linkColor = spannableTheme.linkColor;
            this.blockMargin = spannableTheme.blockMargin;
            this.blockQuoteWidth = spannableTheme.blockQuoteWidth;
            this.blockQuoteColor = spannableTheme.blockQuoteColor;
            this.listItemColor = spannableTheme.listItemColor;
            this.bulletListItemStrokeWidth = spannableTheme.bulletListItemStrokeWidth;
            this.bulletWidth = spannableTheme.bulletWidth;
            this.codeTextColor = spannableTheme.codeTextColor;
            this.codeBlockTextColor = spannableTheme.codeBlockTextColor;
            this.codeBackgroundColor = spannableTheme.codeBackgroundColor;
            this.codeBlockBackgroundColor = spannableTheme.codeBlockBackgroundColor;
            this.codeMultilineMargin = spannableTheme.codeMultilineMargin;
            this.codeTypeface = spannableTheme.codeTypeface;
            this.codeTextSize = spannableTheme.codeTextSize;
            this.headingBreakHeight = spannableTheme.headingBreakHeight;
            this.headingBreakColor = spannableTheme.headingBreakColor;
            this.scriptTextSizeRatio = spannableTheme.scriptTextSizeRatio;
            this.thematicBreakColor = spannableTheme.thematicBreakColor;
            this.thematicBreakHeight = spannableTheme.thematicBreakHeight;
            this.tableCellPadding = spannableTheme.tableCellPadding;
            this.tableBorderColor = spannableTheme.tableBorderColor;
            this.tableBorderWidth = spannableTheme.tableBorderWidth;
            this.tableOddRowBackgroundColor = spannableTheme.tableOddRowBackgroundColor;
            this.taskListDrawable = spannableTheme.taskListDrawable;
        }

        public Builder blockMargin(int n) {
            this.blockMargin = n;
            return this;
        }

        public Builder blockQuoteColor(int n) {
            this.blockQuoteColor = n;
            return this;
        }

        public Builder blockQuoteWidth(int n) {
            this.blockQuoteWidth = n;
            return this;
        }

        public SpannableTheme build() {
            return new SpannableTheme(this);
        }

        public Builder bulletListItemStrokeWidth(int n) {
            this.bulletListItemStrokeWidth = n;
            return this;
        }

        public Builder bulletWidth(int n) {
            this.bulletWidth = n;
            return this;
        }

        public Builder codeBackgroundColor(int n) {
            this.codeBackgroundColor = n;
            return this;
        }

        public Builder codeBlockBackgroundColor(int n) {
            this.codeBlockBackgroundColor = n;
            return this;
        }

        public Builder codeBlockTextColor(int n) {
            this.codeBlockTextColor = n;
            return this;
        }

        public Builder codeMultilineMargin(int n) {
            this.codeMultilineMargin = n;
            return this;
        }

        public Builder codeTextColor(int n) {
            this.codeTextColor = n;
            return this;
        }

        public Builder codeTextSize(int n) {
            this.codeTextSize = n;
            return this;
        }

        public Builder codeTypeface(Typeface typeface) {
            this.codeTypeface = typeface;
            return this;
        }

        public Builder headingBreakColor(int n) {
            this.headingBreakColor = n;
            return this;
        }

        public Builder headingBreakHeight(int n) {
            this.headingBreakHeight = n;
            return this;
        }

        public Builder linkColor(int n) {
            this.linkColor = n;
            return this;
        }

        public Builder listItemColor(int n) {
            this.listItemColor = n;
            return this;
        }

        public Builder scriptTextSizeRatio(float f) {
            this.scriptTextSizeRatio = f;
            return this;
        }

        public Builder tableBorderColor(int n) {
            this.tableBorderColor = n;
            return this;
        }

        public Builder tableBorderWidth(int n) {
            this.tableBorderWidth = n;
            return this;
        }

        public Builder tableCellPadding(int n) {
            this.tableCellPadding = n;
            return this;
        }

        public Builder tableOddRowBackgroundColor(int n) {
            this.tableOddRowBackgroundColor = n;
            return this;
        }

        public Builder taskListDrawable(Drawable drawable2) {
            this.taskListDrawable = drawable2;
            return this;
        }

        public Builder thematicBreakColor(int n) {
            this.thematicBreakColor = n;
            return this;
        }

        public Builder thematicBreakHeight(int n) {
            this.thematicBreakHeight = n;
            return this;
        }
    }

    private static class Dip {
        private final float density;

        Dip(Context context) {
            this.density = context.getResources().getDisplayMetrics().density;
        }

        int toPx(int n) {
            return (int)(0.5f + (float)n * this.density);
        }
    }

}

