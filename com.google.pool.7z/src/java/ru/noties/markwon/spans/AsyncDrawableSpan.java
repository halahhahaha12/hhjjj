/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$FontMetricsInt
 *  android.graphics.Rect
 *  android.text.style.ReplacementSpan
 *  java.lang.CharSequence
 *  java.lang.Throwable
 */
package ru.noties.markwon.spans;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.style.ReplacementSpan;
import ru.noties.markwon.spans.AsyncDrawable;
import ru.noties.markwon.spans.CanvasUtils;
import ru.noties.markwon.spans.SpannableTheme;

public class AsyncDrawableSpan
extends ReplacementSpan {
    public static final int ALIGN_BASELINE = 1;
    public static final int ALIGN_BOTTOM = 0;
    public static final int ALIGN_CENTER = 2;
    private final int alignment;
    private final AsyncDrawable drawable;
    private final boolean replacementTextIsLink;
    private final SpannableTheme theme;

    public AsyncDrawableSpan(SpannableTheme spannableTheme, AsyncDrawable asyncDrawable) {
        this(spannableTheme, asyncDrawable, 0);
    }

    public AsyncDrawableSpan(SpannableTheme spannableTheme, AsyncDrawable asyncDrawable, int n) {
        this(spannableTheme, asyncDrawable, n, false);
    }

    public AsyncDrawableSpan(SpannableTheme spannableTheme, AsyncDrawable asyncDrawable, int n, boolean bl) {
        this.theme = spannableTheme;
        this.drawable = asyncDrawable;
        this.alignment = n;
        this.replacementTextIsLink = bl;
        if (asyncDrawable.getBounds().isEmpty()) {
            asyncDrawable.setBounds(0, 0, asyncDrawable.getIntrinsicWidth(), asyncDrawable.getIntrinsicHeight());
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void draw(Canvas canvas, CharSequence charSequence, int n, int n2, float f, int n3, int n4, int n5, Paint paint) {
        int n6;
        int n7;
        AsyncDrawable asyncDrawable;
        block7 : {
            int n8;
            this.drawable.initWithKnownDimensions(canvas.getWidth(), paint.getTextSize());
            asyncDrawable = this.drawable;
            if (asyncDrawable.hasResult()) {
                n6 = n5 - asyncDrawable.getBounds().bottom;
                n7 = canvas.save();
                try {
                    int n9 = this.alignment;
                    if (2 == n9) {
                        n8 = (n5 - n3 - asyncDrawable.getBounds().height()) / 2;
                    }
                    if (1 == n9) {
                        n8 = paint.getFontMetricsInt().descent;
                    }
                    break block7;
                }
                catch (Throwable throwable) {
                    canvas.restoreToCount(n7);
                    throw throwable;
                }
            } else {
                float f2 = CanvasUtils.textCenterY(n3, n5, paint);
                if (this.replacementTextIsLink) {
                    this.theme.applyLinkStyle(paint);
                }
                canvas.drawText(charSequence, n, n2, f, f2, paint);
                return;
            }
            n6 -= n8;
        }
        canvas.translate(f, (float)n6);
        asyncDrawable.draw(canvas);
        canvas.restoreToCount(n7);
    }

    public AsyncDrawable getDrawable() {
        return this.drawable;
    }

    public int getSize(Paint paint, CharSequence charSequence, int n, int n2, Paint.FontMetricsInt fontMetricsInt) {
        if (this.drawable.hasResult()) {
            Rect rect = this.drawable.getBounds();
            if (fontMetricsInt != null) {
                fontMetricsInt.ascent = -rect.bottom;
                fontMetricsInt.descent = 0;
                fontMetricsInt.top = fontMetricsInt.ascent;
                fontMetricsInt.bottom = 0;
            }
            return rect.right;
        }
        if (this.replacementTextIsLink) {
            this.theme.applyLinkStyle(paint);
        }
        return (int)(0.5f + paint.measureText(charSequence, n, n2));
    }
}

