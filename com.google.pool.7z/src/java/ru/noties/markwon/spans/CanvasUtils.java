/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  java.lang.Object
 */
package ru.noties.markwon.spans;

import android.graphics.Paint;

abstract class CanvasUtils {
    private CanvasUtils() {
    }

    static float textCenterY(int n, int n2, Paint paint) {
        return (int)((float)(n2 - (n2 - n) / 2) - (0.5f + (paint.descent() + paint.ascent()) / 2.0f));
    }
}

