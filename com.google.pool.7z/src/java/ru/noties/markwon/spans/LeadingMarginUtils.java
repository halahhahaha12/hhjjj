/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.Spanned
 *  java.lang.CharSequence
 *  java.lang.Object
 */
package ru.noties.markwon.spans;

import android.text.Spanned;

abstract class LeadingMarginUtils {
    private LeadingMarginUtils() {
    }

    static boolean selfEnd(int n, CharSequence charSequence, Object object) {
        return charSequence instanceof Spanned && ((Spanned)charSequence).getSpanEnd(object) == n;
    }

    static boolean selfStart(int n, CharSequence charSequence, Object object) {
        return charSequence instanceof Spanned && ((Spanned)charSequence).getSpanStart(object) == n;
    }
}

