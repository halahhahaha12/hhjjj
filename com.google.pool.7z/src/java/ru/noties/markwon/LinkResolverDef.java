/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.util.Log
 *  android.view.View
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package ru.noties.markwon;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import ru.noties.markwon.spans.LinkSpan;

public class LinkResolverDef
implements LinkSpan.Resolver {
    @Override
    public void resolve(View view, String string2) {
        Uri uri = Uri.parse((String)string2);
        Context context = view.getContext();
        Intent intent = new Intent("android.intent.action.VIEW", uri);
        intent.putExtra("com.android.browser.application_id", context.getPackageName());
        try {
            context.startActivity(intent);
            return;
        }
        catch (ActivityNotFoundException activityNotFoundException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Actvity was not found for intent, ");
            stringBuilder.append(intent.toString());
            Log.w((String)"LinkResolverDef", (String)stringBuilder.toString());
            return;
        }
    }
}

