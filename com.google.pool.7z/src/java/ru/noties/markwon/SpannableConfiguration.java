/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  ru.noties.markwon.AsyncDrawableLoaderNoOp
 *  ru.noties.markwon.LinkResolverDef
 *  ru.noties.markwon.SyntaxHighlightNoOp
 *  ru.noties.markwon.UrlProcessorNoOp
 *  ru.noties.markwon.renderer.html.ImageSizeResolverDef
 */
package ru.noties.markwon;

import android.content.Context;
import ru.noties.markwon.AsyncDrawableLoaderNoOp;
import ru.noties.markwon.LinkResolverDef;
import ru.noties.markwon.SyntaxHighlight;
import ru.noties.markwon.SyntaxHighlightNoOp;
import ru.noties.markwon.UrlProcessor;
import ru.noties.markwon.UrlProcessorNoOp;
import ru.noties.markwon.renderer.html.ImageSizeResolver;
import ru.noties.markwon.renderer.html.ImageSizeResolverDef;
import ru.noties.markwon.renderer.html.SpannableHtmlParser;
import ru.noties.markwon.spans.AsyncDrawable;
import ru.noties.markwon.spans.LinkSpan;
import ru.noties.markwon.spans.SpannableTheme;

public class SpannableConfiguration {
    private final AsyncDrawable.Loader asyncDrawableLoader;
    private final SpannableHtmlParser htmlParser;
    private final LinkSpan.Resolver linkResolver;
    private final SyntaxHighlight syntaxHighlight;
    private final SpannableTheme theme;
    private final UrlProcessor urlProcessor;

    private SpannableConfiguration(Builder builder) {
        this.theme = builder.theme;
        this.asyncDrawableLoader = builder.asyncDrawableLoader;
        this.syntaxHighlight = builder.syntaxHighlight;
        this.linkResolver = builder.linkResolver;
        this.urlProcessor = builder.urlProcessor;
        this.htmlParser = builder.htmlParser;
    }

    public static Builder builder(Context context) {
        return new Builder(context);
    }

    public static SpannableConfiguration create(Context context) {
        return new Builder(context).build();
    }

    public AsyncDrawable.Loader asyncDrawableLoader() {
        return this.asyncDrawableLoader;
    }

    public SpannableHtmlParser htmlParser() {
        return this.htmlParser;
    }

    public LinkSpan.Resolver linkResolver() {
        return this.linkResolver;
    }

    public SyntaxHighlight syntaxHighlight() {
        return this.syntaxHighlight;
    }

    public SpannableTheme theme() {
        return this.theme;
    }

    public UrlProcessor urlProcessor() {
        return this.urlProcessor;
    }

    public static class Builder {
        private AsyncDrawable.Loader asyncDrawableLoader;
        private final Context context;
        private SpannableHtmlParser htmlParser;
        private ImageSizeResolver imageSizeResolver;
        private LinkSpan.Resolver linkResolver;
        private SyntaxHighlight syntaxHighlight;
        private SpannableTheme theme;
        private UrlProcessor urlProcessor;

        Builder(Context context) {
            this.context = context;
        }

        public Builder asyncDrawableLoader(AsyncDrawable.Loader loader) {
            this.asyncDrawableLoader = loader;
            return this;
        }

        public SpannableConfiguration build() {
            if (this.theme == null) {
                this.theme = SpannableTheme.create(this.context);
            }
            if (this.asyncDrawableLoader == null) {
                this.asyncDrawableLoader = new AsyncDrawableLoaderNoOp();
            }
            if (this.syntaxHighlight == null) {
                this.syntaxHighlight = new SyntaxHighlightNoOp();
            }
            if (this.linkResolver == null) {
                this.linkResolver = new LinkResolverDef();
            }
            if (this.urlProcessor == null) {
                this.urlProcessor = new UrlProcessorNoOp();
            }
            if (this.htmlParser == null) {
                if (this.imageSizeResolver == null) {
                    this.imageSizeResolver = new ImageSizeResolverDef();
                }
                this.htmlParser = SpannableHtmlParser.create(this.theme, this.asyncDrawableLoader, this.urlProcessor, this.linkResolver, this.imageSizeResolver);
            }
            return new SpannableConfiguration(this);
        }

        public Builder htmlParser(SpannableHtmlParser spannableHtmlParser) {
            this.htmlParser = spannableHtmlParser;
            return this;
        }

        public Builder imageSizeResolver(ImageSizeResolver imageSizeResolver) {
            this.imageSizeResolver = imageSizeResolver;
            return this;
        }

        public Builder linkResolver(LinkSpan.Resolver resolver) {
            this.linkResolver = resolver;
            return this;
        }

        public Builder syntaxHighlight(SyntaxHighlight syntaxHighlight) {
            this.syntaxHighlight = syntaxHighlight;
            return this;
        }

        public Builder theme(SpannableTheme spannableTheme) {
            this.theme = spannableTheme;
            return this;
        }

        public Builder urlProcessor(UrlProcessor urlProcessor) {
            this.urlProcessor = urlProcessor;
            return this;
        }
    }

}

