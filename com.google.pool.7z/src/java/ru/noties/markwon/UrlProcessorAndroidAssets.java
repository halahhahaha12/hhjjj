/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package ru.noties.markwon;

import android.net.Uri;
import android.text.TextUtils;
import ru.noties.markwon.UrlProcessor;
import ru.noties.markwon.UrlProcessorRelativeToAbsolute;

public class UrlProcessorAndroidAssets
implements UrlProcessor {
    private final UrlProcessorRelativeToAbsolute assetsProcessor = new UrlProcessorRelativeToAbsolute("file:///android_asset/");
    private final UrlProcessor processor;

    public UrlProcessorAndroidAssets() {
        this(null);
    }

    public UrlProcessorAndroidAssets(UrlProcessor urlProcessor) {
        this.processor = urlProcessor;
    }

    @Override
    public String process(String string2) {
        if (TextUtils.isEmpty((CharSequence)Uri.parse((String)string2).getScheme())) {
            return this.assetsProcessor.process(string2);
        }
        UrlProcessor urlProcessor = this.processor;
        if (urlProcessor != null) {
            string2 = urlProcessor.process(string2);
        }
        return string2;
    }
}

