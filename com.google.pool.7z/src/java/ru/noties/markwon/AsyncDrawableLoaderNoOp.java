/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package ru.noties.markwon;

import ru.noties.markwon.spans.AsyncDrawable;

class AsyncDrawableLoaderNoOp
implements AsyncDrawable.Loader {
    AsyncDrawableLoaderNoOp() {
    }

    @Override
    public void cancel(String string2) {
    }

    @Override
    public void load(String string2, AsyncDrawable asyncDrawable) {
    }
}

