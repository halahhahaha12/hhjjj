/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.method.LinkMovementMethod
 *  android.text.method.MovementMethod
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  org.commonmark.ext.gfm.strikethrough.StrikethroughExtension
 *  org.commonmark.ext.gfm.tables.TablesExtension
 *  ru.noties.markwon.tasklist.TaskListExtension
 */
package ru.noties.markwon;

import android.content.Context;
import android.text.method.LinkMovementMethod;
import android.text.method.MovementMethod;
import android.widget.TextView;
import java.util.Arrays;
import org.commonmark.Extension;
import org.commonmark.ext.gfm.strikethrough.StrikethroughExtension;
import org.commonmark.ext.gfm.tables.TablesExtension;
import org.commonmark.node.Node;
import org.commonmark.parser.Parser;
import ru.noties.markwon.DrawablesScheduler;
import ru.noties.markwon.SpannableConfiguration;
import ru.noties.markwon.TableRowsScheduler;
import ru.noties.markwon.renderer.SpannableRenderer;
import ru.noties.markwon.tasklist.TaskListExtension;

public abstract class Markwon {
    private Markwon() {
    }

    public static Parser createParser() {
        Parser.Builder builder = new Parser.Builder();
        Object[] arrobject = new Extension[]{StrikethroughExtension.create(), TablesExtension.create(), TaskListExtension.create()};
        return builder.extensions((Iterable<? extends Extension>)Arrays.asList((Object[])arrobject)).build();
    }

    public static CharSequence markdown(Context context, String string2) {
        return Markwon.markdown(SpannableConfiguration.create(context), string2);
    }

    public static CharSequence markdown(SpannableConfiguration spannableConfiguration, String string2) {
        Node node = Markwon.createParser().parse(string2);
        return new SpannableRenderer().render(spannableConfiguration, node);
    }

    public static void scheduleDrawables(TextView textView) {
        DrawablesScheduler.schedule(textView);
    }

    public static void scheduleTableRows(TextView textView) {
        TableRowsScheduler.schedule(textView);
    }

    public static void setMarkdown(TextView textView, String string2) {
        Markwon.setMarkdown(textView, SpannableConfiguration.create(textView.getContext()), string2);
    }

    public static void setMarkdown(TextView textView, SpannableConfiguration spannableConfiguration, String string2) {
        Markwon.setText(textView, Markwon.markdown(spannableConfiguration, string2));
    }

    public static void setText(TextView textView, CharSequence charSequence) {
        Markwon.unscheduleDrawables(textView);
        Markwon.unscheduleTableRows(textView);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setText(charSequence);
        Markwon.scheduleDrawables(textView);
        Markwon.scheduleTableRows(textView);
    }

    public static void unscheduleDrawables(TextView textView) {
        DrawablesScheduler.unschedule(textView);
    }

    public static void unscheduleTableRows(TextView textView) {
        TableRowsScheduler.unschedule(textView);
    }
}

