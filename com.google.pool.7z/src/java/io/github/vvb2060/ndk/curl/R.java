/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.github.vvb2060.ndk.curl;

public final class R {
    private R() {
    }
}

